import { useState, useEffect, useMemo } from "react";
import axios from "axios";

const API = "http://localhost:8080/api";

const exportCSV = (rows) => {
  const h = ["Code","ServiceMark","FamilleGeo","ServiceText","Description","NatInter","Jour","Suffixe","Libel25","LibelleFa","IsPrimary"];
  const lines = rows.map(r => h.map(k => `"${r[k.charAt(0).toLowerCase()+k.slice(1)]||""}"`).join(","));
  const blob = new Blob([[h.join(","),...lines].join("\n")],{type:"text/csv"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob);
  a.download="products.csv"; a.click();
};

const SortIcon = ({ f, sf, sd }) => sf!==f ? <span className="text-gray-300 ml-1">⇅</span> : <span className="text-blue-600 ml-1">{sd==="asc"?"↑":"↓"}</span>;

export default function ProductsPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterNat, setFilterNat] = useState("all");
  const [filterPrimary, setFilterPrimary] = useState("all");
  const [sortField, setSortField] = useState("codeGeopost");
  const [sortDir, setSortDir] = useState("asc");
  const [page, setPage] = useState(1);
  const PS = 30;

  useEffect(() => {
    axios.get(`${API}/admin/products`).then(r => {
      if (r.data.success) setRows(r.data.data || []);
    }).catch(() => {
      // fallback mock for demo
      setRows([
        { id:1, codeGeopost:327, serviceMark:".", serviceText:"D-B2C", description:"TRANSIT B2C NORMAL", natInter:"I", jour:"SE", suffixe:"JF", libel25:"COM INT", libelleFa:"B2C NORMAL PA", isPrimary:"P" },
        { id:2, codeGeopost:328, serviceMark:"X", serviceText:"XD-B2C", description:"TRANSIT B2C SMALL", natInter:"I", jour:"SE", suffixe:"JF", libel25:"COM INT", libelleFa:"B2C SMALL PAR", isPrimary:"P" },
      ]);
    }).finally(() => setLoading(false));
  }, []);

  const handleSort = (f) => { if(sortField===f) setSortDir(d=>d==="asc"?"desc":"asc"); else{setSortField(f);setSortDir("asc");} setPage(1); };

  const filtered = useMemo(() => {
    let r = [...rows];
    if (search) { const q=search.toLowerCase(); r=r.filter(x=>(x.description||"").toLowerCase().includes(q)||(x.serviceText||"").toLowerCase().includes(q)||String(x.codeGeopost).includes(q)||(x.suffixe||"").toLowerCase().includes(q)); }
    if (filterNat!=="all") r=r.filter(x=>x.natInter===filterNat);
    if (filterPrimary!=="all") r=r.filter(x=>x.isPrimary===filterPrimary);
    r.sort((a,b)=>{
      let av=a[sortField]??"", bv=b[sortField]??"";
      if (typeof av==="number") return sortDir==="asc"?av-bv:bv-av;
      return sortDir==="asc"?String(av).localeCompare(String(bv)):String(bv).localeCompare(String(av));
    });
    return r;
  }, [rows, search, filterNat, filterPrimary, sortField, sortDir]);

  const pageRows = filtered.slice((page-1)*PS, page*PS);

  const TH = ({f,children}) => (
    <th onClick={()=>handleSort(f)} className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide cursor-pointer hover:bg-gray-100 whitespace-nowrap select-none">
      {children}<SortIcon f={f} sf={sortField} sd={sortDir}/>
    </th>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Products (CHR_PRODUCTS)</h1>
            <p className="text-sm text-gray-400 mt-0.5">Loaded from PRODUIT.CSV · {filtered.length} of {rows.length} rows</p>
          </div>
          <button onClick={()=>exportCSV(filtered)} className="px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 bg-white hover:bg-gray-50">↓ Export CSV</button>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-3 mb-3 flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-1 min-w-[200px] border border-gray-200 rounded-lg px-3 py-1.5">
            <span className="text-gray-400">🔍</span>
            <input value={search} onChange={e=>{setSearch(e.target.value);setPage(1);}} placeholder="Search code, name, service text, suffix..." className="flex-1 text-sm outline-none placeholder-gray-300"/>
            {search&&<button onClick={()=>setSearch("")} className="text-gray-400 text-xs">✕</button>}
          </div>
          <select value={filterNat} onChange={e=>{setFilterNat(e.target.value);setPage(1);}} className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm text-gray-600 focus:outline-none bg-white">
            <option value="all">All (Nat/Inter)</option>
            <option value="N">N — National</option>
            <option value="I">I — International</option>
          </select>
          <select value={filterPrimary} onChange={e=>{setFilterPrimary(e.target.value);setPage(1);}} className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm text-gray-600 focus:outline-none bg-white">
            <option value="all">All (Primary/Other)</option>
            <option value="P">P — Primary</option>
            <option value="O">O — Other</option>
          </select>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {loading ? (
            <div className="p-16 text-center"><div className="animate-spin text-3xl mb-3">⟳</div><p className="text-sm text-gray-400">Loading...</p></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <TH f="codeGeopost">Code Geopost</TH>
                    <TH f="serviceMark">Mark</TH>
                    <TH f="serviceText">Service Text</TH>
                    <TH f="description">Description</TH>
                    <TH f="natInter">N/I</TH>
                    <TH f="jour">Jour</TH>
                    <TH f="suffixe">Suffix</TH>
                    <TH f="libel25">Label (25)</TH>
                    <TH f="libelleFa">Service Name</TH>
                    <TH f="isPrimary">Primary</TH>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {pageRows.map(r => (
                    <tr key={r.id} className="hover:bg-gray-50">
                      <td className="px-3 py-2.5 font-mono text-blue-700 font-semibold">{r.codeGeopost}</td>
                      <td className="px-3 py-2.5 text-center">
                        {r.serviceMark && r.serviceMark!=="." ? (
                          <span className="px-1.5 py-0.5 bg-purple-100 text-purple-700 rounded text-xs font-bold">{r.serviceMark}</span>
                        ) : <span className="text-gray-300">—</span>}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-xs text-gray-700">{r.serviceText}</td>
                      <td className="px-3 py-2.5 text-gray-700">{r.description}</td>
                      <td className="px-3 py-2.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${r.natInter==="I"?"bg-blue-100 text-blue-700":"bg-gray-100 text-gray-600"}`}>{r.natInter}</span>
                      </td>
                      <td className="px-3 py-2.5 text-xs text-gray-500">{r.jour}</td>
                      <td className="px-3 py-2.5 font-mono text-sm font-bold text-gray-800">{r.suffixe}</td>
                      <td className="px-3 py-2.5 font-mono text-xs text-gray-600">{r.libel25}</td>
                      <td className="px-3 py-2.5 text-gray-600">{r.libelleFa}</td>
                      <td className="px-3 py-2.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${r.isPrimary==="P"?"bg-green-100 text-green-700":"bg-gray-100 text-gray-500"}`}>{r.isPrimary}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {filtered.length > PS && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100 bg-gray-50">
              <p className="text-xs text-gray-400">Showing {(page-1)*PS+1}–{Math.min(page*PS,filtered.length)} of {filtered.length}</p>
              <div className="flex gap-1">
                <button onClick={()=>setPage(1)} disabled={page===1} className="px-2 py-1 text-xs border border-gray-200 rounded disabled:opacity-40">«</button>
                <button onClick={()=>setPage(p=>p-1)} disabled={page===1} className="px-2 py-1 text-xs border border-gray-200 rounded disabled:opacity-40">‹</button>
                <span className="px-3 py-1 text-xs bg-blue-600 text-white rounded">{page}</span>
                <button onClick={()=>setPage(p=>p+1)} disabled={page===Math.ceil(filtered.length/PS)} className="px-2 py-1 text-xs border border-gray-200 rounded disabled:opacity-40">›</button>
                <button onClick={()=>setPage(Math.ceil(filtered.length/PS))} disabled={page===Math.ceil(filtered.length/PS)} className="px-2 py-1 text-xs border border-gray-200 rounded disabled:opacity-40">»</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
