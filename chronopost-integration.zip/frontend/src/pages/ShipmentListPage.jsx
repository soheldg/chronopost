import { useState, useEffect, useMemo, useCallback } from "react";
import axios from "axios";

const API = "http://localhost:8080/api";

// ── Helpers ──────────────────────────────────────────────────────
const STATUS_META = {
  CREATED:      { label:"Created",       cls:"bg-gray-100 text-gray-600",    dot:"bg-gray-400" },
  LABEL_READY:  { label:"Label Ready",   cls:"bg-blue-100 text-blue-700",    dot:"bg-blue-500" },
  PREALERT_SENT:{ label:"Pre-Alert Sent",cls:"bg-purple-100 text-purple-700",dot:"bg-purple-500" },
  INVOICE_SENT: { label:"Invoice Sent",  cls:"bg-teal-100 text-teal-700",    dot:"bg-teal-500" },
  IN_TRANSIT:   { label:"In Transit",    cls:"bg-yellow-100 text-yellow-700",dot:"bg-yellow-500" },
  DELIVERED:    { label:"Delivered",     cls:"bg-green-100 text-green-700",  dot:"bg-green-500" },
  FAILED:       { label:"Failed",        cls:"bg-red-100 text-red-700",      dot:"bg-red-500" },
  RETURNED:     { label:"Returned",      cls:"bg-orange-100 text-orange-700",dot:"bg-orange-500" },
};

const LH_META = { AI:"✈ Air", RO:"🚛 Road", SE:"🚢 Sea" };

const Badge = ({ status }) => {
  const m = STATUS_META[status] || STATUS_META.CREATED;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${m.cls}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${m.dot}`}/>
      {m.label}
    </span>
  );
};

const fmt = (v) => v ? new Date(v).toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"2-digit"}) : "—";

// ── Sort icon ─────────────────────────────────────────────────────
const SortIcon = ({ field, sortField, sortDir }) => {
  if (sortField !== field) return <span className="text-gray-300 ml-1 text-xs">⇅</span>;
  return <span className="text-blue-600 ml-1 text-xs">{sortDir==="asc"?"↑":"↓"}</span>;
};

// ── Column header ─────────────────────────────────────────────────
const TH = ({ children, field, sortField, sortDir, onSort, className="" }) => (
  <th
    onClick={() => onSort(field)}
    className={`px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase
                tracking-wide cursor-pointer select-none hover:bg-gray-100
                whitespace-nowrap ${className}`}
  >
    {children}
    {field && <SortIcon field={field} sortField={sortField} sortDir={sortDir}/>}
  </th>
);

// ── Filter chip ───────────────────────────────────────────────────
const FilterChip = ({ label, onRemove }) => (
  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100
                   text-blue-700 rounded-full text-xs font-medium">
    {label}
    <button onClick={onRemove} className="hover:text-blue-900 font-bold">×</button>
  </span>
);

// ── Multi-select dropdown ─────────────────────────────────────────
const MultiSelect = ({ label, options, selected, onChange }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200
                   rounded-lg text-xs text-gray-600 hover:border-gray-300 bg-white
                   whitespace-nowrap"
      >
        {label}
        {selected.length > 0 && (
          <span className="bg-blue-600 text-white rounded-full px-1.5 py-0 text-xs">
            {selected.length}
          </span>
        )}
        <span className="text-gray-400">{open?"▲":"▼"}</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)}/>
          <div className="absolute top-full left-0 mt-1 bg-white border border-gray-200
                          rounded-xl shadow-xl z-20 min-w-[160px] py-1">
            {options.map(opt => (
              <label key={opt.value}
                className="flex items-center gap-2.5 px-3 py-2 hover:bg-gray-50
                           cursor-pointer text-sm">
                <input
                  type="checkbox"
                  checked={selected.includes(opt.value)}
                  onChange={e => {
                    if (e.target.checked) onChange([...selected, opt.value]);
                    else onChange(selected.filter(s => s !== opt.value));
                  }}
                  className="accent-blue-600"
                />
                {opt.label}
              </label>
            ))}
            {selected.length > 0 && (
              <button onClick={() => onChange([])}
                className="w-full text-left px-3 py-2 text-xs text-red-500
                           hover:bg-red-50 border-t border-gray-100 mt-1">
                Clear all
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
};

// ── Date range picker ─────────────────────────────────────────────
const DateRange = ({ from, to, onChange }) => (
  <div className="flex items-center gap-1">
    <input type="date" value={from}
      onChange={e => onChange(e.target.value, to)}
      className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs
                 text-gray-600 focus:outline-none focus:border-blue-400"/>
    <span className="text-gray-400 text-xs">—</span>
    <input type="date" value={to}
      onChange={e => onChange(from, e.target.value)}
      className="border border-gray-200 rounded-lg px-2 py-1.5 text-xs
                 text-gray-600 focus:outline-none focus:border-blue-400"/>
  </div>
);

// ── Export CSV ────────────────────────────────────────────────────
const exportCSV = (rows) => {
  const headers = ["ID","MPSID","Status","Sender","Country","Parcels","Weight(g)","Transport","Created"];
  const lines = rows.map(r => [
    r.id, r.mpsId, r.status,
    r.senderName || "",
    r.receiverCountry || "",
    r.parcelCount || "",
    r.totalWeightGrams || "",
    r.linehaul || "",
    r.createdAt?.substring(0,10) || ""
  ].map(v => `"${v}"`).join(","));
  const blob = new Blob([[headers.join(","), ...lines].join("\n")], { type:"text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `shipments_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
};

// ── Main Page ─────────────────────────────────────────────────────
export default function ShipmentListPage({ onNavigate, onSelect }) {
  const [shipments, setShipments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(new Set());

  // Sort
  const [sortField, setSortField] = useState("id");
  const [sortDir, setSortDir] = useState("desc");

  // Filters
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState([]);
  const [filterLinehaul, setFilterLinehaul] = useState([]);
  const [filterCountry, setFilterCountry] = useState([]);
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [weightMin, setWeightMin] = useState("");
  const [weightMax, setWeightMax] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  // Pagination
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  useEffect(() => { loadShipments(); }, []);

  const loadShipments = async () => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await axios.get(`${API}/shipment/list`);
      if (data.success) setShipments(data.data || []);
    } catch (e) {
      setError("Failed to load shipments");
    } finally {
      setLoading(false);
    }
  };

  const handleSort = useCallback((field) => {
    if (sortField === field) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
    setPage(1);
  }, [sortField]);

  // ── Derived: all unique countries ─────────────────────────────
  const countries = useMemo(() =>
    [...new Set(shipments.map(s => s.receiverCountry).filter(Boolean))].sort()
  , [shipments]);

  // ── Apply filters + sort ──────────────────────────────────────
  const filtered = useMemo(() => {
    let rows = [...shipments];

    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(s =>
        (s.mpsId||"").toLowerCase().includes(q) ||
        (s.senderName||"").toLowerCase().includes(q) ||
        (s.receiverName||"").toLowerCase().includes(q) ||
        String(s.id).includes(q)
      );
    }
    if (filterStatus.length)   rows = rows.filter(s => filterStatus.includes(s.status));
    if (filterLinehaul.length) rows = rows.filter(s => filterLinehaul.includes(s.linehaul));
    if (filterCountry.length)  rows = rows.filter(s => filterCountry.includes(s.receiverCountry));
    if (dateFrom)  rows = rows.filter(s => s.createdAt >= dateFrom);
    if (dateTo)    rows = rows.filter(s => s.createdAt <= dateTo + "T23:59:59");
    if (weightMin) rows = rows.filter(s => (s.totalWeightGrams||0) >= Number(weightMin));
    if (weightMax) rows = rows.filter(s => (s.totalWeightGrams||0) <= Number(weightMax));

    rows.sort((a, b) => {
      let av = a[sortField] ?? "", bv = b[sortField] ?? "";
      if (typeof av === "number" && typeof bv === "number") {
        return sortDir === "asc" ? av - bv : bv - av;
      }
      av = String(av).toLowerCase(); bv = String(bv).toLowerCase();
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });

    return rows;
  }, [shipments, search, filterStatus, filterLinehaul, filterCountry,
      dateFrom, dateTo, weightMin, weightMax, sortField, sortDir]);

  const pageRows = filtered.slice((page-1)*PAGE_SIZE, page*PAGE_SIZE);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));

  const activeFilters = [
    ...filterStatus.map(s => ({ label:`Status: ${STATUS_META[s]?.label||s}`, clear: () => setFilterStatus(f=>f.filter(x=>x!==s)) })),
    ...filterLinehaul.map(l => ({ label:`Transport: ${LH_META[l]||l}`, clear: () => setFilterLinehaul(f=>f.filter(x=>x!==l)) })),
    ...filterCountry.map(c => ({ label:`Country: ${c}`, clear: () => setFilterCountry(f=>f.filter(x=>x!==c)) })),
    ...(dateFrom||dateTo ? [{ label:`Date: ${dateFrom||"…"} → ${dateTo||"…"}`, clear:()=>{setDateFrom("");setDateTo("");} }] : []),
    ...(weightMin||weightMax ? [{ label:`Weight: ${weightMin||0}–${weightMax||"∞"}g`, clear:()=>{setWeightMin("");setWeightMax("");} }] : []),
  ];

  const clearAll = () => {
    setSearch(""); setFilterStatus([]); setFilterLinehaul([]);
    setFilterCountry([]); setDateFrom(""); setDateTo("");
    setWeightMin(""); setWeightMax(""); setPage(1);
  };

  const toggleSelect = (id) => setSelected(s => {
    const n = new Set(s);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });

  const toggleAll = () => {
    if (selected.size === pageRows.length) setSelected(new Set());
    else setSelected(new Set(pageRows.map(r => r.id)));
  };

  // Stats
  const stats = useMemo(() => ({
    total: shipments.length,
    delivered: shipments.filter(s=>s.status==="DELIVERED").length,
    inTransit: shipments.filter(s=>s.status==="IN_TRANSIT").length,
    pending: shipments.filter(s=>["CREATED","LABEL_READY"].includes(s.status)).length,
    failed: shipments.filter(s=>s.status==="FAILED").length,
  }), [shipments]);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Shipments</h1>
            <p className="text-sm text-gray-400 mt-0.5">
              {filtered.length} of {shipments.length} shipments
            </p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => exportCSV(filtered)}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm
                         text-gray-600 hover:bg-white bg-white">
              ↓ Export CSV
            </button>
            <button onClick={loadShipments}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm
                         text-gray-600 hover:bg-white bg-white">
              ↻ Refresh
            </button>
            <button onClick={() => onNavigate?.("new-shipment")}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white
                         rounded-lg text-sm font-medium">
              + New Shipment
            </button>
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-5 gap-3 mb-5">
          {[
            { label:"Total",      val:stats.total,     color:"text-gray-800",   bg:"bg-white" },
            { label:"Delivered",  val:stats.delivered, color:"text-green-600",  bg:"bg-green-50" },
            { label:"In Transit", val:stats.inTransit, color:"text-yellow-600", bg:"bg-yellow-50" },
            { label:"Pending",    val:stats.pending,   color:"text-blue-600",   bg:"bg-blue-50" },
            { label:"Failed",     val:stats.failed,    color:"text-red-600",    bg:"bg-red-50" },
          ].map(c => (
            <div key={c.label} onClick={() => {
              if (c.label==="Delivered") setFilterStatus(["DELIVERED"]);
              else if (c.label==="In Transit") setFilterStatus(["IN_TRANSIT"]);
              else if (c.label==="Pending") setFilterStatus(["CREATED","LABEL_READY"]);
              else if (c.label==="Failed") setFilterStatus(["FAILED"]);
              else clearAll();
              setPage(1);
            }}
              className={`${c.bg} rounded-xl border border-gray-200 p-4
                          cursor-pointer hover:shadow-sm transition-shadow`}>
              <p className="text-xs text-gray-500">{c.label}</p>
              <p className={`text-2xl font-bold mt-1 ${c.color}`}>{c.val}</p>
            </div>
          ))}
        </div>

        {/* Search + Filter bar */}
        <div className="bg-white rounded-xl border border-gray-200 p-3 mb-3">
          <div className="flex items-center gap-3 flex-wrap">

            {/* Global search */}
            <div className="flex items-center gap-2 flex-1 min-w-[200px]
                            border border-gray-200 rounded-lg px-3 py-1.5">
              <span className="text-gray-400 text-sm">🔍</span>
              <input
                type="text" value={search}
                onChange={e => { setSearch(e.target.value); setPage(1); }}
                placeholder="Search by ID, MPSID, sender, receiver..."
                className="flex-1 text-sm outline-none placeholder-gray-300"
              />
              {search && (
                <button onClick={() => setSearch("")}
                  className="text-gray-400 hover:text-gray-600 text-xs">✕</button>
              )}
            </div>

            {/* Filter dropdowns */}
            <MultiSelect
              label="Status"
              options={Object.entries(STATUS_META).map(([v,m])=>({value:v,label:m.label}))}
              selected={filterStatus} onChange={v=>{setFilterStatus(v);setPage(1);}}
            />
            <MultiSelect
              label="Transport"
              options={Object.entries(LH_META).map(([v,l])=>({value:v,label:l}))}
              selected={filterLinehaul} onChange={v=>{setFilterLinehaul(v);setPage(1);}}
            />
            <MultiSelect
              label="Country"
              options={countries.map(c=>({value:c,label:c}))}
              selected={filterCountry} onChange={v=>{setFilterCountry(v);setPage(1);}}
            />

            {/* Advanced filters toggle */}
            <button onClick={() => setShowFilters(!showFilters)}
              className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs
                         text-gray-600 hover:border-gray-300 whitespace-nowrap">
              {showFilters ? "▲" : "▼"} More filters
              {(dateFrom||dateTo||weightMin||weightMax) && (
                <span className="ml-1 bg-blue-600 text-white rounded-full px-1.5 text-xs">!</span>
              )}
            </button>

            {activeFilters.length > 0 && (
              <button onClick={clearAll}
                className="text-xs text-red-500 hover:text-red-700 whitespace-nowrap">
                Clear all ({activeFilters.length})
              </button>
            )}
          </div>

          {/* Advanced filters panel */}
          {showFilters && (
            <div className="flex items-center gap-4 mt-3 pt-3 border-t border-gray-100 flex-wrap">
              <div>
                <p className="text-xs text-gray-400 mb-1">Date range</p>
                <DateRange from={dateFrom} to={dateTo}
                  onChange={(f,t)=>{setDateFrom(f);setDateTo(t);setPage(1);}}/>
              </div>
              <div>
                <p className="text-xs text-gray-400 mb-1">Weight (grams)</p>
                <div className="flex items-center gap-1">
                  <input type="number" value={weightMin}
                    onChange={e=>{setWeightMin(e.target.value);setPage(1);}}
                    placeholder="Min" className="w-20 border border-gray-200 rounded
                    px-2 py-1.5 text-xs focus:outline-none focus:border-blue-400"/>
                  <span className="text-gray-400 text-xs">—</span>
                  <input type="number" value={weightMax}
                    onChange={e=>{setWeightMax(e.target.value);setPage(1);}}
                    placeholder="Max" className="w-20 border border-gray-200 rounded
                    px-2 py-1.5 text-xs focus:outline-none focus:border-blue-400"/>
                </div>
              </div>
            </div>
          )}

          {/* Active filter chips */}
          {activeFilters.length > 0 && (
            <div className="flex gap-2 mt-2.5 flex-wrap">
              {activeFilters.map((f,i) => (
                <FilterChip key={i} label={f.label} onRemove={f.clear}/>
              ))}
            </div>
          )}
        </div>

        {/* Bulk action bar */}
        {selected.size > 0 && (
          <div className="bg-blue-600 rounded-xl px-4 py-2.5 mb-3
                          flex items-center justify-between">
            <p className="text-sm text-white font-medium">
              {selected.size} selected
            </p>
            <div className="flex gap-2">
              <button className="px-3 py-1 bg-white text-blue-700 rounded-lg
                                 text-xs font-medium hover:bg-blue-50">
                📡 Send Pre-Alert
              </button>
              <button className="px-3 py-1 bg-white text-blue-700 rounded-lg
                                 text-xs font-medium hover:bg-blue-50">
                🏷️ Generate Labels
              </button>
              <button onClick={() => setSelected(new Set())}
                className="px-3 py-1 text-white text-xs hover:underline">
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {loading ? (
            <div className="p-16 text-center">
              <div className="animate-spin text-3xl mb-3">⟳</div>
              <p className="text-sm text-gray-400">Loading shipments...</p>
            </div>
          ) : error ? (
            <div className="p-12 text-center">
              <p className="text-red-500 text-sm">{error}</p>
              <button onClick={loadShipments}
                className="mt-3 text-sm text-blue-600 underline">Retry</button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-16 text-center">
              <div className="text-4xl text-gray-300 mb-3">📦</div>
              <p className="text-sm text-gray-400">No shipments match your filters</p>
              <button onClick={clearAll}
                className="mt-3 text-sm text-blue-600 underline">Clear filters</button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-3 py-2.5 w-8">
                      <input type="checkbox"
                        checked={selected.size===pageRows.length && pageRows.length>0}
                        onChange={toggleAll} className="accent-blue-600"/>
                    </th>
                    <TH field="id" sortField={sortField} sortDir={sortDir} onSort={handleSort}>ID</TH>
                    <TH field="mpsId" sortField={sortField} sortDir={sortDir} onSort={handleSort}>MPS ID</TH>
                    <TH field="status" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Status</TH>
                    <TH field="senderName" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Sender</TH>
                    <TH field="receiverName" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Receiver</TH>
                    <TH field="receiverCountry" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Country</TH>
                    <TH field="parcelCount" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Parcels</TH>
                    <TH field="totalWeightGrams" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Weight</TH>
                    <TH field="linehaul" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Transport</TH>
                    <TH field="createdAt" sortField={sortField} sortDir={sortDir} onSort={handleSort}>Created</TH>
                    <th className="px-3 py-2.5 text-xs font-semibold text-gray-500 uppercase tracking-wide">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {pageRows.map(s => (
                    <tr key={s.id}
                      className={`hover:bg-gray-50 transition-colors
                        ${selected.has(s.id) ? "bg-blue-50" : ""}`}>
                      <td className="px-3 py-2.5">
                        <input type="checkbox" checked={selected.has(s.id)}
                          onChange={() => toggleSelect(s.id)}
                          className="accent-blue-600"/>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-xs text-gray-500">#{s.id}</td>
                      <td className="px-3 py-2.5">
                        <span className="font-mono text-xs text-gray-800 bg-gray-100
                                         px-1.5 py-0.5 rounded">
                          {s.mpsId || "—"}
                        </span>
                      </td>
                      <td className="px-3 py-2.5"><Badge status={s.status}/></td>
                      <td className="px-3 py-2.5 text-gray-800 max-w-[140px] truncate">
                        {s.senderName || "—"}
                      </td>
                      <td className="px-3 py-2.5 text-gray-800 max-w-[140px] truncate">
                        {s.receiverName || "—"}
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="text-xs font-semibold text-gray-600
                                         bg-gray-100 px-2 py-0.5 rounded">
                          {s.receiverCountry || "—"}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-center text-gray-600">
                        {s.parcelCount ?? "—"}
                      </td>
                      <td className="px-3 py-2.5 text-gray-600 text-xs">
                        {s.totalWeightGrams ? `${(s.totalWeightGrams/1000).toFixed(2)} kg` : "—"}
                      </td>
                      <td className="px-3 py-2.5 text-xs text-gray-500">
                        {LH_META[s.linehaul] || s.linehaul || "—"}
                      </td>
                      <td className="px-3 py-2.5 text-xs text-gray-400">
                        {fmt(s.createdAt)}
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex gap-1">
                          <button onClick={() => onSelect?.(s.id)}
                            className="px-2 py-1 text-xs text-blue-600 border
                                       border-blue-200 rounded hover:bg-blue-50">
                            View
                          </button>
                          <button onClick={() => onNavigate?.("label", { shipmentId: s.id })}
                            className="px-2 py-1 text-xs text-gray-500 border
                                       border-gray-200 rounded hover:bg-gray-50">
                            🏷️
                          </button>
                          <button onClick={() => onNavigate?.("prealert", { shipmentId: s.id })}
                            className="px-2 py-1 text-xs text-gray-500 border
                                       border-gray-200 rounded hover:bg-gray-50">
                            📡
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {!loading && filtered.length > PAGE_SIZE && (
            <div className="flex items-center justify-between px-4 py-3
                            border-t border-gray-100 bg-gray-50">
              <p className="text-xs text-gray-400">
                Showing {(page-1)*PAGE_SIZE+1}–{Math.min(page*PAGE_SIZE, filtered.length)} of {filtered.length}
              </p>
              <div className="flex items-center gap-1">
                <button onClick={() => setPage(1)} disabled={page===1}
                  className="px-2 py-1 text-xs border border-gray-200 rounded
                             disabled:opacity-40 hover:bg-white">«</button>
                <button onClick={() => setPage(p=>Math.max(1,p-1))} disabled={page===1}
                  className="px-2 py-1 text-xs border border-gray-200 rounded
                             disabled:opacity-40 hover:bg-white">‹</button>

                {/* Page numbers */}
                {Array.from({length: Math.min(7, totalPages)}, (_, i) => {
                  const start = Math.max(1, Math.min(page-3, totalPages-6));
                  const p = start + i;
                  return p <= totalPages ? (
                    <button key={p} onClick={() => setPage(p)}
                      className={`px-2.5 py-1 text-xs border rounded
                        ${p===page
                          ? "bg-blue-600 text-white border-blue-600"
                          : "border-gray-200 hover:bg-white"}`}>
                      {p}
                    </button>
                  ) : null;
                })}

                <button onClick={() => setPage(p=>Math.min(totalPages,p+1))} disabled={page===totalPages}
                  className="px-2 py-1 text-xs border border-gray-200 rounded
                             disabled:opacity-40 hover:bg-white">›</button>
                <button onClick={() => setPage(totalPages)} disabled={page===totalPages}
                  className="px-2 py-1 text-xs border border-gray-200 rounded
                             disabled:opacity-40 hover:bg-white">»</button>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-gray-400">
                Page
                <input type="number" min={1} max={totalPages} value={page}
                  onChange={e => setPage(Math.min(totalPages,Math.max(1,Number(e.target.value))))}
                  className="w-12 border border-gray-200 rounded px-1.5 py-0.5
                             text-center focus:outline-none focus:border-blue-400"/>
                of {totalPages}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
