import { useState, useEffect, useRef } from "react";
import axios from "axios";

const API_BASE = "http://localhost:8080/api";

const StatusBadge = ({ status }) => {
  const map = {
    PENDING:  { cls: "bg-yellow-100 text-yellow-800", label: "Pending" },
    SENT:     { cls: "bg-green-100  text-green-800",  label: "Sent" },
    RECEIVED: { cls: "bg-blue-100   text-blue-800",   label: "Received" },
    FAILED:   { cls: "bg-red-100    text-red-800",    label: "Failed" },
  };
  const s = map[status] || map.PENDING;
  return <span className={`px-2 py-1 rounded text-xs font-medium ${s.cls}`}>{s.label}</span>;
};

const DirectionBadge = ({ direction }) => (
  <span className={`px-2 py-0.5 rounded text-xs font-medium
    ${direction === "OUT" ? "bg-purple-100 text-purple-700" : "bg-teal-100 text-teal-700"}`}>
    {direction === "OUT" ? "↑ Upload" : "↓ Download"}
  </span>
);

const fmtSize = (bytes) => {
  if (!bytes) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024*1024) return `${(bytes/1024).toFixed(1)} KB`;
  return `${(bytes/1024/1024).toFixed(1)} MB`;
};

const DropZone = ({ onFile, file }) => {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef();
  return (
    <div onDrop={e=>{e.preventDefault();setDragging(false);const f=e.dataTransfer.files[0];if(f)onFile(f);}}
      onDragOver={e=>{e.preventDefault();setDragging(true);}}
      onDragLeave={()=>setDragging(false)}
      onClick={()=>inputRef.current?.click()}
      className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-colors
        ${dragging?"border-blue-400 bg-blue-50":file?"border-green-300 bg-green-50":"border-gray-200 hover:border-gray-300 bg-gray-50"}`}>
      <input ref={inputRef} type="file" accept=".pdf" className="hidden"
        onChange={e=>e.target.files[0]&&onFile(e.target.files[0])}/>
      {file ? (
        <div><div className="text-2xl mb-1">📄</div>
          <p className="text-sm font-medium text-green-700">{file.name}</p>
          <p className="text-xs text-green-500 mt-0.5">{fmtSize(file.size)}</p>
        </div>
      ) : (
        <div><div className="text-2xl mb-1 text-gray-400">📂</div>
          <p className="text-sm text-gray-500">Drop PDF here or click to browse</p>
          <p className="text-xs text-gray-400 mt-0.5">PDF only · Min 300 DPI</p>
        </div>
      )}
    </div>
  );
};

const InvoiceRow = ({ inv, onView, onDownload, onRetry }) => (
  <div className="flex items-center gap-3 py-3 border-b border-gray-100 last:border-0 hover:bg-gray-50 rounded px-2">
    <div className="flex-1 min-w-0">
      <p className="text-xs font-mono text-gray-800 truncate">{inv.fileName}</p>
      <p className="text-xs text-gray-400 mt-0.5">
        {inv.createdAt?.substring(0,16).replace("T"," ")} · {fmtSize(inv.fileSize)}
      </p>
    </div>
    <DirectionBadge direction={inv.direction}/>
    <StatusBadge status={inv.ftpStatus}/>
    <div className="flex gap-1">
      <button onClick={()=>onView(inv.id)}
        className="px-2 py-1 text-xs text-gray-500 hover:text-blue-600 border border-gray-200 rounded hover:border-blue-300">
        View
      </button>
      <button onClick={()=>onDownload(inv.id)}
        className="px-2 py-1 text-xs text-gray-500 hover:text-green-600 border border-gray-200 rounded hover:border-green-300">
        Save
      </button>
      {inv.ftpStatus === "FAILED" && (
        <button onClick={()=>onRetry(inv.id)}
          className="px-2 py-1 text-xs text-white bg-orange-500 hover:bg-orange-600 rounded">
          Retry
        </button>
      )}
    </div>
  </div>
);

export default function InvoicePage({ initialShipmentId }) {
  const [tab,          setTab]          = useState("generate"); // generate | upload | history
  const [shipmentId,   setShipmentId]   = useState(initialShipmentId||"");
  const [invoiceType,  setInvoiceType]  = useState("EXP");
  const [file,         setFile]         = useState(null);
  const [uploading,    setUploading]    = useState(false);
  const [fetching,     setFetching]     = useState(false);
  const [generating,   setGenerating]   = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [fetchResult,  setFetchResult]  = useState(null);
  const [invoices,     setInvoices]     = useState([]);
  const [loadingList,  setLoadingList]  = useState(false);
  const [pdfUrl,       setPdfUrl]       = useState(null);
  const [pdfFileName,  setPdfFileName]  = useState("");
  const [error,        setError]        = useState(null);

  useEffect(() => { loadAllInvoices(); }, []);

  const loadAllInvoices = async () => {
    setLoadingList(true);
    try {
      const { data } = await axios.get(`${API_BASE}/invoice/all`);
      if (data.success) setInvoices(data.data || []);
    } catch {} finally { setLoadingList(false); }
  };

  // ── Generate from DB ──────────────────────────────────────────────
  const handleGenerate = async () => {
    if (!shipmentId) { setError("Please enter a Shipment ID"); return; }
    setGenerating(true); setError(null); setPdfUrl(null);
    try {
      const response = await axios.get(
        `${API_BASE}/invoice/generate/${shipmentId}`,
        { responseType: "blob" });
      const url = URL.createObjectURL(new Blob([response.data],{type:"application/pdf"}));
      setPdfUrl(url);
      setPdfFileName(`invoice_${shipmentId}.pdf`);
    } catch (err) {
      setError("Could not generate invoice — check shipment ID");
    } finally { setGenerating(false); }
  };

  // ── Generate + auto upload ─────────────────────────────────────────
  const handleGenerateAndUpload = async () => {
    if (!shipmentId) { setError("Please enter a Shipment ID"); return; }
    setGenerating(true); setError(null); setUploadResult(null);
    try {
      // Step 1: Get generated PDF
      const genRes = await axios.get(
        `${API_BASE}/invoice/generate/${shipmentId}`,
        { responseType: "blob" });

      // Step 2: Upload it
      const formData = new FormData();
      formData.append("file", new File(
        [genRes.data],
        `INV_${invoiceType}_${shipmentId}.pdf`,
        { type: "application/pdf" }));
      formData.append("shipmentId", shipmentId);
      formData.append("type", invoiceType);

      const upRes = await axios.post(`${API_BASE}/invoice/upload`, formData,
        { headers: { "Content-Type": "multipart/form-data" } });

      setUploadResult(upRes.data.data);
      if (upRes.data.success) {
        await loadAllInvoices();
        setTab("history");
      } else {
        setError(upRes.data.message);
      }
    } catch (err) {
      setError(err.response?.data?.message || "Generate + Upload failed");
    } finally { setGenerating(false); }
  };

  // ── Manual Upload ──────────────────────────────────────────────────
  const handleUpload = async () => {
    if (!file || !shipmentId) { setError("Please select a PDF and enter Shipment ID"); return; }
    setUploading(true); setError(null); setUploadResult(null);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("shipmentId", shipmentId);
    formData.append("type", invoiceType);
    try {
      const { data } = await axios.post(`${API_BASE}/invoice/upload`, formData,
        { headers: { "Content-Type": "multipart/form-data" } });
      setUploadResult(data.data);
      if (data.success) { setFile(null); await loadAllInvoices(); }
      else setError(data.message);
    } catch (err) {
      setError(err.response?.data?.message || "Upload failed");
    } finally { setUploading(false); }
  };

  const handleFetch = async () => {
    setFetching(true); setFetchResult(null);
    try {
      const { data } = await axios.post(`${API_BASE}/invoice/fetch`);
      setFetchResult(data.data);
      await loadAllInvoices();
    } catch { setError("Fetch failed"); } finally { setFetching(false); }
  };

  const handleView = async (id) => {
    try {
      const r = await axios.get(`${API_BASE}/invoice/view/${id}`,{responseType:"blob"});
      setPdfUrl(URL.createObjectURL(new Blob([r.data],{type:"application/pdf"})));
      setPdfFileName("invoice_"+id+".pdf");
    } catch { setError("Could not load PDF"); }
  };

  const handleDownload = async (id) => {
    try {
      const r = await axios.get(`${API_BASE}/invoice/download/${id}`,{responseType:"blob"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(r.data);
      a.download = `invoice_${id}.pdf`;
      a.click();
    } catch { setError("Download failed"); }
  };

  const handleRetry = async (id) => {
    try { await axios.post(`${API_BASE}/invoice/retry/${id}`); await loadAllInvoices(); }
    catch { setError("Retry failed"); }
  };

  const downloadGenerated = () => {
    if (!pdfUrl) return;
    const a = document.createElement("a");
    a.href = pdfUrl; a.download = pdfFileName; a.click();
  };

  const sentCount     = invoices.filter(i=>i.ftpStatus==="SENT").length;
  const receivedCount = invoices.filter(i=>i.ftpStatus==="RECEIVED").length;
  const failedCount   = invoices.filter(i=>i.ftpStatus==="FAILED").length;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto">

        <div className="mb-5">
          <h1 className="text-2xl font-bold text-gray-900">Invoice Management</h1>
          <p className="text-sm text-gray-400 mt-0.5">Generate · Upload · Download</p>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-3 gap-3 mb-5">
          {[
            {label:"Sent",     count:sentCount,     color:"text-green-600"},
            {label:"Received", count:receivedCount, color:"text-blue-600"},
            {label:"Failed",   count:failedCount,   color:"text-red-600"},
          ].map(c=>(
            <div key={c.label} className="bg-white rounded-xl border border-gray-200 p-4">
              <p className="text-xs text-gray-400">{c.label}</p>
              <p className={`text-2xl font-bold mt-1 ${c.color}`}>{c.count}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-100 p-1 rounded-xl mb-5 w-fit">
          {[
            {id:"generate", label:"📄 Generate"},
            {id:"upload",   label:"↑ Upload"},
            {id:"history",  label:"📋 History"},
          ].map(t=>(
            <button key={t.id} onClick={()=>{setTab(t.id);setError(null);}}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
                ${tab===t.id?"bg-white shadow text-gray-900":"text-gray-500 hover:text-gray-700"}`}>
              {t.label}
            </button>
          ))}
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {/* ── TAB: GENERATE ─────────────────────────────────────── */}
        {tab==="generate" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="space-y-4">
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h2 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">
                  Generate from Shipment Data
                </h2>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Shipment ID</label>
                    <input type="number" value={shipmentId}
                      onChange={e=>setShipmentId(e.target.value)}
                      placeholder="e.g. 164"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                                 focus:outline-none focus:border-blue-400"/>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Invoice Type</label>
                    <select value={invoiceType} onChange={e=>setInvoiceType(e.target.value)}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                                 focus:outline-none focus:border-blue-400 bg-white">
                      <option value="EXP">EXP — Export</option>
                      <option value="IMP">IMP — Import</option>
                    </select>
                  </div>
                </div>

                {/* Info box */}
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-xs font-semibold text-blue-700 mb-1">Invoice includes:</p>
                  <div className="text-xs text-blue-600 space-y-0.5">
                    <p>✓ Sender + Receiver full address</p>
                    <p>✓ All invoice line items with HS codes</p>
                    <p>✓ Quantities, prices, weights</p>
                    <p>✓ Customs info (incoterms, clearance)</p>
                    <p>✓ Declaration + signature field</p>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button onClick={handleGenerate} disabled={generating||!shipmentId}
                    className="flex-1 bg-gray-700 hover:bg-gray-800 disabled:bg-gray-300
                               text-white font-medium rounded-xl py-2.5 text-sm">
                    {generating?"Generating...":"👁 Preview"}
                  </button>
                  <button onClick={handleGenerateAndUpload} disabled={generating||!shipmentId}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300
                               text-white font-medium rounded-xl py-2.5 text-sm">
                    {generating?"Working...":"↑ Generate + Upload"}
                  </button>
                </div>
              </div>

              {uploadResult && (
                <div className={`rounded-xl border p-4
                  ${uploadResult.success?"bg-green-50 border-green-200":"bg-red-50 border-red-200"}`}>
                  <p className={`text-sm font-medium ${uploadResult.success?"text-green-700":"text-red-700"}`}>
                    {uploadResult.success ? "✓ Uploaded to Chronopost" : "✗ Upload Failed"}
                  </p>
                  {uploadResult.fileName && (
                    <p className="text-xs font-mono mt-1 text-gray-600">{uploadResult.fileName}</p>
                  )}
                </div>
              )}
            </div>

            {/* PDF Preview */}
            <div>
              {pdfUrl ? (
                <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                  <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-700">{pdfFileName}</p>
                    <div className="flex gap-2">
                      <button onClick={downloadGenerated}
                        className="px-3 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700">
                        ↓ Download
                      </button>
                      <button onClick={()=>setPdfUrl(null)}
                        className="text-xs text-gray-400 hover:text-gray-600">✕</button>
                    </div>
                  </div>
                  <iframe src={pdfUrl} className="w-full" style={{height:"520px"}} title="Invoice"/>
                </div>
              ) : (
                <div className="bg-white rounded-xl border border-dashed border-gray-300
                                p-16 text-center h-full flex flex-col items-center justify-center">
                  <div className="text-5xl text-gray-300 mb-4">📄</div>
                  <p className="text-sm text-gray-400">Enter Shipment ID and click Preview</p>
                  <p className="text-xs text-gray-300 mt-2">
                    Invoice PDF will appear here ready to download or upload
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB: UPLOAD ───────────────────────────────────────── */}
        {tab==="upload" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="space-y-4">
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h2 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">
                  Upload Your Own Invoice PDF
                </h2>
                <div className="space-y-3 mb-4">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Shipment ID</label>
                    <input type="number" value={shipmentId}
                      onChange={e=>setShipmentId(e.target.value)} placeholder="e.g. 164"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                                 focus:outline-none focus:border-blue-400"/>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Invoice Type</label>
                    <select value={invoiceType} onChange={e=>setInvoiceType(e.target.value)}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                                 focus:outline-none focus:border-blue-400 bg-white">
                      <option value="EXP">EXP — Export</option>
                      <option value="IMP">IMP — Import</option>
                    </select>
                  </div>
                </div>

                <DropZone file={file} onFile={setFile}/>

                {file && shipmentId && (
                  <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                    <p className="text-xs text-gray-400">Will be uploaded as:</p>
                    <p className="text-xs font-mono text-gray-700 mt-0.5">
                      INV_{invoiceType}_[account]_[parcelId].PDF
                    </p>
                  </div>
                )}

                <button onClick={handleUpload} disabled={uploading||!file||!shipmentId}
                  className="w-full mt-4 bg-purple-600 hover:bg-purple-700
                             disabled:bg-purple-300 text-white font-medium rounded-xl py-2.5 text-sm">
                  {uploading?"Uploading...":"↑ Upload to Chronopost SFTP"}
                </button>
              </div>

              {uploadResult && (
                <div className={`rounded-xl border p-4
                  ${uploadResult.success?"bg-green-50 border-green-200":"bg-red-50 border-red-200"}`}>
                  <p className={`text-sm font-medium ${uploadResult.success?"text-green-700":"text-red-700"}`}>
                    {uploadResult.success?"✓ Uploaded":"✗ Failed"}
                  </p>
                  {uploadResult.fileName && (
                    <p className="text-xs font-mono mt-1 text-gray-600">{uploadResult.fileName}</p>
                  )}
                  {uploadResult.errors?.map((e,i)=>(
                    <p key={i} className="text-xs text-red-600 mt-1">{e}</p>
                  ))}
                </div>
              )}

              {/* Fetch section */}
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h2 className="text-sm font-semibold text-gray-700 mb-2 uppercase tracking-wide">
                  Fetch from Chronopost
                </h2>
                <p className="text-xs text-gray-400 mb-3">
                  Download invoices from Chronopost SFTP /OUT directory.
                </p>
                <button onClick={handleFetch} disabled={fetching}
                  className="w-full bg-teal-600 hover:bg-teal-700 disabled:bg-teal-300
                             text-white font-medium rounded-xl py-2.5 text-sm">
                  {fetching?"Fetching...":"↓ Fetch from SFTP /OUT"}
                </button>
                {fetchResult && (
                  <div className="mt-3 p-3 bg-teal-50 rounded-lg grid grid-cols-3 gap-2 text-center">
                    {[
                      {label:"Found",      val:fetchResult.totalFound},
                      {label:"Downloaded", val:fetchResult.downloaded},
                      {label:"Failed",     val:fetchResult.failed},
                    ].map(s=>(
                      <div key={s.label}>
                        <p className="text-lg font-bold text-teal-700">{s.val}</p>
                        <p className="text-xs text-teal-500">{s.label}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* PDF Preview */}
            {pdfUrl && (
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-700">{pdfFileName}</p>
                  <button onClick={()=>setPdfUrl(null)}
                    className="text-xs text-gray-400 hover:text-gray-600">✕ Close</button>
                </div>
                <iframe src={pdfUrl} className="w-full" style={{height:"500px"}} title="Invoice"/>
              </div>
            )}
          </div>
        )}

        {/* ── TAB: HISTORY ─────────────────────────────────────── */}
        {tab==="history" && (
          <div className="space-y-4">
            <div className="bg-white rounded-xl border border-gray-200">
              <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
                <h2 className="text-sm font-semibold text-gray-700">Invoice History</h2>
                <button onClick={loadAllInvoices}
                  className="text-xs text-gray-400 hover:text-gray-600">↻ Refresh</button>
              </div>
              <div className="px-4 max-h-96 overflow-y-auto">
                {loadingList ? (
                  <p className="text-xs text-gray-400 py-6 text-center">Loading...</p>
                ) : invoices.length===0 ? (
                  <p className="text-xs text-gray-400 py-6 text-center">No invoices yet</p>
                ) : invoices.map(inv=>(
                  <InvoiceRow key={inv.id} inv={inv}
                    onView={handleView} onDownload={handleDownload} onRetry={handleRetry}/>
                ))}
              </div>
            </div>

            {pdfUrl && (
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="px-5 py-3 border-b border-gray-100 flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-700">{pdfFileName}</p>
                  <button onClick={()=>setPdfUrl(null)}
                    className="text-xs text-gray-400 hover:text-gray-600">✕ Close</button>
                </div>
                <iframe src={pdfUrl} className="w-full" style={{height:"400px"}} title="Invoice"/>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
