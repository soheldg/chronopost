import { useState, useEffect } from "react";
import axios from "axios";

const API = "http://localhost:8080/api";

const InfoRow = ({ label, value, mono=false }) => (
  <div className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0">
    <span className="text-sm text-gray-500">{label}</span>
    <span className={`text-sm font-medium text-gray-800 ${mono?"font-mono":""}`}>{value||"—"}</span>
  </div>
);

export default function LabelPage({ initialShipmentId }) {
  const [shipmentId,      setShipmentId]      = useState(initialShipmentId||"");
  const [parcelDbId,      setParcelDbId]      = useState("");
  const [parcels,         setParcels]         = useState([]);   // parcel list from API
  const [loadingParcels,  setLoadingParcels]  = useState(false);
  const [customerPrefix,  setCustomerPrefix]  = useState("HY712");
  const [geopostSenderId, setGeopostSenderId] = useState("0407112");
  const [clearanceCode,   setClearanceCode]   = useState("HY-DP");

  const [loading, setLoading] = useState(false);
  const [result,  setResult]  = useState(null);
  const [error,   setError]   = useState(null);
  const [pdfUrl,  setPdfUrl]  = useState(null);

  // ── Auto-load parcels when shipmentId changes ──────────────────────
  useEffect(() => {
    if (!shipmentId) { setParcels([]); setParcelDbId(""); return; }
    setLoadingParcels(true);
    setParcels([]);
    setParcelDbId("");
    setResult(null);
    setPdfUrl(null);
    axios.get(`${API}/shipment/${shipmentId}`)
      .then(res => {
        if (res.data.success && res.data.data?.parcels?.length > 0) {
          setParcels(res.data.data.parcels);
          // Auto-select first PENDING parcel
          const pending = res.data.data.parcels.find(p => p.labelStatus === "PENDING");
          if (pending) setParcelDbId(String(pending.id));
          else setParcelDbId(String(res.data.data.parcels[0].id));
        }
      })
      .catch(() => {})
      .finally(() => setLoadingParcels(false));
  }, [shipmentId]);

  const handleGenerate = async () => {
    if (!shipmentId || !parcelDbId) {
      setError("Shipment ID and Parcel ID are required"); return;
    }
    setLoading(true); setError(null); setResult(null); setPdfUrl(null);
    try {
      const { data } = await axios.post(`${API}/label/generate`, {
        shipmentId:           parseInt(shipmentId),
        parcelId:             parseInt(parcelDbId),
        customerPrefix,
        geopostSenderId,
        customsClearanceCode: clearanceCode,
      });
      if (data.success) setResult(data.data);
      else setError(data.message);
    } catch (err) {
      setError(err.response?.data?.message || "Label generation failed");
    } finally { setLoading(false); }
  };

  const handlePreview = async () => {
    if (!result?.parcelDbId) return;
    const r = await axios.get(`${API}/label/preview/${result.parcelDbId}`, { responseType:"blob" });
    setPdfUrl(URL.createObjectURL(new Blob([r.data],{type:"application/pdf"})));
  };

  const handleDownload = async () => {
    if (!result?.parcelDbId) return;
    const r = await axios.get(`${API}/label/download/${result.parcelDbId}`, { responseType:"blob" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(r.data);
    a.download = `label_${result.chronopostParcelId}.pdf`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Label Generator</h1>
          <p className="text-gray-500 text-sm mt-1">
            Routing + product auto-resolved from DB
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">

            {/* Shipment + Parcel */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">
                Shipment + Parcel
              </h2>
              <div className="space-y-3">

                {/* Shipment ID */}
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Shipment ID (DB)</label>
                  <input type="number" value={shipmentId}
                    onChange={e => setShipmentId(e.target.value)}
                    placeholder="e.g. 164"
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                               focus:outline-none focus:border-blue-400"/>
                </div>

                {/* Parcel selector — auto-populated from shipment */}
                <div>
                  <label className="block text-xs text-gray-500 mb-1">
                    Parcel
                    {loadingParcels && <span className="ml-2 text-gray-400">loading...</span>}
                  </label>

                  {parcels.length > 0 ? (
                    <select value={parcelDbId}
                      onChange={e => setParcelDbId(e.target.value)}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                                 focus:outline-none focus:border-blue-400 bg-white">
                      {parcels.map(p => (
                        <option key={p.id} value={p.id}>
                          #{p.id} — Parcel {p.parcelRank}
                          {p.declaredWeight ? ` · ${p.declaredWeight}g` : ""}
                          {p.labelStatus === "GENERATED" ? " ✓ label ready" : ""}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input type="number" value={parcelDbId}
                      onChange={e => setParcelDbId(e.target.value)}
                      placeholder={shipmentId ? "No parcels found" : "Enter Shipment ID first"}
                      className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                                 focus:outline-none focus:border-blue-400"/>
                  )}
                </div>
              </div>
            </div>

            {/* Chronopost credentials */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-sm font-semibold text-gray-700 mb-4 uppercase tracking-wide">
                Chronopost Credentials
              </h2>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Customer Prefix (5 chars)</label>
                  <input value={customerPrefix} onChange={e=>setCustomerPrefix(e.target.value)} maxLength={5}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono
                               focus:outline-none focus:border-blue-400"/>
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Geopost Sender ID (7 chars)</label>
                  <input value={geopostSenderId} onChange={e=>setGeopostSenderId(e.target.value)} maxLength={7}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono
                               focus:outline-none focus:border-blue-400"/>
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Customs Clearance</label>
                  <select value={clearanceCode} onChange={e=>setClearanceCode(e.target.value)}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm
                               focus:outline-none focus:border-blue-400 bg-white">
                    <option value="HY-DP">HY-DP — Duty Paid</option>
                    <option value="HY-NP">HY-NP — Not Paid</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Auto info */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <p className="text-xs font-semibold text-blue-700 mb-2">Auto-resolved from DB</p>
              <div className="space-y-1 text-xs text-blue-600">
                <p>✓ Product suffix + service code ← CHR_PRODUCTS (by parcel weight)</p>
                <p>✓ OrigSort, DistribSort ← CHR_ROUTING (by country + zip)</p>
                <p>✓ Numerical country code ← CHR_ROUTING</p>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            <button onClick={handleGenerate} disabled={loading || !shipmentId || !parcelDbId}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300
                         text-white font-medium rounded-xl py-3 text-sm">
              {loading ? "Generating..." : "🏷️ Generate Label"}
            </button>
          </div>

          {/* Result + Preview */}
          <div className="space-y-4">
            {result && (
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Generated</h2>
                  <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded text-xs font-medium">
                    {result.labelStatus}
                  </span>
                </div>
                <InfoRow label="Parcel ID"        value={result.chronopostParcelId} mono/>
                <InfoRow label="Geopost Track ID"  value={result.geopostTrackingId}  mono/>
                <InfoRow label="Routing Barcode"   value={result.routingBarcodeDisplay} mono/>
                <InfoRow label="Generated At"      value={result.generatedAt?.substring(0,19).replace("T"," ")}/>
                <div className="flex gap-3 mt-5">
                  <button onClick={handlePreview}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700
                               font-medium rounded-lg py-2 text-sm">Preview</button>
                  <button onClick={handleDownload}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white
                               font-medium rounded-lg py-2 text-sm">↓ Download</button>
                </div>
              </div>
            )}

            {pdfUrl && (
              <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
                <div className="px-5 py-3 border-b border-gray-100">
                  <h2 className="text-sm font-semibold text-gray-700">Label Preview</h2>
                </div>
                <iframe src={pdfUrl} className="w-full" style={{height:"500px"}} title="Label"/>
              </div>
            )}

            {!result && !loading && (
              <div className="bg-white rounded-xl border border-dashed border-gray-300 p-12 text-center">
                <div className="text-gray-400 text-4xl mb-3">🏷️</div>
                <p className="text-sm text-gray-500">
                  {shipmentId && parcels.length === 0 && !loadingParcels
                    ? "No parcels found for this shipment"
                    : "Select shipment and parcel, then generate"}
                </p>
              </div>
            )}
            {loading && (
              <div className="bg-white rounded-xl border border-gray-200 p-12 text-center">
                <div className="animate-spin text-3xl mb-3">⟳</div>
                <p className="text-sm text-gray-500">Generating barcode and PDF...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
