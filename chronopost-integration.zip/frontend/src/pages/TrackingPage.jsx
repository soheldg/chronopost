import { useState, useEffect } from "react";
import axios from "axios";

const API_BASE = "http://localhost:8080/api";

// ─── Event code → icon + color ─────────────────────────────
// FIX: Corrected event codes from Evenements_Chronopost_2023-06-30.xlsx
// Real codes: D=Delivered, N=Not delivered, P=Failed(absent), R=Returned
const EVENT_STYLE = {
  // ── DELIVERED ──────────────────────────────────────────────────
  D:  { icon:"✓",  color:"text-green-600",  bg:"bg-green-100",  dot:"bg-green-500" },
  D1: { icon:"✓",  color:"text-green-600",  bg:"bg-green-100",  dot:"bg-green-500" },
  D6: { icon:"✓",  color:"text-green-600",  bg:"bg-green-100",  dot:"bg-green-500" },
  D7: { icon:"✓",  color:"text-green-600",  bg:"bg-green-100",  dot:"bg-green-500" },
  RG: { icon:"✓",  color:"text-green-600",  bg:"bg-green-100",  dot:"bg-green-500" },
  RI: { icon:"✓",  color:"text-green-600",  bg:"bg-green-100",  dot:"bg-green-500" },
  U:  { icon:"✓",  color:"text-green-600",  bg:"bg-green-100",  dot:"bg-green-500" },
  // ── IN TRANSIT ─────────────────────────────────────────────────
  SM: { icon:"→",  color:"text-blue-600",   bg:"bg-blue-100",   dot:"bg-blue-500" },
  PC: { icon:"📦", color:"text-blue-600",   bg:"bg-blue-50",    dot:"bg-blue-400" },
  TS: { icon:"→",  color:"text-blue-600",   bg:"bg-blue-50",    dot:"bg-blue-400" },
  TP: { icon:"→",  color:"text-blue-600",   bg:"bg-blue-50",    dot:"bg-blue-400" },
  TI: { icon:"⬤",  color:"text-blue-500",   bg:"bg-blue-50",    dot:"bg-blue-400" },
  TO: { icon:"⬤",  color:"text-blue-500",   bg:"bg-blue-50",    dot:"bg-blue-400" },
  OD: { icon:"🚚", color:"text-blue-600",   bg:"bg-blue-50",    dot:"bg-blue-400" },
  TA: { icon:"🚚", color:"text-blue-600",   bg:"bg-blue-50",    dot:"bg-blue-400" },
  E:  { icon:"✓",  color:"text-teal-600",   bg:"bg-teal-50",    dot:"bg-teal-400" },
  // ── FAILED ─────────────────────────────────────────────────────
  P:  { icon:"!",  color:"text-orange-600", bg:"bg-orange-100", dot:"bg-orange-500" },  // FIX: was AT
  N:  { icon:"✗",  color:"text-red-600",    bg:"bg-red-100",    dot:"bg-red-500" },     // FIX: was ND
  AT: { icon:"!",  color:"text-orange-600", bg:"bg-orange-100", dot:"bg-orange-500" },  // alias
  HO: { icon:"⏸",  color:"text-yellow-600", bg:"bg-yellow-100", dot:"bg-yellow-500" },
  // ── RETURNED ───────────────────────────────────────────────────
  R:  { icon:"↩",  color:"text-gray-600",   bg:"bg-gray-100",   dot:"bg-gray-500" },    // FIX: was RT
  RT: { icon:"↩",  color:"text-gray-600",   bg:"bg-gray-100",   dot:"bg-gray-500" },    // alias
  // ── AVAILABLE ──────────────────────────────────────────────────
  IP: { icon:"🏪", color:"text-purple-600", bg:"bg-purple-100", dot:"bg-purple-500" },
  MD: { icon:"🏪", color:"text-purple-600", bg:"bg-purple-100", dot:"bg-purple-500" },
  // ── DEFAULT ────────────────────────────────────────────────────
  DEFAULT: { icon:"·", color:"text-gray-500", bg:"bg-gray-100", dot:"bg-gray-400" },
};

const getStyle = (code) =>
  EVENT_STYLE[code?.toUpperCase()] || EVENT_STYLE.DEFAULT;

// ─── Dashboard card ────────────────────────────────────────
const DashCard = ({ label, count, color, onClick }) => (
  <div
    onClick={onClick}
    className={`bg-white rounded-xl border border-gray-200 p-4
                cursor-pointer hover:shadow-md transition-shadow`}
  >
    <p className="text-xs text-gray-400 mb-1">{label}</p>
    <p className={`text-3xl font-bold ${color}`}>
      {count ?? "—"}
    </p>
  </div>
);

// ─── Timeline event row ─────────────────────────────────────
const TimelineEvent = ({ event, isLast }) => {
  const style = getStyle(event.eventCode);
  return (
    <div className="flex gap-3">
      {/* Dot + line */}
      <div className="flex flex-col items-center">
        <div className={`w-8 h-8 rounded-full flex items-center
                         justify-center text-sm font-bold
                         ${style.bg} ${style.color} shrink-0`}>
          {style.icon}
        </div>
        {!isLast && (
          <div className="w-0.5 bg-gray-200 flex-1 mt-1 mb-1 min-h-4" />
        )}
      </div>
      {/* Content */}
      <div className={`pb-4 flex-1 ${isLast ? "" : ""}`}>
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-gray-800">
              {event.eventDescription}
            </p>
            {event.location && (
              <p className="text-xs text-gray-400 mt-0.5">
                📍 {event.location}
              </p>
            )}
            {event.deliveryInstruction && (
              <p className="text-xs text-blue-600 mt-0.5">
                ↳ {event.instructionDescription ||
                    event.deliveryInstruction}
              </p>
            )}
            {event.deskClerk && (
              <p className="text-xs text-gray-400 mt-0.5">
                👤 {event.deskClerk}
              </p>
            )}
          </div>
          <div className="text-right ml-4 shrink-0">
            {event.eventDate && (
              <p className="text-xs font-medium text-gray-600">
                {event.eventDate}
              </p>
            )}
            {event.eventTime && (
              <p className="text-xs text-gray-400 mt-0.5">
                {event.eventTime.substring(0, 2)}:
                {event.eventTime.substring(2, 4)}
              </p>
            )}
          </div>
        </div>
        {/* Extra info row */}
        <div className="flex gap-3 mt-1.5">
          {event.eventCode && (
            <span className={`text-xs px-1.5 py-0.5 rounded font-mono
                              ${style.bg} ${style.color}`}>
              {event.eventCode}
            </span>
          )}
          {event.reasonCode && (
            <span className="text-xs px-1.5 py-0.5 rounded bg-gray-100
                             text-gray-600 font-mono">
              {event.reasonCode}
            </span>
          )}
          {event.weight && (
            <span className="text-xs text-gray-400">{event.weight} kg</span>
          )}
          {event.channel && (
            <span className="text-xs text-gray-400">
              {event.channel === "MAIL" ? "✉" : "💬"} {event.channel}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

// ─── Parcel tracking card ──────────────────────────────────
const ParcelTrackingCard = ({ tracking }) => {
  const [expanded, setExpanded] = useState(false);
  const latestEvent = tracking.events?.[0];
  const style = getStyle(latestEvent?.eventCode);

  return (
    <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4
                   cursor-pointer hover:bg-gray-50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div>
          <div className="flex items-center gap-2">
            <p className="text-sm font-mono font-medium text-gray-800">
              {tracking.parcelNumber}
            </p>
            {// FIX: isDelivered now checks 'D' code (not 'DL')
              tracking.isDelivered && (
              <span className="text-xs bg-green-100 text-green-700
                               px-2 py-0.5 rounded font-medium">
                Delivered
              </span>
            )}
          </div>
          <p className="text-xs text-gray-400 mt-0.5">
            Geopost: {tracking.geopostTrackingId || "—"} ·{" "}
            {tracking.totalEvents} event{tracking.totalEvents !== 1 ? "s" : ""}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-1.5 px-2.5 py-1
                           rounded-full text-xs font-medium
                           ${style.bg} ${style.color}`}>
            <span>{style.icon}</span>
            <span>{tracking.currentStatus}</span>
          </div>
          <span className="text-gray-400 text-xs">
            {expanded ? "▲" : "▼"}
          </span>
        </div>
      </div>

      {/* Timeline */}
      {expanded && (
        <div className="border-t border-gray-100 px-5 py-4">
          {tracking.events && tracking.events.length > 0 ? (
            tracking.events.map((event, i) => (
              <TimelineEvent
                key={i}
                event={event}
                isLast={i === tracking.events.length - 1}
              />
            ))
          ) : (
            <p className="text-sm text-gray-400 py-4 text-center">
              No tracking events yet
            </p>
          )}
        </div>
      )}
    </div>
  );
};

// ─── Main Tracking Page ─────────────────────────────────────
export default function TrackingPage() {
  const [dashboard, setDashboard] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [trackingData, setTrackingData] = useState(null);
  const [shipmentId, setShipmentId] = useState("");
  const [polling, setPolling] = useState(false);
  const [pollResult, setPollResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Load dashboard on mount
  useEffect(() => { loadDashboard(); }, []);

  const loadDashboard = async () => {
    try {
      const { data } = await axios.get(`${API_BASE}/tracking/dashboard`);
      if (data.success) setDashboard(data.data);
    } catch { /* silent */ }
  };

  // ─── Search ─────────────────────────────────────────────
  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setLoading(true);
    setError(null);
    setTrackingData(null);
    setSearchResults([]);

    try {
      const { data } = await axios.get(
        `${API_BASE}/tracking/search?q=${encodeURIComponent(searchQuery)}`);
      if (data.success) setSearchResults(data.data || []);
      else setError("No results found");
    } catch (err) {
      setError(err.response?.data?.message || "Search failed");
    } finally {
      setLoading(false);
    }
  };

  // ─── Load parcel tracking ──────────────────────────────
  const loadParcelTracking = async (parcelNumber) => {
    setLoading(true);
    setError(null);
    try {
      const { data } = await axios.get(
        `${API_BASE}/tracking/${parcelNumber}`);
      if (data.success) setTrackingData(data.data);
    } catch (err) {
      setError("Could not load tracking data");
    } finally {
      setLoading(false);
    }
  };

  // ─── Load shipment tracking ────────────────────────────
  const loadShipmentTracking = async () => {
    if (!shipmentId) return;
    setLoading(true);
    setError(null);
    setTrackingData(null);
    try {
      const { data } = await axios.get(
        `${API_BASE}/tracking/shipment/${shipmentId}`);
      if (data.success) setTrackingData(data.data);
    } catch (err) {
      setError("Could not load shipment tracking");
    } finally {
      setLoading(false);
    }
  };

  // ─── Poll FTP ──────────────────────────────────────────
  const handlePoll = async () => {
    setPolling(true);
    setPollResult(null);
    try {
      const { data } = await axios.post(`${API_BASE}/tracking/poll`);
      if (data.success) {
        setPollResult(data.data);
        await loadDashboard();
      }
    } catch (err) {
      setError("Poll failed");
    } finally {
      setPolling(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto">

        {/* ─── Header ─────────────────────────────────── */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              Tracking Dashboard
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              Real-time shipment tracking from Chronopost
            </p>
          </div>
          <button
            onClick={handlePoll}
            disabled={polling}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600
                       hover:bg-blue-700 disabled:bg-blue-300 text-white
                       font-medium rounded-xl text-sm transition-colors"
          >
            <span className={polling ? "animate-spin" : ""}>↻</span>
            {polling ? "Polling FTP..." : "Poll FTP Now"}
          </button>
        </div>

        {/* ─── Poll result ──────────────────────────── */}
        {pollResult && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl
                          p-4 mb-5">
            <div className="flex items-center gap-6 text-sm">
              <span className="text-blue-700 font-medium">
                Poll complete
              </span>
              {[
                { label: "Files found",   val: pollResult.filesFound },
                { label: "Processed",     val: pollResult.filesProcessed },
                { label: "Events",        val: pollResult.totalEventsProcessed },
                { label: "Failed",        val: pollResult.filesFailed },
              ].map(s => (
                <span key={s.label} className="text-blue-600">
                  {s.label}: <strong>{s.val}</strong>
                </span>
              ))}
            </div>
          </div>
        )}

        {/* ─── Dashboard cards ──────────────────────── */}
        {dashboard && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
            <DashCard label="Total"     count={dashboard.totalShipments}
                      color="text-gray-800" />
            <DashCard label="Delivered" count={dashboard.delivered}
                      color="text-green-600" />
            <DashCard label="In Transit" count={dashboard.inTransit}
                      color="text-blue-600" />
            <DashCard label="Failed"    count={dashboard.failed}
                      color="text-orange-600" />
            <DashCard label="Returned"  count={dashboard.returned}
                      color="text-gray-500" />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* ─── Left: Search panel ──────────────────── */}
          <div className="space-y-4">

            {/* Parcel / tracking no search */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-xs font-semibold text-gray-500 uppercase
                             tracking-wide mb-3">
                Search Parcel
              </h2>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleSearch()}
                  placeholder="Parcel no / tracking no"
                  className="flex-1 border border-gray-200 rounded-lg px-3
                             py-2 text-sm font-mono focus:outline-none
                             focus:border-blue-400"
                />
                <button
                  onClick={handleSearch}
                  disabled={loading || !searchQuery}
                  className="px-3 py-2 bg-gray-800 text-white rounded-lg
                             text-sm hover:bg-gray-700 disabled:opacity-50"
                >
                  ↵
                </button>
              </div>

              {/* Search results */}
              {searchResults.length > 0 && (
                <div className="mt-3 space-y-2">
                  {searchResults.map((r, i) => (
                    <button
                      key={i}
                      onClick={() => loadParcelTracking(r.parcelNumber)}
                      className="w-full text-left p-3 bg-gray-50
                                 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <p className="text-xs font-mono font-medium
                                   text-gray-800">
                        {r.parcelNumber}
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {r.latestStatus} · {r.totalEvents} events
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Shipment lookup */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-xs font-semibold text-gray-500 uppercase
                             tracking-wide mb-3">
                By Shipment ID
              </h2>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={shipmentId}
                  onChange={e => setShipmentId(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && loadShipmentTracking()}
                  placeholder="e.g. 1001"
                  className="flex-1 border border-gray-200 rounded-lg px-3
                             py-2 text-sm focus:outline-none
                             focus:border-blue-400"
                />
                <button
                  onClick={loadShipmentTracking}
                  disabled={loading || !shipmentId}
                  className="px-3 py-2 bg-gray-800 text-white rounded-lg
                             text-sm hover:bg-gray-700 disabled:opacity-50"
                >
                  ↵
                </button>
              </div>
            </div>

            {/* Event code legend */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-xs font-semibold text-gray-500 uppercase
                             tracking-wide mb-3">
                Event Codes
              </h2>
              <div className="space-y-1.5">
                {[
                  // FIX: Using real Chronopost event codes
                  { code: "D",  label: "Delivered" },
                  { code: "D1", label: "Delivered in mailbox" },
                  { code: "SM", label: "In transit / scanned" },
                  { code: "TA", label: "Out for delivery" },
                  { code: "P",  label: "Delivery failed (absent)" },
                  { code: "N",  label: "Not delivered" },
                  { code: "HO", label: "Held at depot" },
                  { code: "R",  label: "Returned to sender" },
                  { code: "IP", label: "Left at post office" },
                  { code: "E",  label: "Released from customs" },
                ].map(({ code, label }) => {
                  const s = getStyle(code);
                  return (
                    <div key={code}
                         className="flex items-center gap-2">
                      <span className={`w-6 h-6 rounded flex items-center
                                       justify-center text-xs font-bold
                                       ${s.bg} ${s.color}`}>
                        {s.icon}
                      </span>
                      <span className="text-xs font-mono text-gray-600">
                        {code}
                      </span>
                      <span className="text-xs text-gray-400">{label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ─── Right: Tracking timeline ──────────── */}
          <div className="lg:col-span-2 space-y-4">

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            )}

            {loading && (
              <div className="bg-white rounded-xl border border-gray-200
                              p-12 text-center">
                <p className="text-sm text-gray-400">Loading tracking data…</p>
              </div>
            )}

            {/* Single parcel result */}
            {!loading && trackingData && !Array.isArray(trackingData) && (
              <ParcelTrackingCard
                tracking={trackingData}
              />
            )}

            {/* Multiple parcels (shipment result) */}
            {!loading && Array.isArray(trackingData) && (
              trackingData.length === 0 ? (
                <div className="bg-white rounded-xl border border-gray-200
                                p-8 text-center">
                  <p className="text-sm text-gray-400">
                    No parcels found for this shipment
                  </p>
                </div>
              ) : (
                trackingData.map((t, i) => (
                  <ParcelTrackingCard key={i} tracking={t} />
                ))
              )
            )}

            {/* Empty state */}
            {!loading && !trackingData && !error && (
              <div className="bg-white rounded-xl border border-dashed
                              border-gray-300 p-14 text-center">
                <div className="text-4xl text-gray-300 mb-3">📍</div>
                <p className="text-sm text-gray-500">
                  Search for a parcel or shipment to see tracking events
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  Auto-updated every 30 minutes from Chronopost FTP
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
