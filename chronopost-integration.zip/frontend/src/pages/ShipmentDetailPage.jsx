import { useState, useEffect } from "react";
import axios from "axios";

const API = "http://localhost:8080/api";

const STATUS_META = {
  CREATED:      { label:"Created",        cls:"bg-gray-100 text-gray-600"   },
  LABEL_READY:  { label:"Label Ready",    cls:"bg-blue-100 text-blue-700"   },
  PREALERT_SENT:{ label:"Pre-Alert Sent", cls:"bg-purple-100 text-purple-700"},
  INVOICE_SENT: { label:"Invoice Sent",   cls:"bg-teal-100 text-teal-700"   },
  IN_TRANSIT:   { label:"In Transit",     cls:"bg-yellow-100 text-yellow-700"},
  DELIVERED:    { label:"Delivered",      cls:"bg-green-100 text-green-700" },
  FAILED:       { label:"Failed",         cls:"bg-red-100 text-red-700"     },
};

const Section = ({ title, icon, children, onEdit }) => (
  <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
    <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100 bg-gray-50">
      <div className="flex items-center gap-2">
        <span className="text-base">{icon}</span>
        <h3 className="text-sm font-semibold text-gray-700">{title}</h3>
      </div>
      {onEdit && (
        <button onClick={onEdit}
          className="text-xs text-blue-600 hover:text-blue-800 border
                     border-blue-200 rounded px-2 py-0.5 hover:bg-blue-50">
          ✏️ Edit
        </button>
      )}
    </div>
    <div className="p-5">{children}</div>
  </div>
);

const InfoRow = ({ label, value, mono, badge }) => (
  <div className="flex items-start justify-between py-2 border-b border-gray-50 last:border-0">
    <span className="text-xs text-gray-400 shrink-0 w-36">{label}</span>
    <span className={`text-sm text-right ${mono ? "font-mono text-gray-700" : "text-gray-800 font-medium"}`}>
      {badge ? (
        <span className={`px-2 py-0.5 rounded text-xs font-medium ${STATUS_META[value]?.cls||""}`}>
          {STATUS_META[value]?.label || value}
        </span>
      ) : (value || "—")}
    </span>
  </div>
);

// ── Edit modal for a section ──────────────────────────────────────
const EditModal = ({ title, fields, values, onSave, onClose, loading }) => {
  const [form, setForm] = useState({ ...values });
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="font-semibold text-gray-800">Edit {title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>
        <div className="p-6 space-y-4 max-h-[60vh] overflow-y-auto">
          {fields.map(f => (
            <div key={f.key}>
              <label className="block text-xs text-gray-500 mb-1">
                {f.label}{f.required && <span className="text-red-500 ml-0.5">*</span>}
              </label>
              {f.type === "select" ? (
                <select value={form[f.key]||""}
                  onChange={e => setForm(prev=>({...prev,[f.key]:e.target.value}))}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2
                             text-sm focus:outline-none focus:border-blue-400 bg-white">
                  {f.options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              ) : (
                <input type={f.type||"text"} value={form[f.key]||""}
                  onChange={e => setForm(prev=>({...prev,[f.key]:e.target.value}))}
                  maxLength={f.max}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2
                             text-sm focus:outline-none focus:border-blue-400"/>
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-end gap-3 px-6 py-4 border-t border-gray-100 bg-gray-50">
          <button onClick={onClose}
            className="px-4 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-100">
            Cancel
          </button>
          <button onClick={() => onSave(form)} disabled={loading}
            className="px-5 py-2 bg-blue-600 text-white rounded-lg text-sm
                       font-medium hover:bg-blue-700 disabled:opacity-50">
            {loading ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
};

// ── Workflow progress bar ─────────────────────────────────────────
const WORKFLOW = [
  { key:"CREATED",       label:"Created",    icon:"📝" },
  { key:"LABEL_READY",   label:"Label",      icon:"🏷️"  },
  { key:"PREALERT_SENT", label:"Pre-Alert",  icon:"📡" },
  { key:"INVOICE_SENT",  label:"Invoice",    icon:"📋" },
  { key:"IN_TRANSIT",    label:"In Transit", icon:"🚛" },
  { key:"DELIVERED",     label:"Delivered",  icon:"✅" },
];

const WorkflowBar = ({ status }) => {
  const idx = WORKFLOW.findIndex(w => w.key === status);
  return (
    <div className="flex items-center">
      {WORKFLOW.map((step, i) => {
        const done = i < idx;
        const active = i === idx;
        const fail = status === "FAILED" && i === idx;
        return (
          <div key={step.key} className="flex items-center flex-1">
            <div className="flex flex-col items-center">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center
                              text-sm transition-all ${
                done    ? "bg-green-500 text-white" :
                active  ? "bg-blue-600 text-white ring-4 ring-blue-100" :
                "bg-gray-200 text-gray-400"}`}>
                {done ? "✓" : step.icon}
              </div>
              <p className={`text-xs mt-1 font-medium whitespace-nowrap ${
                done ? "text-green-600" : active ? "text-blue-600" : "text-gray-400"
              }`}>{step.label}</p>
            </div>
            {i < WORKFLOW.length-1 && (
              <div className={`flex-1 h-0.5 mt-[-10px] ${i < idx ? "bg-green-400" : "bg-gray-200"}`}/>
            )}
          </div>
        );
      })}
    </div>
  );
};

// ── Main Component ─────────────────────────────────────────────────
export default function ShipmentDetailPage({ shipmentId, onBack, onNavigate }) {
  const [shipment, setShipment] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editSection, setEditSection] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState(null);

  useEffect(() => { if (shipmentId) loadShipment(); }, [shipmentId]);

  const loadShipment = async () => {
    setLoading(true);
    try {
      const { data } = await axios.get(`${API}/shipment/${shipmentId}`);
      if (data.success) setShipment(data.data);
      else setError(data.message);
    } catch { setError("Failed to load shipment"); }
    finally { setLoading(false); }
  };

  const handleSave = async (section, values) => {
    setSaving(true);
    try {
      await axios.put(`${API}/shipment/${shipmentId}/${section}`, values);
      setSaveMsg("Saved successfully");
      setEditSection(null);
      await loadShipment();
      setTimeout(() => setSaveMsg(null), 3000);
    } catch {
      setSaveMsg("Save failed — please try again");
    } finally { setSaving(false); }
  };

  if (loading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin text-3xl mb-3">⟳</div>
        <p className="text-sm text-gray-400">Loading shipment...</p>
      </div>
    </div>
  );

  if (error || !shipment) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <p className="text-red-500 text-sm mb-3">{error || "Shipment not found"}</p>
        <button onClick={onBack} className="text-sm text-blue-600 underline">← Back to list</button>
      </div>
    </div>
  );

  const s = shipment;
  const sender = s.sender || {};
  const receiver = s.receiver || {};
  const parcels = s.parcels || [];
  const customs = s.customs || {};
  const invoiceLines = s.invoiceLines || [];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto">

        {/* Back + header */}
        <div className="flex items-start justify-between mb-5">
          <div>
            <button onClick={onBack}
              className="text-sm text-gray-400 hover:text-gray-600 flex items-center gap-1 mb-2">
              ← Back to shipments
            </button>
            <h1 className="text-2xl font-bold text-gray-900">
              Shipment #{s.id}
            </h1>
            <p className="text-sm font-mono text-gray-400 mt-0.5">{s.mpsId}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => onNavigate?.("label", { shipmentId: s.id })}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm
                         bg-white hover:bg-gray-50 text-gray-600">
              🏷️ Label
            </button>
            <button onClick={() => onNavigate?.("prealert", { shipmentId: s.id })}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm
                         bg-white hover:bg-gray-50 text-gray-600">
              📡 Pre-Alert
            </button>
            <button onClick={() => onNavigate?.("invoice", { shipmentId: s.id })}
              className="px-3 py-2 border border-gray-200 rounded-lg text-sm
                         bg-white hover:bg-gray-50 text-gray-600">
              📋 Invoice
            </button>
          </div>
        </div>

        {saveMsg && (
          <div className={`mb-4 px-4 py-3 rounded-xl text-sm font-medium
            ${saveMsg.includes("fail") ? "bg-red-50 text-red-700" : "bg-green-50 text-green-700"}`}>
            {saveMsg}
          </div>
        )}

        {/* Workflow */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 mb-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-4">
            Shipment Workflow
          </p>
          <WorkflowBar status={s.status}/>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Shipment info */}
          <Section title="Shipment Info" icon="📦">
            <InfoRow label="Status"        value={s.status}     badge/>
            <InfoRow label="MPSID"         value={s.mpsId}      mono/>
            <InfoRow label="Transport"     value={s.linehaul === "AI" ? "✈ Air" : s.linehaul === "RO" ? "🚛 Road" : "🚢 Sea"}/>
            <InfoRow label="Parcel Count"  value={parcels.length}/>
            <InfoRow label="Total Weight"  value={s.mpsweight ? `${s.mpsweight/10} kg` : "—"}/>
            <InfoRow label="Created"       value={s.createdAt?.substring(0,10)}/>
          </Section>

          {/* Sender */}
          <Section title="Sender" icon="👤"
            onEdit={() => setEditSection("sender")}>
            <InfoRow label="Account No"  value={sender.accountNo} mono/>
            <InfoRow label="Name"        value={sender.companyName || sender.name1}/>
            <InfoRow label="Street"      value={sender.street}/>
            <InfoRow label="City"        value={`${sender.zipcode} ${sender.town}`}/>
            <InfoRow label="Country"     value={sender.countryCode}/>
            <InfoRow label="Phone"       value={sender.phone}/>
            <InfoRow label="Email"       value={sender.email}/>
            <InfoRow label="Type"        value={sender.businessType === "B" ? "Business" : "Private"}/>
          </Section>

          {/* Receiver */}
          <Section title="Receiver" icon="📍"
            onEdit={() => setEditSection("receiver")}>
            <InfoRow label="Name"    value={receiver.name1 || receiver.companyName}/>
            <InfoRow label="Street"  value={receiver.street}/>
            <InfoRow label="City"    value={`${receiver.zipcode} ${receiver.town}`}/>
            <InfoRow label="Country" value={receiver.countryCode}/>
            <InfoRow label="Phone"   value={receiver.phone1}/>
            <InfoRow label="Email"   value={receiver.email}/>
            <InfoRow label="Type"    value={receiver.businessType === "P" ? "Private" : "Business"}/>
          </Section>

          {/* Customs */}
          <Section title="Customs" icon="🛃">
            <InfoRow label="Parcel Type"   value={customs.parcelType === "P" ? "Non-Document" : "Document"}/>
            <InfoRow label="Customs Value" value={customs.customsAmount ? `${customs.customsAmount} ${customs.currency}` : "—"}/>
            <InfoRow label="Incoterms"     value={customs.incoterms}/>
            <InfoRow label="Clearance"     value={customs.clearanceStatus}/>
            <InfoRow label="Reason"        value={customs.reasonForExport === "01" ? "Sale" : customs.reasonForExport === "02" ? "Return" : "Gift"}/>
            <InfoRow label="HS Code (IMP)" value={invoiceLines[0]?.hsCodeRecv} mono/>
          </Section>
        </div>

        {/* Parcels */}
        <div className="mt-4">
          <Section title={`Parcels (${parcels.length})`} icon="📦">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    {["Rank","Parcel Number","Weight","Dimensions","Content","Status"].map(h => (
                      <th key={h} className="text-left text-xs font-semibold text-gray-400
                                             uppercase tracking-wide py-2 pr-4">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {parcels.map((p, i) => (
                    <tr key={i} className="border-b border-gray-50 last:border-0">
                      <td className="py-2.5 pr-4 text-gray-500">#{p.parcelRank || i+1}</td>
                      <td className="py-2.5 pr-4 font-mono text-xs text-blue-700">
                        {p.parcelNumber || "PENDING"}
                      </td>
                      <td className="py-2.5 pr-4 text-gray-600">
                        {p.declaredWeight ? `${p.declaredWeight}g` : "—"}
                      </td>
                      <td className="py-2.5 pr-4 font-mono text-xs text-gray-500">
                        {p.dimension || "—"}
                      </td>
                      <td className="py-2.5 pr-4 text-gray-600 max-w-[180px] truncate">
                        {p.content || "—"}
                      </td>
                      <td className="py-2.5">
                        <span className={`px-2 py-0.5 rounded text-xs font-medium
                          ${p.labelStatus === "GENERATED"
                            ? "bg-green-100 text-green-700"
                            : "bg-gray-100 text-gray-500"}`}>
                          {p.labelStatus || "PENDING"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>
        </div>

        {/* Invoice lines */}
        {invoiceLines.length > 0 && (
          <div className="mt-4">
            <Section title={`Invoice Lines (${invoiceLines.length} items)`} icon="📃">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-100">
                      {["#","Description","Qty","Amount","Origin","HS Import","HS Export","Net/Gross (g)"].map(h => (
                        <th key={h} className="text-left text-xs font-semibold text-gray-400
                                               uppercase tracking-wide py-2 pr-3">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {invoiceLines.map((ln, i) => (
                      <tr key={i} className="border-b border-gray-50 last:border-0">
                        <td className="py-2 pr-3 text-gray-400 text-xs">{i+1}</td>
                        <td className="py-2 pr-3 text-gray-700 max-w-[200px] truncate">{ln.content || "—"}</td>
                        <td className="py-2 pr-3 text-center text-gray-600">{ln.quantity}</td>
                        <td className="py-2 pr-3 text-gray-700 font-medium">{ln.amount ? `€${ln.amount}` : "—"}</td>
                        <td className="py-2 pr-3 text-gray-500">{ln.countryOrigin}</td>
                        <td className="py-2 pr-3 font-mono text-xs text-gray-500">{ln.hsCodeRecv || "—"}</td>
                        <td className="py-2 pr-3 font-mono text-xs text-gray-500">{ln.hsCodeSend || "—"}</td>
                        <td className="py-2 text-xs text-gray-400">{ln.netWeight}/{ln.grossWeight}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Section>
          </div>
        )}
      </div>

      {/* Edit modals */}
      {editSection === "sender" && (
        <EditModal
          title="Sender"
          values={sender}
          fields={[
            { key:"companyName", label:"Company Name", max:35 },
            { key:"name1",       label:"Contact Name", max:35 },
            { key:"street",      label:"Street",       max:35, required:true },
            { key:"zipcode",     label:"Zipcode",      max:9,  required:true },
            { key:"town",        label:"City",         max:35, required:true },
            { key:"phone",       label:"Phone",        max:30 },
            { key:"email",       label:"Email",        max:100 },
          ]}
          onSave={(vals) => handleSave("sender", vals)}
          onClose={() => setEditSection(null)}
          loading={saving}
        />
      )}
      {editSection === "receiver" && (
        <EditModal
          title="Receiver"
          values={receiver}
          fields={[
            { key:"name1",     label:"Receiver Name", max:35, required:true },
            { key:"street",    label:"Street",        max:35, required:true },
            { key:"add2",      label:"Address Line 2",max:35 },
            { key:"zipcode",   label:"Zipcode",       max:9,  required:true },
            { key:"town",      label:"City",          max:35, required:true },
            { key:"phone1",    label:"Phone",         max:30 },
            { key:"email",     label:"Email",         max:100 },
            { key:"doorCode",  label:"Door Code",     max:8 },
          ]}
          onSave={(vals) => handleSave("receiver", vals)}
          onClose={() => setEditSection(null)}
          loading={saving}
        />
      )}
    </div>
  );
}
