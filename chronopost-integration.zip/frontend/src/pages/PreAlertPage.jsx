import { useState } from "react";
import axios from "axios";

const API_BASE = "http://localhost:8080/api";

// ─── Status badge ──────────────────────────────────────────
const StatusBadge = ({ status }) => {
  const map = {
    PENDING:        { cls: "bg-yellow-100 text-yellow-800", label: "Pending" },
    SENT:           { cls: "bg-green-100  text-green-800",  label: "Sent" },
    FAILED:         { cls: "bg-red-100    text-red-800",    label: "Failed" },
    PREALERT_SENT:  { cls: "bg-blue-100   text-blue-800",   label: "Pre-alert Sent" },
  };
  const s = map[status] || map.PENDING;
  return (
    <span className={`px-2 py-1 rounded text-xs font-medium ${s.cls}`}>
      {s.label}
    </span>
  );
};

// ─── Validation error list ─────────────────────────────────
const ErrorList = ({ errors }) => (
  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
    <p className="text-sm font-medium text-red-700 mb-2">
      Validation Errors ({errors.length})
    </p>
    <ul className="space-y-1">
      {errors.map((err, i) => (
        <li key={i} className="text-xs text-red-600 flex gap-2">
          <span className="text-red-400">⚠</span>
          {err}
        </li>
      ))}
    </ul>
  </div>
);

// ─── File preview pane ─────────────────────────────────────
const FilePreview = ({ content, fileName }) => (
  <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
    <div className="px-4 py-3 border-b border-gray-100 flex
                    items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-800">{fileName}</p>
        <p className="text-xs text-gray-400 mt-0.5">
          {content?.split("\n").length} lines ·{" "}
          {(content?.length / 1024).toFixed(1)} KB
        </p>
      </div>
      <button
        onClick={() => navigator.clipboard.writeText(content)}
        className="text-xs text-gray-500 hover:text-gray-700 px-3 py-1
                   border border-gray-200 rounded"
      >
        Copy
      </button>
    </div>
    <pre className="p-4 text-xs text-gray-700 overflow-auto
                    max-h-96 font-mono leading-relaxed bg-gray-50">
      {content}
    </pre>
  </div>
);

// ─── Main Page ─────────────────────────────────────────────
export default function PreAlertPage() {
  const [shipmentId, setShipmentId] = useState("");
  const [loading,    setLoading]    = useState(false);
  const [action,     setAction]     = useState(null); // "generate" | "send"
  const [result,     setResult]     = useState(null);
  const [status,     setStatus]     = useState(null);
  const [error,      setError]      = useState(null);

  const handleAction = async (type) => {
    if (!shipmentId) {
      setError("Please enter a Shipment ID");
      return;
    }

    setLoading(true);
    setAction(type);
    setError(null);
    setResult(null);

    try {
      const endpoint = type === "send"
        ? `${API_BASE}/prealert/send/${shipmentId}`
        : `${API_BASE}/prealert/generate/${shipmentId}`;

      const { data } = await axios.post(endpoint);

      if (data.success) {
        setResult(data.data);
      } else {
        setResult(data.data);
        setError(data.message);
      }
    } catch (err) {
      setError(err.response?.data?.message || "Request failed");
    } finally {
      setLoading(false);
    }
  };

  const handleStatus = async () => {
    if (!shipmentId) return;
    try {
      const { data } = await axios.get(
        `${API_BASE}/prealert/status/${shipmentId}`);
      if (data.success) setStatus(data.data);
    } catch (err) {
      setError("Could not fetch status");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto">

        {/* ─── Header ─────────────────────────────────────── */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            Pre-Alert Manager
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Generate and send GEODATA CONSO file to Chronopost SFTP
          </p>
        </div>

        {/* ─── Control panel ──────────────────────────────── */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 mb-5">
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <label className="block text-xs text-gray-500 mb-1">
                Shipment ID (DB)
              </label>
              <input
                type="number"
                value={shipmentId}
                onChange={e => setShipmentId(e.target.value)}
                placeholder="e.g. 1001"
                className="w-full border border-gray-200 rounded-lg px-3
                           py-2.5 text-sm focus:outline-none
                           focus:border-blue-400"
              />
            </div>

            <button
              onClick={() => handleAction("generate")}
              disabled={loading || !shipmentId}
              className="px-4 py-2.5 bg-gray-100 hover:bg-gray-200
                         disabled:opacity-50 text-gray-700 font-medium
                         rounded-lg text-sm transition-colors whitespace-nowrap"
            >
              {loading && action === "generate"
                ? "Building..." : "Generate File"}
            </button>

            <button
              onClick={() => handleAction("send")}
              disabled={loading || !shipmentId}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700
                         disabled:opacity-50 text-white font-medium
                         rounded-lg text-sm transition-colors whitespace-nowrap"
            >
              {loading && action === "send"
                ? "Sending..." : "Send to Chronopost"}
            </button>

            <button
              onClick={handleStatus}
              disabled={!shipmentId}
              className="px-4 py-2.5 bg-white border border-gray-200
                         hover:bg-gray-50 disabled:opacity-50 text-gray-600
                         font-medium rounded-lg text-sm transition-colors
                         whitespace-nowrap"
            >
              Check Status
            </button>
          </div>
        </div>

        {/* ─── Status card ────────────────────────────────── */}
        {status && (
          <div className="bg-white rounded-xl border border-gray-200
                          p-4 mb-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-800">
                  Shipment {status.mpsId}
                </p>
                <p className="text-xs text-gray-400 mt-0.5">
                  ID: {status.shipmentId}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <StatusBadge status={status.shipmentStatus} />
                {status.prealertSent && (
                  <span className="text-xs text-green-600 font-medium">
                    ✓ Pre-alert sent
                  </span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ─── Main result area ───────────────────────────── */}
        {result && (
          <div className="space-y-4">

            {/* Summary */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-semibold text-gray-700
                               uppercase tracking-wide">
                  Result
                </h2>
                <StatusBadge status={
                  result.ftpStatus || (result.success ? "SENT" : "FAILED")
                }/>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-xs text-gray-400">File Name</p>
                  <p className="font-mono text-xs text-gray-800 mt-0.5
                                break-all">
                    {result.fileName || "—"}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Shipment ID</p>
                  <p className="text-gray-800 mt-0.5">
                    {result.shipmentId}
                  </p>
                </div>
                {result.sentAt && (
                  <div>
                    <p className="text-xs text-gray-400">Sent At</p>
                    <p className="text-gray-800 mt-0.5">
                      {result.sentAt.substring(0, 19).replace("T", " ")}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Validation errors */}
            {result.errors && result.errors.length > 0 && (
              <ErrorList errors={result.errors} />
            )}

            {/* File preview */}
            {result.fileContent && (
              <FilePreview
                content={result.fileContent}
                fileName={result.fileName}
              />
            )}
          </div>
        )}

        {/* ─── Error ──────────────────────────────────────── */}
        {error && !result && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {/* ─── Empty state ────────────────────────────────── */}
        {!result && !loading && !error && (
          <div className="bg-white rounded-xl border border-dashed
                          border-gray-300 p-12 text-center">
            <div className="text-4xl mb-3 text-gray-400">📡</div>
            <p className="text-sm text-gray-500">
              Enter a Shipment ID and generate or send a pre-alert
            </p>
            <p className="text-xs text-gray-400 mt-1">
              File will be validated and uploaded to Chronopost SFTP /IN
            </p>
          </div>
        )}

        {/* ─── File format info ───────────────────────────── */}
        <div className="mt-6 bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-xs font-semibold text-gray-500 uppercase
                         tracking-wide mb-3">
            GEODATA File Structure
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { tag: "#FILE",    desc: "File name" },
              { tag: "#ENCODING",desc: "ISO-8859-1" },
              { tag: "#VERSION", desc: "3.32" },
              { tag: "HEADER",   desc: "CONSO classification" },
              { tag: "CONSOLIDATION", desc: "Transport info" },
              { tag: "SHIPMENT", desc: "Shipment details" },
              { tag: "SENDER",   desc: "Sender address" },
              { tag: "RECEIVER", desc: "Receiver address" },
              { tag: "INTER",    desc: "Customs data" },
              { tag: "INTERINVOICELINE", desc: "Item lines" },
              { tag: "PARCEL",   desc: "Parcel barcodes" },
              { tag: "#END",     desc: "End of file" },
            ].map(item => (
              <div key={item.tag}
                   className="flex items-center gap-2 p-2 bg-gray-50
                              rounded-lg">
                <code className="text-xs font-mono text-blue-700 font-medium
                                 bg-blue-50 px-1.5 py-0.5 rounded">
                  {item.tag}
                </code>
                <span className="text-xs text-gray-500">{item.desc}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
