import { useState } from "react";
import axios from "axios";

const API_BASE = "http://localhost:8080/api";

// ─── Step indicator ────────────────────────────────────────
const steps = [
  { id: 1, label: "Sender",   icon: "👤" },
  { id: 2, label: "Receiver", icon: "📍" },
  { id: 3, label: "Parcel",   icon: "📦" },
  { id: 4, label: "Customs",  icon: "🛃" },
  { id: 5, label: "Review",   icon: "✅" },
];

const StepBar = ({ current }) => (
  <div className="flex items-center gap-0 mb-8">
    {steps.map((s, i) => (
      <div key={s.id} className="flex items-center flex-1">
        <div className="flex flex-col items-center">
          <div className={`w-10 h-10 rounded-full flex items-center
                           justify-center text-sm font-bold transition-colors
                           ${current === s.id
                             ? "bg-blue-600 text-white"
                             : current > s.id
                               ? "bg-green-500 text-white"
                               : "bg-gray-200 text-gray-500"}`}>
            {current > s.id ? "✓" : s.icon}
          </div>
          <p className={`text-xs mt-1 font-medium
                         ${current === s.id
                           ? "text-blue-600"
                           : current > s.id
                             ? "text-green-600"
                             : "text-gray-400"}`}>
            {s.label}
          </p>
        </div>
        {i < steps.length - 1 && (
          <div className={`flex-1 h-0.5 mt-[-14px]
                           ${current > s.id
                             ? "bg-green-400" : "bg-gray-200"}`}/>
        )}
      </div>
    ))}
  </div>
);

// ─── Form field components ──────────────────────────────────
const Field = ({ label, required, children, hint }) => (
  <div className="space-y-1">
    <label className="block text-xs font-medium text-gray-600">
      {label}
      {required && <span className="text-red-500 ml-0.5">*</span>}
    </label>
    {children}
    {hint && <p className="text-xs text-gray-400">{hint}</p>}
  </div>
);

const Input = ({ value, onChange, placeholder, type="text",
                 maxLength, className="" }) => (
  <input
    type={type}
    value={value || ""}
    onChange={e => onChange(e.target.value)}
    placeholder={placeholder}
    maxLength={maxLength}
    className={`w-full border border-gray-200 rounded-lg px-3 py-2
                text-sm focus:outline-none focus:border-blue-400
                placeholder-gray-300 ${className}`}
  />
);

const Select = ({ value, onChange, options }) => (
  <select
    value={value || ""}
    onChange={e => onChange(e.target.value)}
    className="w-full border border-gray-200 rounded-lg px-3 py-2
               text-sm focus:outline-none focus:border-blue-400
               bg-white"
  >
    <option value="">-- Select --</option>
    {options.map(o => (
      <option key={o.value} value={o.value}>{o.label}</option>
    ))}
  </select>
);

const SectionTitle = ({ children }) => (
  <p className="text-xs font-semibold text-gray-500 uppercase
                tracking-wide mb-3 mt-5 first:mt-0">
    {children}
  </p>
);

// ─── STEP 1: Sender ────────────────────────────────────────
const SenderStep = ({ data, onChange }) => {
  const set = (key) => (val) => onChange({ ...data, [key]: val });
  return (
    <div className="space-y-4">
      <SectionTitle>Sender / Shipper Information</SectionTitle>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Account Number" required>
          <Input value={data.accountNo} onChange={set("accountNo")}
                 placeholder="12345678" maxLength={20}/>
        </Field>
        <Field label="Sub Account No">
          <Input value={data.subAccountNo} onChange={set("subAccountNo")}
                 placeholder="000" maxLength={5}/>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Company Name"
               hint="Company name or Personal name required">
          <Input value={data.companyName} onChange={set("companyName")}
                 placeholder="Raheela Fashion House" maxLength={35}/>
        </Field>
        <Field label="Contact Name">
          <Input value={data.name1} onChange={set("name1")}
                 placeholder="Raheela Begum" maxLength={35}/>
        </Field>
      </div>
      <Field label="Street Address" required>
        <Input value={data.street} onChange={set("street")}
               placeholder="123 Dhanmondi Road" maxLength={35}/>
      </Field>
      <div className="grid grid-cols-3 gap-4">
        <Field label="Zipcode" required hint="Only 0-9 A-Z allowed">
          <Input value={data.zipcode} onChange={set("zipcode")}
                 placeholder="1205" maxLength={9}/>
        </Field>
        <Field label="City / Town" required>
          <Input value={data.town} onChange={set("town")}
                 placeholder="Dhaka" maxLength={35}/>
        </Field>
        <Field label="Country Code" required>
          <Select value={data.countryCode} onChange={set("countryCode")}
                  options={COUNTRIES}/>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Phone" hint="Either phone or email required">
          <Input value={data.phone} onChange={set("phone")}
                 placeholder="+880123456789" maxLength={30}/>
        </Field>
        <Field label="Email" hint="Either phone or email required">
          <Input value={data.email} onChange={set("email")}
                 placeholder="raheela@fashion.com" maxLength={100}/>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Business Type" required>
          <Select value={data.businessType} onChange={set("businessType")}
                  options={[
                    { value:"B", label:"B — Business / Company" },
                    { value:"P", label:"P — Private Individual" },
                  ]}/>
        </Field>
        <Field label="VAT Number"
               hint="Required for Business sender">
          <Input value={data.vatNo} onChange={set("vatNo")}
                 placeholder="BD123456789" maxLength={20}/>
        </Field>
      </div>
      {data.businessType === "B" && (
        <Field label="Selling Website" hint="Required for e-commerce businesses">
          <Input value={data.sellingWebsite} onChange={set("sellingWebsite")}
                 placeholder="https://www.raheelafashion.com" maxLength={255}/>
        </Field>
      )}
    </div>
  );
};

// ─── STEP 2: Receiver ──────────────────────────────────────
const ReceiverStep = ({ data, onChange }) => {
  const set = (key) => (val) => onChange({ ...data, [key]: val });
  return (
    <div className="space-y-4">
      <SectionTitle>Receiver / Consignee Information</SectionTitle>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Receiver Name" hint="Name or Company required">
          <Input value={data.name1} onChange={set("name1")}
                 placeholder="M. David Lopez" maxLength={35}/>
        </Field>
        <Field label="Company Name">
          <Input value={data.companyName} onChange={set("companyName")}
                 placeholder="Lopez Enterprises" maxLength={35}/>
        </Field>
      </div>
      <Field label="Street Address" required>
        <Input value={data.street} onChange={set("street")}
               placeholder="2 Rue Berger" maxLength={35}/>
      </Field>
      <Field label="Address Line 2">
        <Input value={data.add2} onChange={set("add2")}
               placeholder="Apt 3B" maxLength={35}/>
      </Field>
      <div className="grid grid-cols-3 gap-4">
        <Field label="Zipcode" required hint="Only 0-9 A-Z allowed">
          <Input value={data.zipcode} onChange={set("zipcode")}
                 placeholder="1000" maxLength={9}/>
        </Field>
        <Field label="City / Town" required>
          <Input value={data.town} onChange={set("town")}
                 placeholder="Bruxelles" maxLength={35}/>
        </Field>
        <Field label="Country Code" required>
          <Select value={data.countryCode} onChange={set("countryCode")}
                  options={COUNTRIES}/>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Phone" hint="Either phone or email required">
          <Input value={data.phone1} onChange={set("phone1")}
                 placeholder="+3212345678" maxLength={30}/>
        </Field>
        <Field label="Email" hint="Either phone or email required">
          <Input value={data.email} onChange={set("email")}
                 placeholder="david@lopez.be" maxLength={100}/>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Business Type" required>
          <Select value={data.businessType} onChange={set("businessType")}
                  options={[
                    { value:"P", label:"P — Private Individual" },
                    { value:"B", label:"B — Business / Company" },
                  ]}/>
        </Field>
        <Field label="Door Code">
          <Input value={data.doorCode} onChange={set("doorCode")}
                 placeholder="1234" maxLength={8}/>
        </Field>
      </div>
      {data.businessType === "B" && (
        <Field label="VAT Number" hint="Required for Business receiver">
          <Input value={data.vatNo} onChange={set("vatNo")}
                 placeholder="BE123456789" maxLength={20}/>
        </Field>
      )}
    </div>
  );
};

// ─── STEP 3: Parcel + Shipment ─────────────────────────────
const ParcelStep = ({ shipmentData, onShipmentChange,
                      parcels, onParcelsChange }) => {
  const setShipment = (key) => (val) =>
    onShipmentChange({ ...shipmentData, [key]: val });

  const updateParcel = (i, key, val) => {
    const updated = [...parcels];
    updated[i] = { ...updated[i], [key]: val };
    onParcelsChange(updated);
  };

  const addParcel = () =>
    onParcelsChange([...parcels,
      { declaredWeight:"", dimension:"", content:"", parcelRank: parcels.length+1 }]);

  const removeParcel = (i) =>
    onParcelsChange(parcels.filter((_, idx) => idx !== i));

  return (
    <div className="space-y-5">
      <SectionTitle>Shipment Settings</SectionTitle>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Transport Mode" required>
          <Select value={shipmentData.linehaul}
                  onChange={setShipment("linehaul")}
                  options={[
                    { value:"AI", label:"AI — Air" },
                    { value:"RO", label:"RO — Road" },
                    { value:"SE", label:"SE — Sea" },
                  ]}/>
        </Field>
        <Field label="Service Code" required>
          <Select value={shipmentData.serviceCode}
                  onChange={setShipment("serviceCode")}
                  options={[
                    { value:"327", label:"327 — Normal (>3 kg)" },
                    { value:"328", label:"328 — Small (≤3 kg)" },
                  ]}/>
        </Field>
      </div>

      <SectionTitle>Parcels</SectionTitle>

      {parcels.map((p, i) => (
        <div key={i}
             className="border border-gray-200 rounded-xl p-4 relative">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold text-gray-700">
              Parcel {i + 1}
            </p>
            {parcels.length > 1 && (
              <button onClick={() => removeParcel(i)}
                      className="text-xs text-red-500 hover:text-red-700">
                ✕ Remove
              </button>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Weight (grams)" required
                   hint="e.g. 2000 = 2 kg">
              <Input value={p.declaredWeight} type="number"
                     onChange={(v) => updateParcel(i,"declaredWeight",v)}
                     placeholder="2000"/>
            </Field>
            <Field label="Dimensions (cm)"
                   hint="LengthWidthHeight — e.g. 030020015">
              <Input value={p.dimension}
                     onChange={(v) => updateParcel(i,"dimension",v)}
                     placeholder="030020015" maxLength={9}/>
            </Field>
          </div>
          <Field label="Content Description"
                 hint="What is inside? English preferred">
            <Input value={p.content}
                   onChange={(v) => updateParcel(i,"content",v)}
                   placeholder="Handwoven silk saree" maxLength={200}/>
          </Field>
        </div>
      ))}

      <button onClick={addParcel}
              className="w-full py-2.5 border-2 border-dashed border-gray-300
                         rounded-xl text-sm text-gray-500 hover:border-blue-400
                         hover:text-blue-600 transition-colors">
        + Add Another Parcel
      </button>
    </div>
  );
};

// ─── STEP 4: Customs ───────────────────────────────────────
const CustomsStep = ({ customs, onCustomsChange,
                       lines, onLinesChange }) => {
  const set = (key) => (val) => onCustomsChange({ ...customs, [key]: val });

  const updateLine = (i, key, val) => {
    const updated = [...lines];
    updated[i] = { ...updated[i], [key]: val };
    onLinesChange(updated);
  };

  const addLine = () => onLinesChange([...lines,
    { quantity:1, content:"", amount:"", countryOrigin:"",
      hsCodeRecv:"", hsCodeSend:"", netWeight:"", grossWeight:"" }]);

  const removeLine = (i) =>
    onLinesChange(lines.filter((_, idx) => idx !== i));

  return (
    <div className="space-y-4">
      <SectionTitle>Customs Information</SectionTitle>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Parcel Type" required>
          <Select value={customs.parcelType} onChange={set("parcelType")}
                  options={[
                    { value:"P", label:"P — Non-Document (goods)" },
                    { value:"D", label:"D — Document only" },
                  ]}/>
        </Field>
        <Field label="Reason for Export" required>
          <Select value={customs.reasonForExport}
                  onChange={set("reasonForExport")}
                  options={[
                    { value:"01", label:"01 — Sale" },
                    { value:"02", label:"02 — Return / Replacement" },
                    { value:"03", label:"03 — Gift" },
                  ]}/>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Declared Customs Amount">
          <Input value={customs.customsAmount} type="number"
                 onChange={set("customsAmount")} placeholder="95.00"/>
        </Field>
        <Field label="Currency">
          <Select value={customs.currency} onChange={set("currency")}
                  options={[
                    { value:"EUR", label:"EUR — Euro" },
                    { value:"GBP", label:"GBP — British Pound" },
                    { value:"USD", label:"USD — US Dollar" },
                    { value:"BDT", label:"BDT — Bangladeshi Taka" },
                  ]}/>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <Field label="Incoterms">
          <Select value={customs.incoterms} onChange={set("incoterms")}
                  options={[
                    { value:"01", label:"01 — DAP (not cleared)" },
                    { value:"02", label:"02 — DDP (duty paid, excl. tax)" },
                    { value:"03", label:"03 — DDP (duty + tax paid)" },
                    { value:"06", label:"06 — DAP" },
                  ]}/>
        </Field>
        <Field label="Clearance Status">
          <Select value={customs.clearanceStatus}
                  onChange={set("clearanceStatus")}
                  options={[
                    { value:"N", label:"N — No clearance" },
                    { value:"F", label:"F — Free (no customs)" },
                    { value:"E", label:"E — Export cleared" },
                    { value:"I", label:"I — Import cleared" },
                  ]}/>
        </Field>
      </div>

      <SectionTitle>Invoice Lines (Items)</SectionTitle>

      {lines.map((ln, i) => (
        <div key={i}
             className="border border-gray-100 rounded-xl p-4 bg-gray-50">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold text-gray-600">
              Item {i + 1}
            </p>
            {lines.length > 1 && (
              <button onClick={() => removeLine(i)}
                      className="text-xs text-red-500 hover:text-red-700">
                ✕ Remove
              </button>
            )}
          </div>
          <div className="grid grid-cols-3 gap-3 mb-3">
            <Field label="Quantity" required>
              <Input value={ln.quantity} type="number"
                     onChange={(v) => updateLine(i,"quantity",v)}
                     placeholder="1"/>
            </Field>
            <Field label="Unit Price (EUR)">
              <Input value={ln.unitPrice} type="number"
                     onChange={(v) => updateLine(i,"unitPrice",v)}
                     placeholder="95.00"/>
            </Field>
            <Field label="Total Amount" required>
              <Input value={ln.amount} type="number"
                     onChange={(v) => updateLine(i,"amount",v)}
                     placeholder="95.00"/>
            </Field>
          </div>
          <Field label="Item Description" required
                 hint="In English">
            <Input value={ln.content}
                   onChange={(v) => updateLine(i,"content",v)}
                   placeholder="Handwoven silk saree" maxLength={200}/>
          </Field>
          <div className="grid grid-cols-3 gap-3 mt-3">
            <Field label="Country of Origin" required>
              <Select value={ln.countryOrigin}
                      onChange={(v) => updateLine(i,"countryOrigin",v)}
                      options={COUNTRIES}/>
            </Field>
            <Field label="HS Code (Import)" required
                   hint="RCTARIF — 8 digits">
              <Input value={ln.hsCodeRecv}
                     onChange={(v) => updateLine(i,"hsCodeRecv",v)}
                     placeholder="62044900" maxLength={8}/>
            </Field>
            <Field label="HS Code (Export)" required
                   hint="SCTARIF — up to 10 chars">
              <Input value={ln.hsCodeSend}
                     onChange={(v) => updateLine(i,"hsCodeSend",v)}
                     placeholder="6204490000" maxLength={10}/>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3 mt-3">
            <Field label="Net Weight (grams)"
                   hint="Excluding packaging">
              <Input value={ln.netWeight} type="number"
                     onChange={(v) => updateLine(i,"netWeight",v)}
                     placeholder="1800"/>
            </Field>
            <Field label="Gross Weight (grams)"
                   hint="Including packaging">
              <Input value={ln.grossWeight} type="number"
                     onChange={(v) => updateLine(i,"grossWeight",v)}
                     placeholder="2000"/>
            </Field>
          </div>
        </div>
      ))}

      <button onClick={addLine}
              className="w-full py-2.5 border-2 border-dashed border-gray-300
                         rounded-xl text-sm text-gray-500 hover:border-blue-400
                         hover:text-blue-600 transition-colors">
        + Add Another Item
      </button>
    </div>
  );
};

// ─── STEP 5: Review ────────────────────────────────────────
const ReviewStep = ({ sender, receiver, shipment, parcels,
                      customs, lines }) => {
  const InfoRow = ({ label, value }) => value ? (
    <div className="flex justify-between py-1.5 border-b border-gray-100
                    last:border-0">
      <span className="text-xs text-gray-500">{label}</span>
      <span className="text-xs font-medium text-gray-800 text-right
                       max-w-[60%]">{value}</span>
    </div>
  ) : null;

  const Card = ({ title, children }) => (
    <div className="bg-gray-50 rounded-xl p-4 mb-3">
      <p className="text-xs font-bold text-gray-600 uppercase
                    tracking-wide mb-3">{title}</p>
      {children}
    </div>
  );

  const totalWeight = parcels.reduce(
    (sum, p) => sum + (Number(p.declaredWeight) || 0), 0);

  return (
    <div className="space-y-1">
      <p className="text-sm text-gray-500 mb-4">
        Please review before submitting. You can go back to edit.
      </p>

      <Card title="Shipment">
        <InfoRow label="Transport" value={
          shipment.linehaul === "AI" ? "Air" :
          shipment.linehaul === "RO" ? "Road" : "Sea"}/>
        <InfoRow label="Service"
                 value={shipment.serviceCode === "327"
                         ? "327 — Normal" : "328 — Small"}/>
        <InfoRow label="Total Weight"
                 value={`${totalWeight} g (${(totalWeight/1000).toFixed(2)} kg)`}/>
        <InfoRow label="Parcel Count" value={`${parcels.length}`}/>
      </Card>

      <Card title="Sender">
        <InfoRow label="Account" value={sender.accountNo}/>
        <InfoRow label="Name"
                 value={sender.companyName || sender.name1}/>
        <InfoRow label="Address"
                 value={`${sender.street}, ${sender.town}, ${sender.countryCode}`}/>
        <InfoRow label="Contact"
                 value={sender.phone || sender.email}/>
        <InfoRow label="Type"
                 value={sender.businessType === "B"
                         ? "Business" : "Private"}/>
      </Card>

      <Card title="Receiver">
        <InfoRow label="Name"
                 value={receiver.name1 || receiver.companyName}/>
        <InfoRow label="Address"
                 value={`${receiver.street}, ${receiver.zipcode} ${receiver.town}, ${receiver.countryCode}`}/>
        <InfoRow label="Contact"
                 value={receiver.phone1 || receiver.email}/>
      </Card>

      {customs.parcelType && (
        <Card title="Customs">
          <InfoRow label="Type"
                   value={customs.parcelType === "P"
                           ? "Non-Document" : "Document"}/>
          <InfoRow label="Declared Value"
                   value={customs.customsAmount
                           ? `${customs.customsAmount} ${customs.currency}` : null}/>
          <InfoRow label="Reason"
                   value={customs.reasonForExport === "01" ? "Sale" :
                          customs.reasonForExport === "02" ? "Return" : "Gift"}/>
          <InfoRow label="Items" value={`${lines.length} line(s)`}/>
        </Card>
      )}
    </div>
  );
};

// ─── Countries list ────────────────────────────────────────
const COUNTRIES = [
  { value:"BD", label:"BD — Bangladesh" },
  { value:"BE", label:"BE — Belgium" },
  { value:"FR", label:"FR — France" },
  { value:"DE", label:"DE — Germany" },
  { value:"GB", label:"GB — United Kingdom" },
  { value:"NL", label:"NL — Netherlands" },
  { value:"IN", label:"IN — India" },
  { value:"US", label:"US — United States" },
  { value:"CN", label:"CN — China" },
  { value:"JP", label:"JP — Japan" },
  { value:"IT", label:"IT — Italy" },
  { value:"ES", label:"ES — Spain" },
  { value:"PT", label:"PT — Portugal" },
  { value:"PK", label:"PK — Pakistan" },
  { value:"LK", label:"LK — Sri Lanka" },
];

// ─── Success screen ────────────────────────────────────────
const SuccessScreen = ({ result, onNewShipment, onGoToLabel }) => (
  <div className="text-center py-8">
    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center
                    justify-center text-3xl mx-auto mb-4">✅</div>
    <h2 className="text-xl font-bold text-gray-800 mb-1">
      Shipment Created!
    </h2>
    <p className="text-sm text-gray-500 mb-6">
      Your shipment has been saved to the database.
    </p>

    <div className="bg-gray-50 rounded-xl p-4 mb-6 text-left max-w-sm mx-auto">
      <div className="space-y-2">
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Shipment ID</span>
          <span className="text-sm font-bold text-blue-700 font-mono">
            {result.shipmentId}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">MPS ID</span>
          <span className="text-xs font-mono text-gray-700">{result.mpsId}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Parcels</span>
          <span className="text-xs text-gray-700">{result.parcelCount}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-xs text-gray-500">Status</span>
          <span className="text-xs bg-yellow-100 text-yellow-700
                           px-2 py-0.5 rounded font-medium">
            CREATED
          </span>
        </div>
      </div>
    </div>

    {/* Next steps guide */}
    <div className="bg-blue-50 rounded-xl p-4 mb-6 text-left max-w-sm mx-auto">
      <p className="text-xs font-bold text-blue-700 mb-3 uppercase tracking-wide">
        Next Steps
      </p>
      {[
        { step:"1", icon:"🏷️", label:"Generate Label",
          desc:"Go to Labels page, use Shipment ID "+result.shipmentId },
        { step:"2", icon:"📡", label:"Send Pre-Alert",
          desc:"Go to Pre-Alert page after label is printed" },
        { step:"3", icon:"📋", label:"Upload Invoice",
          desc:"Go to Invoices page to upload customs invoice" },
        { step:"4", icon:"📍", label:"Track Delivery",
          desc:"Track in real-time on Tracking page" },
      ].map(ns => (
        <div key={ns.step} className="flex gap-3 mb-2.5">
          <div className="w-6 h-6 bg-blue-600 text-white rounded-full
                          flex items-center justify-center text-xs
                          font-bold shrink-0">
            {ns.step}
          </div>
          <div>
            <p className="text-xs font-semibold text-blue-800">
              {ns.icon} {ns.label}
            </p>
            <p className="text-xs text-blue-600">{ns.desc}</p>
          </div>
        </div>
      ))}
    </div>

    <div className="flex gap-3 justify-center">
      <button onClick={onGoToLabel}
              className="px-5 py-2.5 bg-blue-600 text-white font-medium
                         rounded-xl text-sm hover:bg-blue-700 transition-colors">
        🏷️ Go to Label Page
      </button>
      <button onClick={onNewShipment}
              className="px-5 py-2.5 bg-gray-100 text-gray-700 font-medium
                         rounded-xl text-sm hover:bg-gray-200 transition-colors">
        + New Shipment
      </button>
    </div>
  </div>
);

// ─── MAIN PAGE ─────────────────────────────────────────────
export default function NewShipmentPage({ onNavigate }) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  // Form state
  const [sender, setSender] = useState({
    accountNo:"", companyName:"", name1:"", street:"",
    zipcode:"", town:"", countryCode:"BD",
    phone:"", email:"", businessType:"B",
  });
  const [receiver, setReceiver] = useState({
    name1:"", street:"", zipcode:"", town:"",
    countryCode:"BE", phone1:"", email:"",
    businessType:"P",
  });
  const [shipmentData, setShipmentData] = useState({
    linehaul:"RO", serviceCode:"327",
  });
  const [parcels, setParcels] = useState([{
    declaredWeight:"", dimension:"", content:"", parcelRank:1,
  }]);
  const [customs, setCustoms] = useState({
    parcelType:"P", reasonForExport:"01",
    currency:"EUR", clearanceStatus:"N",
  });
  const [lines, setLines] = useState([{
    quantity:1, content:"", amount:"",
    countryOrigin:"BD", hsCodeRecv:"", hsCodeSend:"",
    netWeight:"", grossWeight:"",
  }]);

  // ─── Validation per step ──────────────────────────────────
  const validateStep = () => {
    setError(null);
    if (step === 1) {
      if (!sender.accountNo) return setError("Account number is required") || false;
      if (!sender.companyName && !sender.name1)
        return setError("Company name or contact name required") || false;
      if (!sender.street) return setError("Street address is required") || false;
      if (!sender.zipcode) return setError("Zipcode is required") || false;
      if (!sender.town) return setError("City is required") || false;
      if (!sender.countryCode) return setError("Country is required") || false;
      if (!sender.phone && !sender.email)
        return setError("Phone or email is required") || false;
      if (!sender.businessType) return setError("Business type is required") || false;
    }
    if (step === 2) {
      if (!receiver.name1 && !receiver.companyName)
        return setError("Receiver name or company required") || false;
      if (!receiver.street) return setError("Receiver street is required") || false;
      if (!receiver.zipcode) return setError("Receiver zipcode is required") || false;
      if (!receiver.town) return setError("Receiver city is required") || false;
      if (!receiver.countryCode) return setError("Receiver country is required") || false;
      if (!receiver.phone1 && !receiver.email)
        return setError("Receiver phone or email required") || false;
    }
    if (step === 3) {
      if (!shipmentData.linehaul) return setError("Transport mode is required") || false;
      if (!shipmentData.serviceCode) return setError("Service code is required") || false;
      for (let i = 0; i < parcels.length; i++) {
        if (!parcels[i].declaredWeight || parcels[i].declaredWeight <= 0)
          return setError(`Parcel ${i+1}: Weight is required`) || false;
      }
    }
    if (step === 4) {
      for (let i = 0; i < lines.length; i++) {
        if (!lines[i].content) return setError(`Item ${i+1}: Description required`) || false;
        if (!lines[i].amount)  return setError(`Item ${i+1}: Amount required`) || false;
        if (!lines[i].hsCodeRecv)
          return setError(`Item ${i+1}: HS Code (import) required`) || false;
        if (!lines[i].hsCodeSend)
          return setError(`Item ${i+1}: HS Code (export) required`) || false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (validateStep()) setStep(s => Math.min(s + 1, 5));
  };

  const handleBack = () => {
    setError(null);
    setStep(s => Math.max(s - 1, 1));
  };

  // ─── Submit ───────────────────────────────────────────────
  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      const payload = {
        linehaul: shipmentData.linehaul,
        serviceCode: parseInt(shipmentData.serviceCode),
        sender: {
          ...sender,
          zipcode: sender.zipcode.toUpperCase(),
        },
        receiver: {
          ...receiver,
          zipcode: receiver.zipcode.toUpperCase(),
        },
        parcels: parcels.map((p, i) => ({
          declaredWeight: Number(p.declaredWeight),
          dimension: p.dimension || null,
          content: p.content || null,
          parcelRank: i + 1,
        })),
        customs: {
          ...customs,
          customsAmount: customs.customsAmount
            ? Number(customs.customsAmount) : null,
        },
        invoiceLines: lines.map((ln, i) => ({
          quantity: Number(ln.quantity) || 1,
          content: ln.content,
          amount: Number(ln.amount),
          countryOrigin: ln.countryOrigin,
          hsCodeRecv: ln.hsCodeRecv,
          hsCodeSend: ln.hsCodeSend,
          netWeight: ln.netWeight ? Number(ln.netWeight) : null,
          grossWeight: ln.grossWeight ? Number(ln.grossWeight) : null,
          unitPrice: ln.unitPrice ? Number(ln.unitPrice) : null,
        })),
      };

      const { data } = await axios.post(
        `${API_BASE}/shipment/create`, payload);

      if (data.success) {
        setResult(data.data);
      } else {
        setError(data.message || "Creation failed");
      }
    } catch (err) {
      const msg = err.response?.data?.message
               || err.response?.data?.errors?.[0]
               || "Server error. Please check all fields.";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setStep(1); setResult(null); setError(null);
    setSender({ accountNo:"", companyName:"", name1:"",
      street:"", zipcode:"", town:"", countryCode:"BD",
      phone:"", email:"", businessType:"B" });
    setReceiver({ name1:"", street:"", zipcode:"", town:"",
      countryCode:"BE", phone1:"", email:"", businessType:"P" });
    setShipmentData({ linehaul:"RO", serviceCode:"327" });
    setParcels([{ declaredWeight:"", dimension:"", content:"", parcelRank:1 }]);
    setCustoms({ parcelType:"P", reasonForExport:"01",
                 currency:"EUR", clearanceStatus:"N" });
    setLines([{ quantity:1, content:"", amount:"",
                countryOrigin:"BD", hsCodeRecv:"", hsCodeSend:"",
                netWeight:"", grossWeight:"" }]);
  };

  // ─── Render ───────────────────────────────────────────────
  if (result) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-lg mx-auto">
          <SuccessScreen
            result={result}
            onNewShipment={resetForm}
            onNavigate={onNavigate}
            onGoToLabel={() => onNavigate && onNavigate("label")}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-2xl mx-auto">

        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            New Shipment
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Fill in all details to create a Chronopost shipment
          </p>
        </div>

        {/* Step bar */}
        <StepBar current={step} />

        {/* Form card */}
        <div className="bg-white rounded-2xl border border-gray-200
                        p-6 mb-4">
          {step === 1 && (
            <SenderStep data={sender} onChange={setSender} />
          )}
          {step === 2 && (
            <ReceiverStep data={receiver} onChange={setReceiver} />
          )}
          {step === 3 && (
            <ParcelStep
              shipmentData={shipmentData}
              onShipmentChange={setShipmentData}
              parcels={parcels}
              onParcelsChange={setParcels}
            />
          )}
          {step === 4 && (
            <CustomsStep
              customs={customs}
              onCustomsChange={setCustoms}
              lines={lines}
              onLinesChange={setLines}
            />
          )}
          {step === 5 && (
            <ReviewStep
              sender={sender} receiver={receiver}
              shipment={shipmentData} parcels={parcels}
              customs={customs} lines={lines}
            />
          )}
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200
                          rounded-xl">
            <p className="text-sm text-red-700">⚠ {error}</p>
          </div>
        )}

        {/* Navigation buttons */}
        <div className="flex justify-between">
          <button
            onClick={handleBack}
            disabled={step === 1}
            className="px-5 py-2.5 bg-white border border-gray-200
                       text-gray-600 font-medium rounded-xl text-sm
                       hover:bg-gray-50 disabled:opacity-30
                       disabled:cursor-not-allowed transition-colors"
          >
            ← Back
          </button>

          {step < 5 ? (
            <button
              onClick={handleNext}
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700
                         text-white font-medium rounded-xl text-sm
                         transition-colors"
            >
              Next →
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="px-8 py-2.5 bg-green-600 hover:bg-green-700
                         disabled:bg-green-300 text-white font-bold
                         rounded-xl text-sm transition-colors"
            >
              {loading ? "Creating..." : "✅ Create Shipment"}
            </button>
          )}
        </div>

        {/* Progress hint */}
        <p className="text-center text-xs text-gray-400 mt-4">
          Step {step} of {steps.length} —{" "}
          {step === 1 ? "Sender info" :
           step === 2 ? "Receiver info" :
           step === 3 ? "Parcel details" :
           step === 4 ? "Customs & items" :
           "Final review"}
        </p>
      </div>
    </div>
  );
}
