import { useState } from "react";
import axios from "axios";

const API = "http://localhost:8080/api";

const COUNTRIES = ["AD","AE","AT","AU","BE","BG","BR","CA","CH","CN","CZ","DE","DK","EE","ES","FI","FR","GB","GR","HR","HU","ID","IE","IL","IN","IT","JE","JP","KR","LT","LU","LV","MA","MC","ME","MK","MT","MX","NL","NO","NZ","PL","PT","RO","RS","RU","SA","SE","SI","SK","TR","UA","US","ZA"].map(c=>({value:c,label:c}));

export default function RoutingLookupPage() {
  const [cc, setCc] = useState("BE");
  const [zip, setZip] = useState("1000");
  const [svc, setSvc] = useState("DPD");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const lookup = async () => {
    setLoading(true); setError(null); setResult(null);
    try {
      const { data } = await axios.get(`${API}/admin/routing/lookup`, { params:{country:cc,zip,service:svc} });
      if (data.success) setResult(data.data);
      else setError(data.message);
    } catch { setError("Lookup failed — check if routing data is loaded"); }
    finally { setLoading(false); }
  };

  const Field = ({ label, children }) => (
    <div>
      <label className="block text-xs text-gray-500 mb-1">{label}</label>
      {children}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Routing Lookup (CHR_ROUTING)</h1>
          <p className="text-sm text-gray-400 mt-0.5">
            Look up origSort, distribSort, numCountryCode by country + zip · 417K rows loaded
          </p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-5 mb-5">
          <h2 className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-4">Lookup</h2>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <Field label="Country">
              <select value={cc} onChange={e=>setCc(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2
                           text-sm focus:outline-none focus:border-blue-400 bg-white">
                {COUNTRIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </Field>
            <Field label="ZIP Code">
              <input value={zip} onChange={e=>setZip(e.target.value)}
                onKeyDown={e=>e.key==="Enter"&&lookup()}
                placeholder="e.g. 1000"
                className="w-full border border-gray-200 rounded-lg px-3 py-2
                           text-sm font-mono focus:outline-none focus:border-blue-400"/>
            </Field>
            <Field label="Service Type">
              <select value={svc} onChange={e=>setSvc(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2
                           text-sm focus:outline-none focus:border-blue-400 bg-white">
                {["DPD","12H","INT","IPM","S112","S517"].map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>
          </div>
          <button onClick={lookup} disabled={loading||!cc||!zip}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300
                       text-white font-medium rounded-xl py-2.5 text-sm">
            {loading ? "Looking up..." : "🔍 Lookup Routing"}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-4">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {result && (
          <div className="space-y-4">
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-4">Result</h2>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label:"Origine Sort",      val:result.origSort,       desc:"Label Zone 4 LEFT (font 24 Bold)" },
                  { label:"Agency Code",        val:result.agencyCode,     desc:"Label Zone 4 CENTER" },
                  { label:"Distrib Sort",       val:result.distribSort,    desc:"Label Zone 4 RIGHT (font 24 Bold)" },
                  { label:"Num Country Code",   val:result.numCountryCode, desc:"Routing barcode field E (3 digits)" },
                  { label:"Normalized ZIP",     val:result.normalizedZip,  desc:"7-char padded for routing barcode" },
                  { label:"Service Type",       val:svc,                   desc:"Used for lookup" },
                ].map(item => (
                  <div key={item.label} className="bg-gray-50 rounded-xl p-4">
                    <p className="text-xs text-gray-400 mb-1">{item.label}</p>
                    <p className="text-lg font-bold font-mono text-gray-800">{item.val || "—"}</p>
                    <p className="text-xs text-gray-400 mt-1">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Label preview */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h2 className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-3">
                Label Zone 4 Preview
              </h2>
              <div className="border-2 border-gray-300 rounded-lg p-4 font-mono">
                <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
                  <span>0407 1120 0000 20W</span>
                  <span>D-B2C</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold text-gray-700">{result.origSort || "—"}</span>
                  <span className="text-3xl font-black text-gray-900">
                    {cc}-{result.agencyCode || "0000"}
                  </span>
                  <span className="text-xl font-bold text-gray-700">{result.distribSort || "—"}</span>
                </div>
                <div className="text-xs text-gray-500 mt-2">
                  327-{cc}-{zip}
                </div>
              </div>
            </div>

            <div className="bg-blue-50 rounded-xl border border-blue-200 p-4">
              <p className="text-xs font-semibold text-blue-700 mb-1">Routing Barcode Field E</p>
              <p className="text-sm text-blue-800">
                Numerical country code <span className="font-mono font-bold">{result.numCountryCode}</span> → 
                goes into routing barcode at position D+E:
                <span className="font-mono text-xs ml-2 bg-blue-100 px-2 py-0.5 rounded">
                  %{result.normalizedZip}[tracking14]327{result.numCountryCode}[checksum]
                </span>
              </p>
            </div>
          </div>
        )}

        {!result && !loading && !error && (
          <div className="bg-white rounded-xl border border-dashed border-gray-300 p-16 text-center">
            <div className="text-4xl text-gray-300 mb-3">🗺️</div>
            <p className="text-sm text-gray-400">Enter a country + ZIP to look up routing info</p>
            <p className="text-xs text-gray-300 mt-1">Data from ROUCHR_20260302_B3 · 417,612 rows</p>
          </div>
        )}
      </div>
    </div>
  );
}
