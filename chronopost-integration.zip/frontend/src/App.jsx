import { useState } from "react";
import NewShipmentPage    from "./pages/NewShipmentPage";
import ShipmentListPage   from "./pages/ShipmentListPage";
import ShipmentDetailPage from "./pages/ShipmentDetailPage";
import LabelPage          from "./pages/LabelPage";
import PreAlertPage       from "./pages/PreAlertPage";
import InvoicePage        from "./pages/InvoicePage";
import TrackingPage       from "./pages/TrackingPage";
import ProductsPage       from "./pages/ProductsPage";
import RoutingLookupPage  from "./pages/RoutingLookupPage";

const NavItem = ({ id, label, icon, active, onClick, badge }) => (
  <button onClick={() => onClick(id)}
    className={`flex items-center gap-2.5 w-full px-3 py-2.5 rounded-lg
                text-sm font-medium transition-colors
                ${active ? "bg-blue-600 text-white" : "text-gray-600 hover:bg-gray-100"}`}>
    <span className="text-base shrink-0">{icon}</span>
    <span className="flex-1 text-left">{label}</span>
    {badge && (
      <span className={`text-xs px-1.5 py-0 rounded-full font-semibold
        ${active ? "bg-white/30 text-white" : "bg-blue-100 text-blue-700"}`}>
        {badge}
      </span>
    )}
  </button>
);

const NavGroup = ({ label, children }) => (
  <div className="mb-2">
    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide px-3 mb-1">{label}</p>
    <div className="space-y-0.5">{children}</div>
  </div>
);

export default function App() {
  const [activePage, setActivePage]   = useState("shipments");
  const [selectedId, setSelectedId]   = useState(null);
  const [navContext, setNavContext]    = useState({});

  const navigate = (page, ctx = {}) => {
    setActivePage(page);
    setNavContext(ctx);
    if (ctx.shipmentId) setSelectedId(ctx.shipmentId);
  };

  const selectShipment = (id) => {
    setSelectedId(id);
    setActivePage("shipment-detail");
  };

  const renderPage = () => {
    switch (activePage) {
      case "shipments":
        return <ShipmentListPage onNavigate={navigate} onSelect={selectShipment}/>;
      case "shipment-detail":
        return <ShipmentDetailPage shipmentId={selectedId} onBack={()=>setActivePage("shipments")} onNavigate={navigate}/>;
      case "new-shipment":
        return <NewShipmentPage onNavigate={navigate}/>;
      case "label":
        return <LabelPage initialShipmentId={navContext.shipmentId}/>;
      case "prealert":
        return <PreAlertPage/>;
      case "invoice":
        return <InvoicePage/>;
      case "tracking":
        return <TrackingPage/>;
      case "products":
        return <ProductsPage/>;
      case "routing":
        return <RoutingLookupPage/>;
      default:
        return <ShipmentListPage onNavigate={navigate} onSelect={selectShipment}/>;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <aside className="w-56 bg-white border-r border-gray-200 flex flex-col shrink-0">

        {/* Logo */}
        <div className="px-4 py-5 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-sm font-black">C</span>
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900 leading-none">Chronopost</p>
              <p className="text-xs text-gray-400 leading-none mt-0.5">Integration v2</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-3 overflow-y-auto space-y-3">

          <NavGroup label="Shipments">
            <NavItem id="shipments"    label="All Shipments" icon="📋" active={activePage==="shipments"} onClick={navigate}/>
            <NavItem id="new-shipment" label="New Shipment"  icon="➕" active={activePage==="new-shipment"} onClick={navigate}/>
          </NavGroup>

          <NavGroup label="Operations">
            <NavItem id="label"    label="Labels"    icon="🏷️" active={activePage==="label"}    onClick={navigate}/>
            <NavItem id="prealert" label="Pre-Alert" icon="📡" active={activePage==="prealert"} onClick={navigate}/>
            <NavItem id="invoice"  label="Invoices"  icon="📄" active={activePage==="invoice"}  onClick={navigate}/>
            <NavItem id="tracking" label="Tracking"  icon="📍" active={activePage==="tracking"} onClick={navigate}/>
          </NavGroup>

          <NavGroup label="Reference Data">
            <NavItem id="products" label="Products"       icon="🗃️" active={activePage==="products"} onClick={navigate}/>
            <NavItem id="routing"  label="Routing Lookup" icon="🗺️" active={activePage==="routing"}  onClick={navigate}/>
          </NavGroup>

        </nav>

        {/* Workflow guide */}
        <div className="p-4 border-t border-gray-100">
          <p className="text-xs text-gray-400 font-semibold mb-2">Workflow:</p>
          {["➕ Create","🏷️ Label","📡 Pre-Alert","📄 Invoice","📍 Track"].map((s,i)=>(
            <p key={i} className="text-xs text-gray-400 leading-5">{i+1}. {s}</p>
          ))}
          <div className="flex items-center gap-1.5 mt-3">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400"/>
            <span className="text-xs text-gray-400">System online</span>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">{renderPage()}</main>
    </div>
  );
}
