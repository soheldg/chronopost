# Chronopost Integration System

Spring Boot + React + Oracle 11g

## Modules
- **Label** — Barcode generation (ZXing) + PDF label (iText 7)
- **Pre-Alert** — GEODATA V3.3.2 flat file + SFTP upload
- **Invoice** — PDF FTP exchange (Doc 4)
- **Tracking** — EDIPOD V21.01 parser + scheduler

## Quick Start

### 1. Oracle DB
```sql
CREATE USER CHRONOPOST IDENTIFIED BY chronopost;
GRANT CONNECT, RESOURCE TO CHRONOPOST;
-- Run: backend/src/main/resources/db/schema.sql
```

### 2. Environment variables
```
DB_USER=chronopost
DB_PASS=chronopost
FTP_USER=yourftpuser
FTP_PASS=yourftppass
```

### 3. Backend
```bash
cd backend
mvn spring-boot:run
# Runs on http://localhost:8080/api
```

### 4. Frontend
```bash
cd frontend
npm install
npm run dev
# Runs on http://localhost:3000
```

## API Endpoints
| Module    | Method | Path                          |
|-----------|--------|-------------------------------|
| Label     | POST   | /api/label/generate           |
| Label     | GET    | /api/label/preview/{parcelId} |
| PreAlert  | POST   | /api/prealert/generate/{id}   |
| PreAlert  | POST   | /api/prealert/send/{id}       |
| Invoice   | POST   | /api/invoice/upload           |
| Invoice   | POST   | /api/invoice/fetch            |
| Tracking  | GET    | /api/tracking/{parcelNo}      |
| Tracking  | GET    | /api/tracking/dashboard       |
| Tracking  | POST   | /api/tracking/poll            |

## Documents Used
- GEODATA V3.3.2 — Pre-alert file format
- EDIPOD2018 V21.01 — Tracking feedback
- Doc Etiquette ROW-FR-ROE V25.01 — Label spec
- Commercial Invoice Exchange v1.1 — FTP invoice
