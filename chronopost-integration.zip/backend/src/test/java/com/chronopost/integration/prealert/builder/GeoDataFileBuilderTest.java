package com.chronopost.integration.prealert.builder;

import com.chronopost.integration.common.config.ChronopostConfig;
import com.chronopost.integration.common.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class GeoDataFileBuilderTest {

    private GeoDataFileBuilder builder;

    @BeforeEach
    void setUp() {
        ChronopostConfig config = new ChronopostConfig();
        builder = new GeoDataFileBuilder(config);
    }

    @Test
    @DisplayName("File starts with #FILE header")
    void fileStartsWithHeaderSection() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.startsWith("#FILE;TEST_FILE"));
        assertTrue(content.contains("#ENCODING;ISO-8859-1"));
        assertTrue(content.contains("#VERSION;03.32"));
    }

    @Test
    @DisplayName("File ends with #END")
    void fileEndsWithEnd() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.trim().endsWith("#END"));
    }

    @Test
    @DisplayName("Contains HEADER;03.32;CONSO")
    void containsHeaderLine() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.contains("GEODATA:HEADER;03.32;CONSO"));
    }

    @Test
    @DisplayName("Contains CONSOLIDATION with LINEHAUL")
    void containsConsolidation() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.contains("GEODATA:CONSOLIDATION"));
        assertTrue(content.contains("RO")); // linehaul
    }

    @Test
    @DisplayName("Contains SHIPMENT with MPSID")
    void containsShipment() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.contains("GEODATA:SHIPMENT"));
        assertTrue(content.contains("TESTMPSID12345"));
    }

    @Test
    @DisplayName("Contains SENDER with account number")
    void containsSender() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.contains("GEODATA:SENDER"));
        assertTrue(content.contains("12345678"));
    }

    @Test
    @DisplayName("Contains RECEIVER with name")
    void containsReceiver() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.contains("GEODATA:RECEIVER"));
        assertTrue(content.contains("JOHN DOE"));
    }

    @Test
    @DisplayName("Contains PARCEL with parcel number")
    void containsParcel() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        assertTrue(content.contains("GEODATA:PARCEL"));
        assertTrue(content.contains("HY712000001JF"));
    }

    @Test
    @DisplayName("Fields separated by semicolon")
    void fieldsSeparatedBySemicolon() {
        Shipment shipment = buildTestShipment();
        String content = builder.build(shipment, "TEST_FILE", null);

        // Each data line should have multiple semicolons
        String[] lines = content.split("\r\n");
        for (String line : lines) {
            if (line.startsWith("GEODATA:")) {
                assertTrue(line.contains(";"),
                    "Data line missing semicolon: " + line);
            }
        }
    }

    @Test
    @DisplayName("Semicolons in field values are stripped")
    void semicolonsInValuesStripped() {
        Shipment shipment = buildTestShipment();
        // Add a semicolon to sender name
        shipment.getSender().setName1("Test;Company");

        String content = builder.build(shipment, "TEST_FILE", null);

        // Semicolons in values should be replaced with spaces
        assertTrue(content.contains("Test Company"));
        assertFalse(content.contains("Test;Company"));
    }

    // ─── Test data builder ────────────────────────────────────────────

    private Shipment buildTestShipment() {
        Sender sender = Sender.builder()
            .accountNo("12345678")
            .name1("TEST SENDER")
            .street("123 Test Street")
            .zipcode("75001")
            .town("PARIS")
            .countryCode("FR")
            .phone("+33123456789")
            .businessType("B")
            .build();

        Receiver receiver = Receiver.builder()
            .name1("JOHN DOE")
            .street("456 Receiver Road")
            .zipcode("1000")
            .town("BRUSSELS")
            .countryCode("BE")
            .phone("+32123456789")
            .businessType("P")
            .build();

        Parcel parcel = Parcel.builder()
            .parcelNumber("HY712000001JF")
            .parcelCcKey("X")
            .serviceCode(327)
            .declaredWeight(1500L)
            .parcelRank(1)
            .build();

        Shipment shipment = Shipment.builder()
            .id(1L)
            .mpsId("TESTMPSID12345")
            .mpsIdCcKey("A")
            .mpscount(1)
            .mpsweight(1500L)
            .cdate(LocalDate.now())
            .ctime("120000")
            .linehaul("RO")
            .status(Shipment.ShipmentStatus.LABEL_READY)
            .build();

        sender.setShipment(shipment);
        receiver.setShipment(shipment);
        parcel.setShipment(shipment);

        shipment.setSender(sender);
        shipment.setReceiver(receiver);
        shipment.setParcels(List.of(parcel));

        return shipment;
    }
}
