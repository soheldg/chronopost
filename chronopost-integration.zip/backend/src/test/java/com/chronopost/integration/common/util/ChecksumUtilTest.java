package com.chronopost.integration.common.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for ChecksumUtil
 * Uses the example values from Doc 3 - Label Specification V25.01
 * Section 2.6.4.1.4
 */
class ChecksumUtilTest {

    private ChecksumUtil checksumUtil;

    @BeforeEach
    void setUp() {
        checksumUtil = new ChecksumUtil();
    }

    // ─── Tracking ID checksum tests (from Doc 3) ────────────────────
    @Test
    @DisplayName("99993456799248 → V (from Doc 3 example)")
    void trackingChecksum_example1() {
        String checksum = checksumUtil
            .calculateTrackingChecksum("99993456799248");
        assertEquals("V", checksum);
    }

    @Test
    @DisplayName("12345678901234 → E (from Doc 3 example)")
    void trackingChecksum_example2() {
        String checksum = checksumUtil
            .calculateTrackingChecksum("12345678901234");
        assertEquals("E", checksum);
    }

    // ─── Routing barcode checksum tests (from Doc 3) ────────────────
    @Test
    @DisplayName("009120082123456789248226250 → 0 (from Doc 3)")
    void routingChecksum_example1() {
        String checksum = checksumUtil
            .calculateRoutingChecksum("009120082123456789248226250");
        assertEquals("0", checksum);
    }

    @Test
    @DisplayName("009120036000000000248226250 → 3 (from Doc 3)")
    void routingChecksum_example2() {
        String checksum = checksumUtil
            .calculateRoutingChecksum("009120036000000000248226250");
        assertEquals("3", checksum);
    }

    @Test
    @DisplayName("009120049123123123336156250 → J (from Doc 3)")
    void routingChecksum_example3() {
        String checksum = checksumUtil
            .calculateRoutingChecksum("009120049123123123336156250");
        assertEquals("J", checksum);
    }

    @Test
    @DisplayName("009120024111111111209180250 → Z (from Doc 3)")
    void routingChecksum_example4() {
        String checksum = checksumUtil
            .calculateRoutingChecksum("009120024111111111209180250");
        assertEquals("Z", checksum);
    }

    // ─── Validation tests ────────────────────────────────────────────
    @Test
    @DisplayName("Tracking ID must be 14 chars")
    void invalidTrackingId_tooShort() {
        assertThrows(IllegalArgumentException.class,
            () -> checksumUtil.calculateTrackingChecksum("1234567890123"));
    }

    @Test
    @DisplayName("Routing barcode must be 27 chars")
    void invalidRoutingBarcode_tooShort() {
        assertThrows(IllegalArgumentException.class,
            () -> checksumUtil.calculateRoutingChecksum("12345678901234567890123456"));
    }

    @Test
    @DisplayName("Invalid character throws exception")
    void invalidCharacter() {
        assertThrows(IllegalArgumentException.class,
            () -> checksumUtil.calculate("1234567890123!"));
    }

    // ─── Build full tracking ID test ─────────────────────────────────
    @Test
    @DisplayName("Build full tracking ID with checksum")
    void buildTrackingId() {
        // Sender ID: 0407112, counter: 000002, international: 0
        // Full 14: "04071120000020"
        // checksum: calculateTrackingChecksum("04071120000020")
        String trackingId = checksumUtil
            .buildTrackingId("0407112", "000002");

        assertEquals(15, trackingId.length());
        assertTrue(trackingId.startsWith("04071120000020"));
    }
}
