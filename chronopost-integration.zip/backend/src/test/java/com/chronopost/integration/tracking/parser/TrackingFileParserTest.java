package com.chronopost.integration.tracking.parser;

import com.chronopost.integration.tracking.dto.TrackingEventDto;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for TrackingFileParser
 * Uses example data from Doc 2 - EDIPOD2018 V21.01 (page 6)
 */
class TrackingFileParserTest {

    private TrackingFileParser parser;

    // Example line from Doc 2 page 6 (reconstructed from field descriptions)
    private static final String EXAMPLE_LINE =
        "12345678;000;AA123456789FR;AA123456789248C;" +
        "STE DUMOULIN;;14 RUE DE PARIS;IMMEUBLE B3;06000;NICE;FR;;;" +
        "AG125UY;M DAVID LOPEZ;;2 RUE BERGER;;75015;PARIS;FR;01.45.56.64.46;;" +
        "20180730;BL 123456;;;;" +
        "01;899;0;EUR;0;EUR;" +
        "SM;MIS;20180730;1158;MAIL;consignee@provider.net;" +
        "DAT;;;20180801;1234T;M. DUPONT;;0001,60;;;";

    @BeforeEach
    void setUp() {
        parser = new TrackingFileParser();
    }

    // ─── Single line parsing ──────────────────────────────────────────

    @Test
    @DisplayName("Parse contract number (field 01)")
    void parseContractNo() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertNotNull(event);
        assertEquals("12345678", event.getContractNo());
    }

    @Test
    @DisplayName("Parse Chronopost tracking number (field 03)")
    void parseChronopostTrackNo() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("AA123456789FR", event.getChronopostTrackNo());
    }

    @Test
    @DisplayName("Parse DPD Group tracking number (field 04)")
    void parseDpdGroupTrackNo() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("AA123456789248C", event.getDpdGroupTrackNo());
    }

    @Test
    @DisplayName("Parse sender name (field 05)")
    void parseSenderName() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("STE DUMOULIN", event.getSenderName1());
    }

    @Test
    @DisplayName("Parse consignee name (field 15)")
    void parseConsigneeName() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("M DAVID LOPEZ", event.getConsigneeName1());
    }

    @Test
    @DisplayName("Parse deposit date (field 24) YYYYMMDD → LocalDate")
    void parseDepositDate() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals(LocalDate.of(2018, 7, 30), event.getDepositDate());
    }

    @Test
    @DisplayName("Parse event code (field 35)")
    void parseEventCode() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("SM", event.getEventCode());
    }

    @Test
    @DisplayName("Parse reason code (field 36)")
    void parseReasonCode() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("MIS", event.getReasonCode());
    }

    @Test
    @DisplayName("Parse event date (field 37)")
    void parseEventDate() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals(LocalDate.of(2018, 7, 30), event.getEventDate());
    }

    @Test
    @DisplayName("Parse event time (field 38)")
    void parseEventTime() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("1158", event.getEventTime());
    }

    @Test
    @DisplayName("Parse communication channel (field 39)")
    void parseCommChannel() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("MAIL", event.getCommChannel());
    }

    @Test
    @DisplayName("Parse delivery instruction (field 41)")
    void parseDeliveryInstruction() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("DAT", event.getDeliveryInstruction());
    }

    @Test
    @DisplayName("Parse desk clerk (field 45)")
    void parseDeskClerk() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("M. DUPONT", event.getDeskClerk());
    }

    @Test
    @DisplayName("Parse declared weight (field 47)")
    void parseDeclaredWeight() {
        TrackingEventDto event = parser.parseLine(EXAMPLE_LINE, 1);
        assertEquals("0001,60", event.getDeclaredWeight());
    }

    // ─── Full file parsing ────────────────────────────────────────────

    @Test
    @DisplayName("Parse multi-line file")
    void parseMultiLineFile() {
        String file = EXAMPLE_LINE + "\n" + EXAMPLE_LINE + "\n";
        List<TrackingEventDto> events = parser.parseFile(file);
        assertEquals(2, events.size());
    }

    @Test
    @DisplayName("Skip empty lines")
    void skipEmptyLines() {
        String file = EXAMPLE_LINE + "\n\n" + EXAMPLE_LINE + "\n";
        List<TrackingEventDto> events = parser.parseFile(file);
        assertEquals(2, events.size());
    }

    @Test
    @DisplayName("Empty file returns empty list")
    void emptyFileReturnsEmptyList() {
        List<TrackingEventDto> events = parser.parseFile("");
        assertTrue(events.isEmpty());
    }

    @Test
    @DisplayName("Null file returns empty list")
    void nullFileReturnsEmptyList() {
        List<TrackingEventDto> events = parser.parseFile(null);
        assertTrue(events.isEmpty());
    }

    // ─── Event code detection ─────────────────────────────────────────

    @Test
    @DisplayName("isDelivered returns true for DL event")
    void isDelivered() {
        TrackingEventDto event = new TrackingEventDto();
        event.setEventCode("DL");
        assertTrue(event.isDelivered());
    }

    @Test
    @DisplayName("isInTransit returns true for SM event")
    void isInTransit() {
        TrackingEventDto event = new TrackingEventDto();
        event.setEventCode("SM");
        assertTrue(event.isInTransit());
    }

    @Test
    @DisplayName("isFailedAttempt returns true for AT event")
    void isFailedAttempt() {
        TrackingEventDto event = new TrackingEventDto();
        event.setEventCode("AT");
        assertTrue(event.isFailedAttempt());
    }

    // ─── Event description ────────────────────────────────────────────

    @Test
    @DisplayName("getEventDescription returns correct description")
    void getEventDescription() {
        assertEquals("Delivered",
                     parser.getEventDescription("DL"));
        assertEquals("Parcel scanned / in transit",
                     parser.getEventDescription("SM"));
        assertEquals("Delivery attempted - recipient absent",
                     parser.getEventDescription("AT"));
    }

    @Test
    @DisplayName("getInstructionDescription returns correct description")
    void getInstructionDescription() {
        assertEquals("Delivery date change",
                     parser.getInstructionDescription("DAT"));
        assertEquals("Safe place delivery",
                     parser.getInstructionDescription("COMPADD"));
    }
}
