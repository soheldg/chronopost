package com.chronopost.integration.invoice.util;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

class InvoiceFileNameBuilderTest {

    private InvoiceFileNameBuilder builder;

    @BeforeEach
    void setUp() { builder = new InvoiceFileNameBuilder(); }

    // ─── Build upload file name ───────────────────────────────────────
    @Test
    @DisplayName("Export invoice file name format")
    void exportFileName() {
        String name = builder.buildExportFileName(
            "12345678", "HY712000001JF");
        assertEquals("INV_EXP_12345678_HY712000001JF.PDF", name);
    }

    @Test
    @DisplayName("Import invoice file name format")
    void importFileName() {
        String name = builder.buildImportFileName(
            "12345678", "HY712000001JF");
        assertEquals("INV_IMP_12345678_HY712000001JF.PDF", name);
    }

    @Test
    @DisplayName("Type must be EXP or IMP")
    void invalidType() {
        assertThrows(IllegalArgumentException.class,
            () -> builder.buildUploadFileName(
                "XXX", "12345678", "HY712000001JF"));
    }

    @Test
    @DisplayName("Special chars stripped from account")
    void specialCharsStripped() {
        String name = builder.buildExportFileName(
            "1234-5678", "HY712000001JF");
        assertEquals("INV_EXP_12345678_HY712000001JF.PDF", name);
    }

    // ─── Parse download file name ─────────────────────────────────────
    @Test
    @DisplayName("Parse downloaded file name INV_DDD_ID15.PDF")
    void parseDownloadedName() {
        var parsed = builder.parseDownloadedFileName(
            "INV_CDG_HY712000001JF.PDF");

        assertEquals("CDG",            parsed.getDestination());
        assertEquals("HY712000001JF", parsed.getParcelId());
    }

    @Test
    @DisplayName("Parse is case-insensitive for .pdf extension")
    void parseCaseInsensitive() {
        var parsed = builder.parseDownloadedFileName(
            "INV_CDG_HY712000001JF.pdf");
        assertNotNull(parsed);
    }

    @Test
    @DisplayName("Invalid file name throws exception")
    void parseInvalidName() {
        assertThrows(IllegalArgumentException.class,
            () -> builder.parseDownloadedFileName("RANDOM_FILE.pdf"));
    }

    // ─── isInvoiceFile ────────────────────────────────────────────────
    @Test
    @DisplayName("Correctly identifies invoice files")
    void isInvoiceFile() {
        assertTrue(builder.isInvoiceFile("INV_EXP_12345_PARCEL.PDF"));
        assertTrue(builder.isInvoiceFile("INV_CDG_PARCELID.pdf"));
        assertFalse(builder.isInvoiceFile("GEODATA_CONSO_12345.txt"));
        assertFalse(builder.isInvoiceFile(null));
        assertFalse(builder.isInvoiceFile(""));
    }
}
