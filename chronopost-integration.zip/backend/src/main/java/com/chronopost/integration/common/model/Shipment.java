package com.chronopost.integration.common.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "CHR_SHIPMENTS", schema = "CHRONOPOST")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Shipment {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,
                    generator = "chr_seq")
    @SequenceGenerator(name = "chr_seq",
                       sequenceName = "CHR_SEQ",
                       allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "MPSID", nullable = false, length = 14)
    private String mpsId;

    @Column(name = "MPSID_CCKEY", length = 1)
    private String mpsIdCcKey;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 20)
    @Builder.Default
    private ShipmentStatus status = ShipmentStatus.CREATED;

    @Column(name = "SERVICE_CODE")
    private Integer serviceCode;

    // AI=Air, RO=Road, SE=Sea
    @Column(name = "LINEHAUL", length = 2)
    private String linehaul;

    @Column(name = "CDATE")
    private LocalDate cdate;

    @Column(name = "CTIME", length = 6)
    private String ctime;

    @Column(name = "SDEPOT", length = 7)
    @Builder.Default
    private String sdepot = "0029999";

    @Column(name = "SYSDEPOT", length = 7)
    @Builder.Default
    private String sysdepot = "0020456";

    @Column(name = "HARDWARE", length = 1)
    @Builder.Default
    private String hardware = "K";

    @Column(name = "DELMODALLOW")
    @Builder.Default
    private Integer delmodallow = 1;

    @Column(name = "SPTDATE")
    private LocalDate sptdate;

    @Column(name = "MPSCOUNT")
    private Integer mpscount;

    @Column(name = "MPSWEIGHT")
    private Long mpsweight;

    @Column(name = "MPSVOLUME", length = 9)
    private String mpsvolume;

    @Column(name = "OPCODE", length = 3)
    @Builder.Default
    private String opcode = "INS";

    @Column(name = "TIMEZONE", length = 5)
    @Builder.Default
    private String timezone = "+0000";

    @Column(name = "CREATED_AT")
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    // ===== RELATIONSHIPS =====

    @OneToOne(mappedBy = "shipment",
              cascade = CascadeType.ALL,
              fetch = FetchType.LAZY)
    private Sender sender;

    @OneToOne(mappedBy = "shipment",
              cascade = CascadeType.ALL,
              fetch = FetchType.LAZY)
    private Receiver receiver;

    @OneToMany(mappedBy = "shipment",
               cascade = CascadeType.ALL,
               fetch = FetchType.LAZY)
    @Builder.Default
    private List<Parcel> parcels = new ArrayList<>();

    @OneToOne(mappedBy = "shipment",
              cascade = CascadeType.ALL,
              fetch = FetchType.LAZY)
    private Customs customs;

    @OneToMany(mappedBy = "shipment",
               cascade = CascadeType.ALL,
               fetch = FetchType.LAZY)
    @Builder.Default
    private List<InvoiceLine> invoiceLines = new ArrayList<>();

    // ===== STATUS ENUM =====
    public enum ShipmentStatus {
        CREATED,
        LABEL_READY,
        PREALERT_SENT,
        INVOICE_SENT,
        HANDED_OVER,
        IN_TRANSIT,
        DELIVERED,
        FAILED,
        RETURNED
    }
}
