package com.chronopost.integration.tracking.parser;

import com.chronopost.integration.tracking.dto.TrackingEventDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Parses Chronopost EDIPOD tracking feedback flat file
 * Doc 2 — EDIPOD2018 V21.01
 *
 * FIX: Event codes corrected from official list
 *      (Evenements_Chronopost_2023-06-30.xlsx)
 *      Previous codes (DL, RT, ND) were assumed — actual codes are D, R, N
 *
 * 51 semicolon-separated fields per line
 */
@Component
@Slf4j
public class TrackingFileParser {

    private static final String SEPARATOR = ";";
    private static final DateTimeFormatter DATE_FMT =
        DateTimeFormatter.ofPattern("yyyyMMdd");

    // =====================================================================
    // FILE PARSER
    // =====================================================================

    public List<TrackingEventDto> parseFile(String fileContent) {
        if (fileContent == null || fileContent.isBlank()) {
            log.warn("Tracking file is empty");
            return List.of();
        }

        List<TrackingEventDto> events = new ArrayList<>();
        String[] lines = fileContent.split("\\r?\\n");
        int lineNum = 0;

        for (String line : lines) {
            lineNum++;
            if (line.isBlank()) continue;
            if (lineNum == 1 && line.startsWith("Contract")) {
                log.debug("Skipping header line");
                continue;
            }
            try {
                TrackingEventDto event = parseLine(line, lineNum);
                if (event != null) events.add(event);
            } catch (Exception e) {
                log.warn("Parse error line {}: {}", lineNum, e.getMessage());
            }
        }

        log.info("Parsed: {} events from {} lines", events.size(), lineNum);
        return events;
    }

    public TrackingEventDto parseLine(String line, int lineNum) {
        if (line == null || line.isBlank()) return null;

        String[] f = line.split(SEPARATOR, -1);

        if (f.length < 35) {
            log.warn("Line {} has only {} fields", lineNum, f.length);
        }

        TrackingEventDto e = new TrackingEventDto();
        e.setRawLine(line);
        e.setLineNumber(lineNum);

        // ── F01-04: Identification ─────────────────────────────────────
        e.setContractNo(        get(f,  0));  // F01 AN8
        e.setSubAccountNo(      get(f,  1));  // F02 AN3
        e.setChronopostTrackNo( get(f,  2));  // F03 AN13
        e.setDpdGroupTrackNo(   get(f,  3));  // F04 AN15

        // ── F05-13: Sender ─────────────────────────────────────────────
        e.setSenderName1(       get(f,  4));  // F05
        e.setSenderName2(       get(f,  5));  // F06
        e.setSenderAddress1(    get(f,  6));  // F07
        e.setSenderAddress2(    get(f,  7));  // F08
        e.setSenderPostalCode(  get(f,  8));  // F09
        e.setSenderCity(        get(f,  9));  // F10
        e.setSenderCountryCode( get(f, 10));  // F11
        e.setSenderPhone(       get(f, 11));  // F12
        e.setSenderEmail(       get(f, 12));  // F13

        // ── F14-23: Consignee ──────────────────────────────────────────
        e.setConsigneeCode(      get(f, 13)); // F14
        e.setConsigneeName1(     get(f, 14)); // F15
        e.setConsigneeName2(     get(f, 15)); // F16
        e.setConsigneeAddress1(  get(f, 16)); // F17
        e.setConsigneeAddress2(  get(f, 17)); // F18
        e.setConsigneePostalCode(get(f, 18)); // F19
        e.setConsigneeCity(      get(f, 19)); // F20
        e.setConsigneeCountry(   get(f, 20)); // F21
        e.setConsigneePhone(     get(f, 21)); // F22
        e.setConsigneeEmail(     get(f, 22)); // F23

        // ── F24-34: Parcel info ────────────────────────────────────────
        e.setDepositDate(       parseDate(get(f, 23))); // F24
        e.setSenderRef(         get(f, 24));             // F25
        e.setSenderBarcode(     get(f, 25));             // F26
        e.setDeliverySlotStart( get(f, 26));             // F27
        e.setDeliverySlotEnd(   get(f, 27));             // F28
        e.setProductCode(       get(f, 28));             // F29
        e.setServiceCode(       get(f, 29));             // F30
        e.setInsuredAmount(     get(f, 30));             // F31
        e.setInsuredCurrency(   get(f, 31));             // F32
        e.setCodAmount(         get(f, 32));             // F33
        e.setCodCurrency(       get(f, 33));             // F34

        // ── F35-51: Tracking event ─────────────────────────────────────
        e.setEventCode(          get(f, 34)); // F35
        e.setReasonCode(         get(f, 35)); // F36
        e.setEventDate(     parseDate(get(f, 36))); // F37
        e.setEventTime(          get(f, 37)); // F38
        e.setCommChannel(        get(f, 38)); // F39
        e.setChannelAddress(     get(f, 39)); // F40
        e.setDeliveryInstruction(get(f, 40)); // F41
        e.setDisposalPlaceCode(  get(f, 41)); // F42
        e.setNewDeliveryDate(parseDate(get(f, 42))); // F43
        e.setPickupPudoCode(     get(f, 43)); // F44
        e.setDeskClerk(          get(f, 44)); // F45
        e.setTransmitterCode(    get(f, 45)); // F46
        e.setDeclaredWeight(     get(f, 46)); // F47
        e.setLengthCm(           get(f, 47)); // F48
        e.setWidthCm(            get(f, 48)); // F49
        e.setHeightCm(           get(f, 49)); // F50
        e.setPodImageUrl(        get(f, 50)); // F51

        if (e.getChronopostTrackNo() == null)
            log.warn("Line {}: missing tracking number", lineNum);

        return e;
    }

    // =====================================================================
    // EVENT CODE → DESCRIPTION
    // FIX: All codes from official Excel Evenements_Chronopost_2023-06-30
    //      Previous assumptions (DL, RT, ND) replaced with real codes
    // =====================================================================
    public String getEventDescription(String code) {
        if (code == null) return "Unknown";
        return switch (code.toUpperCase()) {

            // ── DELIVERED ────────────────────────────────────────────────
            case "D"   -> "Delivered";                                   // FIX: was "DL"
            case "D1"  -> "Delivered in mail box";
            case "D6"  -> "Delivered — QR code";
            case "D7"  -> "Delivered — PIN code";
            case "RG"  -> "Delivered to caretaker/reception";
            case "RI"  -> "Collected by consignee at pickup point";
            case "U"   -> "Delivery runsheet available";
            case "VC"  -> "Delivered without signature";

            // ── IN TRANSIT ───────────────────────────────────────────────
            case "SM"  -> "Shipment scanned / in transit";
            case "PC"  -> "Picked up by driver";
            case "TI"  -> "Arrived at hub for sorting";
            case "TO"  -> "Sorted out from hub";
            case "TP"  -> "Parcel in transit";
            case "TS"  -> "Shipment in transit";
            case "TA"  -> "Out for delivery";
            case "BA"  -> "Bagging scan";
            case "BL"  -> "Parcel stopped";
            case "E"   -> "Released from customs";                       // FIX: was missing
            case "G"   -> "Arrived at inbound gateway";
            case "L"   -> "Inbound linehaul scan";
            case "IX"  -> "Manual processing";
            case "SF"  -> "Invoicing scan";
            case "SD"  -> "Sorted at delivery location";
            case "SC"  -> "Sorted at departure location";
            case "SE"  -> "Departure from outbound gateway";
            case "SI"  -> "Departure from inbound gateway";
            case "SJ"  -> "Released from customs — in transit";
            case "ED"  -> "Arrival at delivery location";
            case "EE"  -> "Arrival at outbound gateway";
            case "EI"  -> "Arrival at inbound gateway";
            case "EC"  -> "Sorting at departure depot";
            case "T"   -> "Arrival in depot";
            case "EN"  -> "Entered sorting facility";
            case "EX"  -> "Left sorting facility";
            case "LO"  -> "Loaded on transport";
            case "AR"  -> "Arrived at destination depot";
            case "WC"  -> "With courier for delivery";
            case "OD"  -> "Out for delivery";
            case "PR"  -> "Parcel pre-alerted";

            // ── CUSTOMS ──────────────────────────────────────────────────
            case "CU"  -> "In customs clearance";
            case "CC"  -> "Parcel to collect / Customs cleared";
            case "CS"  -> "Customs stopped";
            case "DO"  -> "Held in customs";
            case "DF"  -> "Docs missing for customs clearance";
            case "VD"  -> "Delayed — customs inspection";
            case "DT"  -> "Handed to consignee's broker";
            case "ST"  -> "Cleared — consignee to pay duties";
            case "EJ"  -> "Customs clearance in progress";

            // ── FAILED DELIVERY ──────────────────────────────────────────
            case "N"   -> "Shipment not delivered";                      // FIX: was "ND"
            case "P"   -> "Delivery failed — recipient absent";          // FIX: was missing
            case "AT"  -> "Delivery attempted — recipient absent";
            case "HO"  -> "Held at depot";
            case "PA"  -> "Delivery failed, awaiting instructions";
            case "CO"  -> "Delivery failed, awaiting instructions";
            case "RC"  -> "Delivery failed, awaiting instructions";
            case "NA"  -> "Delivery failed, awaiting instructions";
            case "IN"  -> "Delivery location not accessible";
            case "NL"  -> "Not delivered — QR/PIN not provided";
            case "UN"  -> "Shipment undeliverable";
            case "BD"  -> "Held — hygiene/police inspection";
            case "KC"  -> "Parcel damaged";
            case "LC"  -> "Removed from plane — capacity issue";
            case "FI"  -> "End of instance";
            case "DI"  -> "Delivery postponed 24hrs";
            case "DS"  -> "Delayed — strike in destination country";
            case "RO"  -> "Packaging unsuitable";
            case "ND"  -> "Not delivered";

            // ── RETURNED ─────────────────────────────────────────────────
            case "R"   -> "Returned to sender";                          // FIX: was "RT"
            case "RT"  -> "Misrouted — returned";
            case "ER"  -> "Held at customer service CRESA";

            // ── AVAILABLE FOR COLLECTION ──────────────────────────────────
            case "B"   -> "Left in mail box";
            case "IP"  -> "Left at local post office";
            case "RB"  -> "Available at post office/parcel shop";
            case "MD"  -> "Available at retrieval point";
            case "I"   -> "Held at location";
            case "AB"  -> "Left at local post office or parcel shop";

            // ── DELAYED ──────────────────────────────────────────────────
            case "A"   -> "Delivery delayed — agent scan";
            case "A1"  -> "Shipment delayed — delivery postponed 24h";
            case "A2"  -> "Delayed at delivery agency — postponed 24h";
            case "RA"  -> "Misrouted — delivery postponed 24h";
            case "RD"  -> "Delay detected";
            case "CR"  -> "Delayed — postponed 24h";
            case "W"   -> "Delivery delayed";
            case "HD"  -> "Delayed — late arrival at delivery location";
            case "LR"  -> "Delayed for technical reason";
            case "LT"  -> "Delayed — technical problems";
            case "LW"  -> "Connection cancelled — bad weather";
            case "BW"  -> "Delayed — bad weather";
            case "IA"  -> "Held — afternoon deliveries not accepted";
            case "IS"  -> "Not due for Saturday delivery";

            // ── OTHER ─────────────────────────────────────────────────────
            case "AC"  -> "Automatic tracking message sent";
            case "SM_NOTIF" -> "Recipient notified by SMS/email";
            case "CL"  -> "Delivery instruction received";
            case "CT"  -> "Delivery instruction registered";
            case "AV"  -> "Awaiting shipper's instructions";
            case "IV"  -> "Awaiting additional information";
            case "SK"  -> "Awaiting additional information from you";
            case "AP"  -> "Awaiting payment of taxes and duties";
            case "DC"  -> "Shipment ready to be shipped";
            case "DB"  -> "Shipment handed over by shipper";
            case "DV"  -> "Handed over to Chronopost";
            case "PC2" -> "Shipment picked up";
            case "PE"  -> "Sending supported by Chronopost";
            case "AN"  -> "Shipment cancelled by shipper";
            case "DP"  -> "Packaging unsuitable";
            case "DR"  -> "Shipment destroyed";
            case "CA"  -> "Consignee has moved";
            case "PT"  -> "Missing parcel";
            case "VO"  -> "Shipment lost";
            case "FC"  -> "Parcel out of CRESA";

            default    -> "Event: " + code;
        };
    }

    // =====================================================================
    // SHIPMENT STATUS MAPPING
    // FIX: Updated with correct event codes from official Excel
    // =====================================================================
    public String resolveShipmentStatus(String eventCode) {
        if (eventCode == null) return null;
        return switch (eventCode.toUpperCase()) {

            // DELIVERED
            case "D", "D1", "D6", "D7", "RG", "RI", "U", "VC"
                -> "DELIVERED";

            // IN_TRANSIT
            case "SM", "PC", "TI", "TO", "TP", "TS", "TA",
                 "BA", "E", "G", "L", "IX", "SF", "SD", "SC",
                 "SE", "SI", "SJ", "ED", "EE", "EI", "EC", "T",
                 "EN", "EX", "LO", "AR", "WC", "OD", "PR",
                 "CU", "CC", "BL"
                -> "IN_TRANSIT";

            // FAILED
            case "N", "P", "AT", "HO", "PA", "CO", "RC", "NA",
                 "IN", "NL", "UN", "BD", "KC", "FI", "CS",
                 "DO", "DF"
                -> "FAILED";

            // RETURNED
            case "R", "RT"
                -> "RETURNED";

            // AVAILABLE (stays IN_TRANSIT from our perspective)
            case "B", "IP", "RB", "MD", "I", "AB"
                -> "IN_TRANSIT";

            default -> null;  // no status change
        };
    }

    // =====================================================================
    // INSTRUCTION DESCRIPTIONS (F41)
    // =====================================================================
    public String getInstructionDescription(String instruction) {
        if (instruction == null) return "";
        return switch (instruction.toUpperCase()) {
            case "MDR"        -> "Put at disposal — PickUp PUDO";
            case "MDBP"       -> "Put at disposal — Post Office";
            case "MDA"        -> "Put at disposal — Address";
            case "DAT"        -> "Delivery date change";
            case "ANNUL"      -> "Cancellation of instruction";
            case "CHRDV"      -> "Reprogramming delivery slot";
            case "COMPADD"    -> "Safe place / additional address";
            case "RVOISIN"    -> "Delivery to neighbour";
            case "SCOMPADD"   -> "Additional safe place address";
            case "CHADD_ZCA"  -> "Change of address (same agency zone)";
            case "CHADD_HZCA" -> "Change of address (outside agency zone)";
            default           -> instruction;
        };
    }

    // =====================================================================
    // HELPERS
    // =====================================================================
    private String get(String[] f, int i) {
        if (i >= f.length) return null;
        String v = f[i].trim();
        return v.isEmpty() ? null : v;
    }

    private LocalDate parseDate(String s) {
        if (s == null || s.isBlank() || s.equals("0")) return null;
        try { return LocalDate.parse(s.trim(), DATE_FMT); }
        catch (Exception e) { return null; }
    }
}
