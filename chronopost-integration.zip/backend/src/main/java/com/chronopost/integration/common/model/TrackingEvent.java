package com.chronopost.integration.common.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "CHR_TRACKING_EVENTS", schema = "CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TrackingEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "chr_seq")
    @SequenceGenerator(name = "chr_seq", sequenceName = "CHR_SEQ", allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARCEL_ID", nullable = false)
    private Parcel parcel;

    @Column(name = "CONTRACT_NO",  length = 8)  private String contractNo;
    @Column(name = "EVENT_CODE",   length = 5)  private String eventCode;
    @Column(name = "REASON_CODE",  length = 10) private String reasonCode;
    @Column(name = "EVENT_DATE")                private LocalDate eventDate;
    @Column(name = "EVENT_TIME",   length = 6)  private String eventTime;
    @Column(name = "LOCATION",     length = 100) private String location;
    @Column(name = "CHANNEL",      length = 10) private String channel;
    @Column(name = "CHANNEL_ADDR", length = 100) private String channelAddr;
    @Column(name = "DELIVERY_INST",length = 35) private String deliveryInst;
    @Column(name = "DESK_CLERK",   length = 35) private String deskClerk;
    @Column(name = "WEIGHT",       length = 7)  private String weight;

    // ── 7 new columns (added via alter_tracking_events.sql) ──────────────
    @Column(name = "PICKUP_PUDO_CODE", length = 9)   private String pickupPudoCode;   // F44
    @Column(name = "DISPOSAL_PLACE",   length = 8)   private String disposalPlace;    // F42
    @Column(name = "NEW_DELIVERY_DATE")              private LocalDate newDeliveryDate;// F43
    @Column(name = "LENGTH_CM",        length = 3)   private String lengthCm;         // F48
    @Column(name = "WIDTH_CM",         length = 3)   private String widthCm;          // F49
    @Column(name = "HEIGHT_CM",        length = 3)   private String heightCm;         // F50
    @Column(name = "POD_IMAGE_URL",    length = 150) private String podImageUrl;       // F51

    @Lob
    @Column(name = "RAW_LINE")
    private String rawLine;

    @Column(name = "CREATED_AT")
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
}
