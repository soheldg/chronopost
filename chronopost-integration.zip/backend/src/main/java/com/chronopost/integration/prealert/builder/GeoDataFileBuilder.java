package com.chronopost.integration.prealert.builder;

import com.chronopost.integration.common.config.ChronopostConfig;
import com.chronopost.integration.common.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Builds GEODATA flat file for pre-alert
 *
 * File structure:
 *   #FILE
 *   #ENCODING ISO-8859-1
 *   #VERSION 03.32
 *   #DEFINITION (constant lines)
 *   HEADER
 *   CONSOLIDATION  (1 per file)
 *   SHIPMENT       (n per consolidation)
 *   SENDER         (1 per shipment)
 *   RECEIVER       (1 per shipment)
 *   INTER          (0,1 per shipment)
 *   INTERINVOICELINE (0,99 per shipment)
 *   PARCEL         (1,m per shipment)
 *   #END
 *
 * As per Doc 1 - GEODATA V3.3.2
 * Fields separated by semicolon (;)
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class GeoDataFileBuilder {

    private final ChronopostConfig config;

    private static final String SEP  = ";";
    private static final String CRLF = "\r\n";
    private static final DateTimeFormatter DATE_FMT =
        DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter TIME_FMT =
        DateTimeFormatter.ofPattern("HHmmss");
    private static final DateTimeFormatter DATETIME_FMT =
        DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    /**
     * Build complete GEODATA file content for a single shipment
     *
     * @param shipment  fully loaded shipment with sender, receiver,
     *                  parcels, customs, invoice lines
     * @param fileName  the file name (used in #FILE line)
     * @param mawb      Master Airwaybill (for air traffic)
     * @return complete file content as String (ISO-8859-1 compatible)
     */
    public String build(Shipment shipment, String fileName, String mawb) {
        log.debug("Building GEODATA file for shipment: {}",
                  shipment.getId());

        StringBuilder sb = new StringBuilder();

        // ─── HEADER SECTION ──────────────────────────────────────────
        appendHeaderSection(sb, fileName);

        // ─── BODY SECTION ────────────────────────────────────────────
        appendHeader(sb);
        appendConsolidation(sb, shipment, mawb);

        // One SHIPMENT/SENDER/RECEIVER/INTER/PARCEL block per shipment
        appendShipment(sb, shipment);
        appendSender(sb, shipment.getSender());
        appendReceiver(sb, shipment.getReceiver());

        if (shipment.getCustoms() != null) {
            appendInter(sb, shipment.getCustoms(), shipment.getReceiver());

            List<InvoiceLine> lines = shipment.getInvoiceLines();
            if (lines != null && !lines.isEmpty()) {
                lines.forEach(line -> appendInterInvoiceLine(sb, line));
            }
        }

        if (shipment.getParcels() != null) {
            shipment.getParcels()
                .forEach(p -> appendParcel(sb, p));
        }

        // ─── END SECTION ─────────────────────────────────────────────
        sb.append("#END").append(CRLF);

        log.debug("GEODATA file built, length: {} chars", sb.length());
        return sb.toString();
    }

    // =====================================================================
    // HEADER SECTION  (lines starting with #)
    // =====================================================================

    private void appendHeaderSection(StringBuilder sb, String fileName) {
        // #FILE
        sb.append("#FILE").append(SEP)
          .append(safe(fileName)).append(CRLF);

        // #ENCODING
        sb.append("#ENCODING").append(SEP)
          .append(config.getGeodata().getEncoding()).append(CRLF);

        // #VERSION
        sb.append("#VERSION").append(SEP)
          .append(config.getGeodata().getVersion()).append(CRLF);

        // #DEFINITION (constant lines that drive decoding)
        appendDefinition(sb);
    }

    private void appendDefinition(StringBuilder sb) {
        // Standard DEFINITION lines - these are constant
        sb.append("#DEF").append(SEP)
          .append("GEODATA:FILE").append(SEP).append(SEP).append(CRLF);

        sb.append("#DEF").append(SEP)
          .append("GEODATA:ENCODING").append(SEP).append(SEP).append(CRLF);

        sb.append("#DEF").append(SEP)
          .append("GEODATA:VERSION").append(SEP).append(SEP).append(CRLF);

        sb.append("#DEF").append(SEP)
          .append("GEODATA:HEADER").append(SEP)
          .append("VERSION").append(SEP)
          .append("CLASSIFICATION").append(CRLF);

        sb.append("#DEF").append(SEP)
          .append("GEODATA:CONSOLIDATION").append(SEP)
          .append("NUMORDER").append(SEP)
          .append("MAWB").append(SEP)
          .append("MAWBDATE").append(SEP)
          .append("FLIGHTNO").append(SEP)
          .append("FAIR").append(SEP)
          .append("TAIR").append(SEP)
          .append("LINEHAUL").append(SEP)
          .append("DEPDATETIME").append(SEP)
          .append("ARRDATETIME").append(SEP)
          .append("BAGMAWB").append(SEP)
          .append("FREIGHTPOSITION").append(SEP)
          .append("CGATEWAYEXP").append(SEP)
          .append("CGATEWAYIMP").append(SEP)
          .append("OPCODE").append(SEP)
          .append("FREIGHTSEQ").append(SEP)
          .append("LORRY").append(SEP)
          .append("CCCREF").append(SEP)
          .append("MAWBDEADWEIGHT").append(SEP)
          .append("MAWBVOLUMETRICWEIGHT").append(SEP)
          .append("SEALNUMBER").append(SEP)
          .append("CONSOMRN").append(SEP)
          .append("TRANSPORTCOST").append(SEP)
          .append("TRANSPORTCOSTCUR").append(SEP)
          .append("REASONFOREXPORT").append(CRLF);

        // SHIPMENT definition
        sb.append("#DEF").append(SEP)
          .append("GEODATA:SHIPMENT").append(SEP)
          .append("NUMORDER").append(SEP)
          .append("MPSID").append(SEP)
          .append("CUSTOMSREF").append(SEP)
          .append("MPSIDCCKEY").append(SEP)
          .append("MPSCOMP").append(SEP)
          .append("MPSCREF1").append(SEP)
          .append("MPSCREF2").append(SEP)
          .append("MPSCREF3").append(SEP)
          .append("MPSCREF4").append(SEP)
          .append("MPSBILLREF").append(SEP)
          .append("MPSCOUNT").append(SEP)
          .append("MPSVOLUME").append(SEP)
          .append("MPSWEIGHT").append(SEP)
          .append("SDEPOT").append(SEP)
          .append("CDATE").append(SEP)
          .append("CTIME").append(SEP)
          .append("HARDWARE").append(SEP)
          .append("RDEPOT").append(SEP)
          .append("DSORT").append(SEP)
          .append("SPTDATE").append(SEP)
          .append("SPTTIME").append(SEP)
          .append("DELMODALLOW").append(SEP)
          .append("OPCODE").append(SEP)
          .append("SYSDEPOT").append(SEP)
          .append("DATADATETIME").append(SEP)
          .append("TIMEZONE").append(CRLF);
    }

    // =====================================================================
    // BODY — HEADER subtype
    // =====================================================================

    private void appendHeader(StringBuilder sb) {
        // Token: GEODATA:HEADER ; VERSION ; CLASSIFICATION
        sb.append("HEADER").append(SEP)
          .append(config.getGeodata().getVersion()).append(SEP)
          .append("CONSO")                          // always CONSO
          .append(CRLF);
    }

    // =====================================================================
    // BODY — CONSOLIDATION subtype (1 per file)
    // ID 001-028 per spec
    // =====================================================================

    private void appendConsolidation(StringBuilder sb,
                                      Shipment shipment,
                                      String mawb) {
        boolean isAir  = "AI".equals(shipment.getLinehaul());
        boolean isRoad = "RO".equals(shipment.getLinehaul());

        sb.append("CONSOLIDATION").append(SEP) // 001
          .append("2").append(SEP)                      // 002 NUMORDER
          .append(isAir ? safe(mawb) : "").append(SEP) // 003 MAWB
          .append(isAir ? today() : "").append(SEP)     // 004 MAWBDATE
          .append("").append(SEP)                        // 005 FLIGHTNO
          .append("").append(SEP)                        // 006 FAIR
          .append("").append(SEP)                        // 007 TAIR
          .append(safe(shipment.getLinehaul())).append(SEP) // 008 LINEHAUL
          .append("").append(SEP)                        // 009 DEPDATETIME
          .append("").append(SEP)                        // 010 ARRDATETIME
          .append("").append(SEP)                        // 011 BAGMAWB
          .append("").append(SEP)                        // 012 FREIGHTPOSITION
          .append(config.getDepot().getSender()).append(SEP)   // 013 CGATEWAYEXP
          .append(config.getDepot().getReceiver()).append(SEP) // 014 CGATEWAYIMP
          .append("INS").append(SEP)                     // 015 OPCODE
          .append("").append(SEP)                        // 016 FREIGHTSEQ
          .append("").append(SEP)                        // 017 LORRY
          .append("").append(SEP)                        // 018 CCCREF
          .append("").append(SEP)                        // 019 MAWBDEADWEIGHT
          .append("").append(SEP)                        // 020 MAWBVOLUMETRICWEIGHT
          .append("").append(SEP)                        // 021 SEALNUMBER
          .append("").append(SEP)                        // 022 CONSOMRN
          .append("").append(SEP)                        // 023 TRANSPORTCOST
          .append("").append(SEP)                        // 024 TRANSPORTCOSTCUR
          .append("").append(SEP)                        // 025 SEALOADPORT
          .append("").append(SEP)                        // 026 SEADISCPORT
          .append("").append(SEP)                        // 027 SEAVESSELNAME
          .append("")                                    // 028 SEAORIGPORTNAT
          .append(CRLF);
    }

    // =====================================================================
    // BODY — SHIPMENT subtype
    // =====================================================================

    private void appendShipment(StringBuilder sb, Shipment s) {
        String cdateStr = s.getCdate() != null
            ? s.getCdate().format(DATE_FMT) : today();
        String ctimeStr = s.getCtime() != null ? s.getCtime() : now6();
        String sptDate  = s.getSptdate() != null
            ? s.getSptdate().format(DATE_FMT) : cdateStr;

        sb.append("SHIPMENT").append(SEP)  // 001
          .append("3").append(SEP)                  // 002 NUMORDER
          .append(safe(s.getMpsId())).append(SEP)  // 003 MPSID
          .append("").append(SEP)                   // 004 CUSTOMSREF
          .append(safe(s.getMpsIdCcKey())).append(SEP) // 005 MPSIDCCKEY
          .append("0").append(SEP)                  // 006 MPSCOMP (default 0)
          .append("").append(SEP)                   // 007 MPSCREF1
          .append("").append(SEP)                   // 008 MPSCREF2
          .append("").append(SEP)                   // 009 MPSCREF3
          .append("").append(SEP)                   // 010 MPSCREF4
          .append("").append(SEP)                   // 011 MPSBILLREF
          .append(s.getMpscount()).append(SEP)      // 012 MPSCOUNT
          .append(safe(s.getMpsvolume())).append(SEP) // 013 MPSVOLUME
          .append(gramsToDecagram(s.getMpsweight())).append(SEP) // 014 MPSWEIGHT (Decagram = g/10, e.g. 2000g → 200)
          .append(config.getDepot().getSender()).append(SEP)   // 015 SDEPOT
          .append(cdateStr).append(SEP)             // 016 CDATE
          .append(ctimeStr).append(SEP)             // 017 CTIME
          .append("K").append(SEP)                  // 018 HARDWARE
          .append("").append(SEP)                   // 019 RDEPOT
          .append("").append(SEP)                   // 020 DSORT
          .append(sptDate).append(SEP)              // 021 SPTDATE
          .append(ctimeStr).append(SEP)             // 022 SPTTIME
          .append("").append(SEP)                   // 023 SPTREALDATE
          .append("").append(SEP)                   // 024 SPTREALTIME
          .append("1").append(SEP)                  // 025 DELMODALLOW
          .append("").append(SEP)                   // 026 ROUTINGPLANVERSION
          .append("").append(SEP)                   // 027 SPARTNERREF1
          .append("").append(SEP)                   // 028 SPARTNERREF2
          .append("").append(SEP)                   // 029 SPARTNERCODE
          .append("").append(SEP)                   // 030 OSORT
          .append("").append(SEP)                   // 031 SSORT
          .append("").append(SEP)                   // 032 MSORT
          .append("").append(SEP)                   // 033 COLREQUESTFLAG
          .append("").append(SEP)                   // 034 ROUTINGPLACE
          .append("").append(SEP)                   // 035 ORIGINMPSID
          .append("INS").append(SEP)                // 036 OPCODE
          .append(config.getDepot().getReceiver()).append(SEP) // 037 SYSDEPOT
          .append(nowDatetime()).append(SEP)         // 038 DATADATETIME
          .append(safe(s.getTimezone()))             // 039 TIMEZONE
          .append(CRLF);
    }

    // =====================================================================
    // BODY — SENDER subtype
    // =====================================================================

    private void appendSender(StringBuilder sb, Sender s) {
        sb.append("SENDER").append(SEP)            // 001
          .append("4").append(SEP)                          // 002 NUMORDER
          .append(safe(s.getAccountNo())).append(SEP)      // 003 SCUSTACCNUMBER
          .append(safe(s.getSubAccountNo())).append(SEP)   // 004 SCUSTSUBACCNUMBER
          .append(safe(s.getCompanyName())).append(SEP)    // 005 SCOMPNAME
          .append("").append(SEP)                           // 006 SUNIQCUSTID
          .append(safe(s.getName1())).append(SEP)          // 007 SNAME1
          .append(safe(s.getName2())).append(SEP)          // 008 SNAME2
          .append(safe(s.getStreet())).append(SEP)         // 009 SSTREET
          .append(safe(s.getPropNum())).append(SEP)        // 010 SPROPNUM
          .append(safe(s.getAdd2())).append(SEP)           // 011 SADD2
          .append("").append(SEP)                           // 012 SADD3
          .append("").append(SEP)                           // 013 SFLOOR
          .append("").append(SEP)                           // 014 SBUILDING
          .append("").append(SEP)                           // 015 SDEPARTMENT
          .append(safe(s.getCountryCode())).append(SEP)    // 016 SCOUNTRYCODE
          .append(safe(s.getState())).append(SEP)          // 017 SSTATE
          .append(safe(s.getZipcode())).append(SEP)        // 018 SZIPCODE
          .append(safe(s.getTown())).append(SEP)           // 019 STOWN
          .append("").append(SEP)                           // 020 SCONTACT
          .append(safe(s.getPhone())).append(SEP)          // 021 SPHONE
          .append(safe(s.getFax())).append(SEP)            // 022 SFAX (if any)
          .append(safe(s.getEmail())).append(SEP)          // 023 SEMAIL
          .append("").append(SEP)                           // 024 SCOMMENT
          .append("").append(SEP)                           // 025 SGLN
          .append("").append(SEP)                           // 026 SGPSLAT
          .append("").append(SEP)                           // 027 SGPSLONG
          .append(safe(s.getAccountOwner())).append(SEP)   // 028 SACCOUNTOWNER
          .append(safe(s.getBusinessType())).append(SEP)   // 029 SBUSINESS
          .append(safe(s.getSellingWebsite())).append(SEP) // 030 SENDERWEBSITE
          .append(safe(s.getEori())).append(SEP)           // 031 SEORI
          .append(safe(s.getVatNo())).append(SEP)          // 032 SVATNO
          .append("").append(SEP)                           // 033 STAXEIDTYPE
          .append("")                                       // 034 STAXEIDVALUE
          .append(CRLF);
    }

    // =====================================================================
    // BODY — RECEIVER subtype
    // =====================================================================

    private void appendReceiver(StringBuilder sb, Receiver r) {
        sb.append("RECEIVER").append(SEP)           // 001
          .append("4").append(SEP)                           // 002 NUMORDER
          .append("").append(SEP)                            // 003 RCUSTID
          .append(safe(r.getName1())).append(SEP)           // 004 RNAME1
          .append(safe(r.getName2())).append(SEP)           // 005 RNAME2
          .append(safe(r.getCompanyName())).append(SEP)     // 006 RCOMPNAME
          .append("").append(SEP)                            // 007 RCOMPNAME2
          .append(safe(r.getPudoId())).append(SEP)          // 008 RPUDOID
          .append(safe(r.getStreet())).append(SEP)          // 009 RSTREET
          .append(safe(r.getPropNum())).append(SEP)         // 010 RPROPNUM
          .append(safe(r.getAdd2())).append(SEP)            // 011 RADD2
          .append("").append(SEP)                            // 012 RADD3
          .append("").append(SEP)                            // 013 RFLOOR
          .append("").append(SEP)                            // 014 RBUILDING
          .append("").append(SEP)                            // 015 RDEPARTMENT
          .append(safe(r.getCountryCode())).append(SEP)     // 016 RCOUNTRYCODE
          .append(safe(r.getState())).append(SEP)           // 017 RSTATE
          .append(safe(r.getZipcode())).append(SEP)         // 018 RZIPCODE
          .append(safe(r.getTown())).append(SEP)            // 019 RTOWN
          .append(safe(r.getDoorCode())).append(SEP)        // 020 RDOORCODE
          .append("").append(SEP)                            // 021 RCONTACT
          .append(safe(r.getPhone1())).append(SEP)          // 022 RCONTACTPHO1
          .append(safe(r.getPhone2())).append(SEP)          // 023 RCONTACTPHO2
          .append("").append(SEP)                            // 024 RINTERPHONENAME
          .append("").append(SEP)                            // 025 RFAX
          .append(safe(r.getEmail())).append(SEP)           // 026 REMAIL
          .append("").append(SEP)                            // 027 RCOMMENT
          .append("").append(SEP)                            // 028 RGPSLAT
          .append("").append(SEP)                            // 029 RGPSLONG
          .append(safe(r.getBusinessType())).append(SEP)    // 030 RBUSINESS
          .append(safe(r.getEori())).append(SEP)            // 031 REORI
          .append(safe(r.getVatNo())).append(SEP)           // 032 RVATNO
          .append("").append(SEP)                            // 033 RTAXEIDTYPE
          .append("").append(SEP)                            // 034 RTAXEIDVALUE
          .append("")                                        // 035 RFISCALVATREPRESENTANT
          .append(CRLF);
    }

    // =====================================================================
    // BODY — INTER subtype (customs)
    // =====================================================================

    private void appendInter(StringBuilder sb, Customs c, Receiver receiver) {
        // FIX: fallback to receiver address when clearance address not set
        // This handles existing shipments created before the auto-fill fix
        String cName1       = nvl(c.getCName1(),       receiver != null ? nvl(receiver.getName1(), receiver.getCompanyName()) : "");
        String cStreet      = nvl(c.getCStreet(),      receiver != null ? receiver.getStreet()      : "");
        String cCountryCode = nvl(c.getCCountryCode(), receiver != null ? receiver.getCountryCode() : "");
        String cZipcode     = nvl(c.getCZipcode(),     receiver != null ? receiver.getZipcode()     : "");
        String cTown        = nvl(c.getCTown(),        receiver != null ? receiver.getTown()         : "");
        String cPhone       = nvl(c.getCPhone(),       receiver != null ? receiver.getPhone1()       : "");
        String cEmail       = nvl(c.getCEmail(),       receiver != null ? receiver.getEmail()        : "");
        // FIX: prealertStatus default S04
        String prealertStatus = nvl(c.getPrealertStatus(), "S04");

        sb.append("INTER").append(SEP)              // 001
          .append("4").append(SEP)                           // 002 NUMORDER
          .append(safe(c.getParcelType())).append(SEP)      // 003 PARCELTYPE
          .append(safe(c.getCustomsAmount())).append(SEP)   // 004 CAMOUNT
          .append(safe(c.getCurrency())).append(SEP)        // 005 CURRENCY
          .append(safe(c.getCustomsAmountEx())).append(SEP) // 006 CAMOUNTEX
          .append(safe(c.getCurrencyEx())).append(SEP)      // 007 CURRENCYEX
          .append(safe(c.getIncoterms())).append(SEP)       // 008 CTERMS
          .append("").append(SEP)                            // 009 CPAPER
          .append("").append(SEP)                            // 010 CCOMMENT
          .append(safe(c.getClearanceStatus())).append(SEP) // 011 CLEARANCECLEARED
          .append(safe(c.getHighLowValue())).append(SEP)    // 012 HIGHLOWVALUE
          .append(safe(prealertStatus)).append(SEP)  // 013 PREALERTSTATUS (S03/S04/S05)
          .append(safe(c.getInvoiceNo())).append(SEP)       // 014 CINVOICE
          .append(c.getInvoiceDate() != null
                  ? c.getInvoiceDate().format(DATE_FMT)
                  : "").append(SEP)                          // 015 CINVOICEDATE
          .append(safe(cName1)).append(SEP)          // 016 CNAME1
          .append("").append(SEP)                            // 017 CNAME2
          .append(safe(cStreet)).append(SEP)         // 018 CSTREET
          .append("").append(SEP)                            // 019 CPROPNUM
          .append(safe(cCountryCode)).append(SEP)    // 020 CCOUNTRYCODE
          .append("").append(SEP)                            // 021 CSTATE
          .append(safe(cZipcode)).append(SEP)        // 022 CZIPCODE
          .append(safe(cTown)).append(SEP)           // 023 CTOWN
          .append("").append(SEP)                            // 024 CGPSLAT
          .append("").append(SEP)                            // 025 CGPSLONG
          .append(safe(c.getCContact())).append(SEP)        // 026 CCONTACT
          .append(safe(cPhone)).append(SEP)          // 027 CPHONE
          .append("").append(SEP)                            // 028 CFAX
          .append(safe(cEmail)).append(SEP)          // 029 CEMAIL
          .append("").append(SEP)                            // 030 CGLN
          .append(safe(c.getCVatNo())).append(SEP)          // 031 CVATNO
          .append("").append(SEP)                            // 032 CNUMBER
          .append("").append(SEP)                            // 033 SHIPMRN
          .append("").append(SEP)                            // 034 CEORI
          .append(safe(c.getSiName1())).append(SEP)         // 035 SINAME1
          .append("").append(SEP)                            // 036 SINAME2
          .append(safe(c.getSiStreet())).append(SEP)        // 037 SISTREET
          .append("").append(SEP)                            // 038 SIPROPNUM
          .append(safe(c.getSiCountryCode())).append(SEP)   // 039 SICOUNTRYCODE
          .append("").append(SEP)                            // 040 SISTATE
          .append(safe(c.getSiZipcode())).append(SEP)       // 041 SIZIPCODE
          .append(safe(c.getSiTown())).append(SEP)          // 042 SITOWN
          .append("").append(SEP)                            // 043 SIGPSLAT
          .append("").append(SEP)                            // 044 SIGPSLONG
          .append("").append(SEP)                            // 045 SICONTACT
          .append("").append(SEP)                            // 046 SIPHONE
          .append("INS").append(SEP)                         // 047 OPCODE
          .append(safe(c.getNumberOfArticle())).append(SEP) // 048 NUMBEROFARTICLE
          .append(safe(c.getDestCountryReg())).append(SEP)  // 049 DESTCOUNTRYREG
          .append(safe(c.getSiEori())).append(SEP)          // 050 SIEORI
          .append(safe(c.getReasonForExport()))              // 051 REASONFOREXPORT
          .append(CRLF);
    }

    // =====================================================================
    // BODY — INTERINVOICELINE subtype
    // =====================================================================

    private void appendInterInvoiceLine(StringBuilder sb, InvoiceLine line) {
        sb.append("INTERINVOICELINE").append(SEP)    // 001
          .append("5").append(SEP)                             // 002 NUMORDER
          .append(safe(line.getPosition())).append(SEP)       // 003 CINVOICEPOSITION
          .append(safe(line.getQuantity())).append(SEP)       // 004 QITEMS
          .append(safe(line.getContent())).append(SEP)        // 005 CCONTENT
          .append(safe(line.getAmount())).append(SEP)         // 006 CAMOUNTLINE
          .append("").append(SEP)                              // 007 CCOMMENT
          .append(safe(line.getCountryOrigin())).append(SEP)  // 008 CORIGIN
          .append(safe(line.getNetWeight())).append(SEP)      // 009 CNETWEIGHT
          .append(safe(line.getGrossWeight())).append(SEP)    // 010 CGROSSWEIGHT
          .append(safe(line.getProdCode())).append(SEP)       // 011 CPRODCODE
          .append(safe(line.getProdType())).append(SEP)       // 012 CRPRODTYPE
          .append(safe(line.getFabricComposition())).append(SEP) // 013 CFABRICCOMPOSITION
          .append(safe(line.getHsCodeRecv())).append(SEP)    // 014 RCTARIF
          .append(safe(line.getHsCodeSend())).append(SEP)    // 015 SCTARIF
          .append(safe(line.getGoodsWebpage()))               // 016 GOODSWEBPAGE
          .append(CRLF);
    }

    // =====================================================================
    // BODY — PARCEL subtype
    // =====================================================================

    private void appendParcel(StringBuilder sb, Parcel p) {
        sb.append("PARCEL").append(SEP)               // 001
          .append("5").append(SEP)                             // 002 NUMORDER
          .append(safe(p.getParcelNumber())).append(SEP)      // 003 PARCELNUMBER
          .append(safe(p.getParcelCcKey())).append(SEP)       // 004 PARCELNUMBERCCKEY
          .append(safe(p.getParcelRank())).append(SEP)        // 005 PARCELRANK
          .append("").append(SEP)                              // 006 SENDPARCELREF1
          .append("").append(SEP)                              // 007 SENDPARCELREF2
          .append("").append(SEP)                              // 008 SENDPARCELREF3
          .append("").append(SEP)                              // 009 SENDPARCELREF4
          .append("").append(SEP)                              // 010 RECPARCELREF
          .append(safe(p.getServiceCode())).append(SEP)       // 011 SERVICECODE
          .append("").append(SEP)                              // 012 PPARTNERREF1
          .append("").append(SEP)                              // 013 PPARTNERREF2
          .append("").append(SEP)                              // 014 PPARTNERREF3
          .append("").append(SEP)                              // 015 PPARTNERREF4
          .append(safe(p.getDimension())).append(SEP)         // 016 DIMENSION
          .append(safe(p.getDeclaredWeight())).append(SEP)    // 017 DECLAREDWEIGHT
          .append(safe(p.getMeasuredWeight())).append(SEP)    // 018 MEASUREDWEIGHT
          .append(safe(p.getInsAmount())).append(SEP)         // 019 HINSAMOUNT
          .append(safe(p.getInsCurrency())).append(SEP)       // 020 HINSCURRENCY
          .append("").append(SEP)                              // 021 HINSCONTENT
          .append(safe(p.getHazlq())).append(SEP)             // 022 HAZLQ
          .append(safe(p.getHzdPackCode())).append(SEP)       // 023 HZDPACKCODE
          .append("INS").append(SEP)                           // 024 OPCODE
          .append(safe(p.getContent())).append(SEP)           // 025 PCONTENT
          .append("").append(SEP)                              // 026 ORIGINPARCELNUMBER
          .append("CHR").append(SEP)                           // 027 POWNERBU
          .append("").append(SEP)                              // 028 PPARTNERCODE
          .append(safe(p.getAscode())).append(SEP)            // 029 ASCODE
          .append("").append(SEP)                              // 030 BAGNO
          .append("").append(SEP)                              // 031 CIFCOST
          .append("")                                          // 032 CIFCOSTCUR
          .append(CRLF);
    }

    // =====================================================================
    // HELPERS
    // =====================================================================

    /**
     * Resolve PREALERTSTATUS value per Doc 1:
     *   S03 = pre-alert sent BEFORE departure day
     *   S04 = pre-alert sent ON departure day (most common)
     *   S05 = pre-alert sent AFTER departure (late — avoid)
     * If explicitly set in customs, use it; otherwise default to S04.
     */
    private String resolvePrealertStatus(String status) {
        if (status != null && status.matches("S0[345]")) {
            return status;
        }
        return "S04";  // default: sent on departure day
    }

    /**
     * Convert grams to Decagram for MPSWEIGHT field
     * Doc 1 §MPSWEIGHT: "Shipment weight in Decagram (10 Grams)"
     * e.g. 2000g → 200 dg, 3000g → 300 dg
     */
    private String gramsToDecagram(Long grams) {
        if (grams == null) return "";
        return String.valueOf(grams / 10);
    }

    /** null-safe: return empty string for null values */
    private String nvl(String value, String fallback) {
        return (value != null && !value.isBlank())
               ? value.trim()
               : (fallback != null ? fallback.trim() : "");
    }

    private String safe(Object val) {
        if (val == null) return "";
        String s = val.toString().trim();
        // Remove semicolons from field values (would break parsing)
        return s.replace(";", " ");
    }

    private String today() {
        return LocalDate.now().format(DATE_FMT);
    }

    private String now6() {
        return LocalDateTime.now().format(TIME_FMT);
    }

    private String nowDatetime() {
        return LocalDateTime.now().format(DATETIME_FMT);
    }
}
