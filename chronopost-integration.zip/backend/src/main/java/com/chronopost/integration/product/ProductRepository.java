package com.chronopost.integration.product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    /** Find primary product by service code and nat/inter flag */
    Optional<Product> findByCodeGeopostAndNatInterAndIsPrimary(
        Integer codeGeopost, String natInter, String isPrimary);

    /** Find by code only — returns first primary match */
    Optional<Product> findFirstByCodeGeopostAndIsPrimary(
        Integer codeGeopost, String isPrimary);
}
