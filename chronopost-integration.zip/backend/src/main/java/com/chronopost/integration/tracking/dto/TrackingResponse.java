package com.chronopost.integration.tracking.dto;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TrackingResponse {
    private String parcelNumber, geopostTrackingId, currentStatus;
    private boolean isDelivered;
    private int totalEvents;
    private List<TrackingEventItem> events;
}
