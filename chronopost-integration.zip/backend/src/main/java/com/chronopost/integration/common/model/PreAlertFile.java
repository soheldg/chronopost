package com.chronopost.integration.common.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name="CHR_PREALERT_FILES",schema="CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PreAlertFile {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="chr_seq")
    @SequenceGenerator(name="chr_seq",sequenceName="CHR_SEQ",allocationSize=1)
    private Long id;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="SHIPMENT_ID",nullable=false)
    private Shipment shipment;
    @Column(name="FILE_NAME",nullable=false,length=255) private String fileName;
    @Lob @Column(name="FILE_CONTENT") private String fileContent;
    @Column(name="FTP_STATUS",length=20) @Builder.Default private String ftpStatus="PENDING";
    @Column(name="ERROR_MSG",length=500) private String errorMsg;
    @Column(name="SENT_AT") private LocalDateTime sentAt;
    @Column(name="CREATED_AT") @Builder.Default private LocalDateTime createdAt=LocalDateTime.now();
}
