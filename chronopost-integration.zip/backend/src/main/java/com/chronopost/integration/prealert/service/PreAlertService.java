package com.chronopost.integration.prealert.service;

import com.chronopost.integration.common.config.ChronopostConfig;
import com.chronopost.integration.common.model.*;
import com.chronopost.integration.common.repository.ShipmentRepository;
import com.chronopost.integration.prealert.builder.GeoDataFileBuilder;
import com.chronopost.integration.prealert.dto.*;
import com.chronopost.integration.prealert.sftp.SftpService;
import com.chronopost.integration.prealert.validator.PreAlertValidator;
import com.chronopost.integration.common.repository.PreAlertFileRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Pre-Alert Service
 *
 * Orchestrates the full pre-alert flow:
 * 1. Load shipment data from DB
 * 2. Validate all fields
 * 3. Build GEODATA flat file
 * 4. Generate file name
 * 5. Save to DB (CHR_PREALERT_FILES)
 * 6. Upload to Chronopost SFTP /IN
 * 7. Update shipment status → PREALERT_SENT
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class PreAlertService {

    private final ShipmentRepository shipmentRepo;
    private final PreAlertValidator   validator;
    private final GeoDataFileBuilder  fileBuilder;
    private final SftpService         sftpService;
    private final ChronopostConfig    config;

    // File sequence counter (per day, reset at midnight - simplified)
    private final AtomicInteger fileSeq = new AtomicInteger(1);

    private static final DateTimeFormatter DATE_FMT =
        DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter TIME_FMT =
        DateTimeFormatter.ofPattern("HHmmss");

    // =====================================================================
    // GENERATE pre-alert file (without sending)
    // =====================================================================

    /**
     * Generate GEODATA file for a shipment (validate + build, don't send yet)
     */
    @Transactional
    public PreAlertResponse generate(Long shipmentId) {
        log.info("Generating pre-alert for shipment: {}", shipmentId);

        // ─── 1. Load shipment ─────────────────────────────────────────
        Shipment shipment = loadFullShipment(shipmentId);

        // ─── 2. Validate ──────────────────────────────────────────────
        List<String> errors = validator.validate(shipment);
        if (!errors.isEmpty()) {
            log.warn("Validation failed for shipment {}: {}",
                     shipmentId, errors);
            return PreAlertResponse.builder()
                .shipmentId(shipmentId)
                .success(false)
                .errors(errors)
                .build();
        }

        // ─── 3. Generate file name ────────────────────────────────────
        String fileName = buildFileName(shipment);

        // ─── 4. Build GEODATA file content ────────────────────────────
        String fileContent = fileBuilder.build(shipment, fileName, null);

        // ─── 5. Save to DB (idempotent — overwrite existing PENDING file) ──
        PreAlertFile preAlertFile = PreAlertFile.builder()
            .shipment(shipment)
            .fileName(fileName)
            .fileContent(fileContent)
            .ftpStatus("PENDING")
            .build();

        preAlertFileRepo.save(preAlertFile);

        log.info("Pre-alert file generated and saved: {} ({} chars)",
                 fileName, fileContent.length());

        return PreAlertResponse.builder()
            .shipmentId(shipmentId)
            .fileName(fileName)
            .fileContent(fileContent)
            .success(true)
            .ftpStatus("PENDING")
            .build();
    }

    // =====================================================================
    // SEND pre-alert file to Chronopost SFTP
    // =====================================================================

    /**
     * Send pre-alert file to Chronopost SFTP /IN directory
     */
    @Transactional
    public PreAlertResponse send(Long shipmentId) {
        log.info("Sending pre-alert for shipment: {}", shipmentId);

        // Generate file first
        PreAlertResponse generated = generate(shipmentId);
        if (!generated.isSuccess()) {
            return generated;
        }

        // ─── Upload to FTP ────────────────────────────────────────────
        boolean uploaded = sftpService.uploadTextFile(
            generated.getFileName(),
            generated.getFileContent()
        );

        if (!uploaded) {
            log.error("FTP upload failed for: {}", generated.getFileName());
            return PreAlertResponse.builder()
                .shipmentId(shipmentId)
                .fileName(generated.getFileName())
                .success(false)
                .ftpStatus("FAILED")
                .errors(List.of("FTP upload failed"))
                .build();
        }

        // ─── Update shipment status ───────────────────────────────────
        Shipment shipment = loadFullShipment(shipmentId);
        shipment.setStatus(Shipment.ShipmentStatus.PREALERT_SENT);
        shipmentRepo.save(shipment);

        log.info("Pre-alert sent successfully: {}", generated.getFileName());

        return PreAlertResponse.builder()
            .shipmentId(shipmentId)
            .fileName(generated.getFileName())
            .fileContent(generated.getFileContent())
            .success(true)
            .ftpStatus("SENT")
            .sentAt(LocalDateTime.now().toString())
            .build();
    }

    // =====================================================================
    // GET pre-alert status
    // =====================================================================

    public PreAlertStatusResponse getStatus(Long shipmentId) {
        Shipment shipment = shipmentRepo.findById(shipmentId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Shipment not found: " + shipmentId));

        return PreAlertStatusResponse.builder()
            .shipmentId(shipmentId)
            .mpsId(shipment.getMpsId())
            .shipmentStatus(shipment.getStatus().name())
            .prealertSent("PREALERT_SENT".equals(
                          shipment.getStatus().name()) ||
                          shipment.getStatus().ordinal() >
                          Shipment.ShipmentStatus.PREALERT_SENT.ordinal())
            .build();
    }

    // =====================================================================
    // PRIVATE HELPERS
    // =====================================================================

    private Shipment loadFullShipment(Long shipmentId) {
        return shipmentRepo.findByIdWithDetails(shipmentId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Shipment not found: " + shipmentId));
    }

    /**
     * Build GEODATA file name per spec:
     * GEODATA_CONSO_[account]_CHR_D[date]T[time]_[seq]
     *
     * Example: GEODATA_CONSO_12345678_CHR_D20250401T120000_000001
     */
    private String buildFileName(Shipment shipment) {
        String account = shipment.getSender() != null
            ? shipment.getSender().getAccountNo().replaceAll("[^0-9A-Z]", "")
            : "UNKNOWN";

        LocalDateTime now = LocalDateTime.now();
        String date = now.format(DATE_FMT);
        String time = now.format(TIME_FMT);
        String seq  = String.format("%06d", fileSeq.getAndIncrement());

        return String.format("GEODATA_%s_%s_%s_D%sT%s_%s",
            config.getGeodata().getDataflow(),    // CONSO
            account,
            config.getGeodata().getDestination(), // CHR
            date,
            time,
            seq
        );
    }
}
