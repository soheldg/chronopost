package com.chronopost.integration.shipment.dto;
import lombok.*;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ShipmentCreateResponse {

    private Long             shipmentId;
    private String           mpsId;
    private String           status;
    private String           linehaul;
    private Long             mpsweight;
    private int              parcelCount;
    private String           createdAt;
    private String           message;

    // Full detail objects (for ShipmentDetailPage)
    private SenderDto        sender;
    private ReceiverDto      receiver;
    private List<ParcelDto>  parcels;
    private CustomsDto       customs;
    private List<InvoiceLineDto> invoiceLines;

    // ── Nested DTOs ────────────────────────────────────────────────────

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ParcelInfo {
        private Long   parcelId;
        private int    rank;
        private Long   weightGrams;
        private String labelStatus;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class SenderDto {
        private Long   id;
        private String accountNo, subAccountNo, companyName, name1, name2;
        private String street, add2, zipcode, town, countryCode, state;
        private String phone, fax, email, businessType;
        private String vatNo, eori, sellingWebsite;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ReceiverDto {
        private Long   id;
        private String name1, name2, companyName;
        private String street, add2, zipcode, town, countryCode, state;
        private String doorCode, phone1, phone2, email, businessType, pudoId;
        private String vatNo, eori;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ParcelDto {
        private Long   id;
        private String parcelNumber, geopostTrackId;
        private Integer parcelRank;
        private Long   declaredWeight;
        private String dimension, content, labelStatus, labelPath;
        private String routingBarcode;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CustomsDto {
        private String parcelType, customsAmount, currency;
        private String incoterms, clearanceStatus, reasonForExport;
        private String invoiceNo, highLowValue, prealertStatus;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class InvoiceLineDto {
        private Long   id;
        private String quantity, content, amount, countryOrigin;
        private String hsCodeRecv, hsCodeSend, netWeight, grossWeight;
    }
}
