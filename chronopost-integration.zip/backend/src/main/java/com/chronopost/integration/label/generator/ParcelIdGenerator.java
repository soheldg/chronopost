package com.chronopost.integration.label.generator;

import com.chronopost.integration.common.util.ChecksumUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Generates Chronopost Parcel ID (13 characters)
 * Structure: XXYYYY ZZZZZZ SS
 *   A (5): customer prefix e.g. "HY712" — provided by Chronopost
 *   B (6): counter 000001–999999, persisted in DB (not in-memory)
 *   C (2): product suffix e.g. "JF" — from product file col 15
 *
 * FIX: Counter is now persisted in DB to survive restarts.
 *      Uses CHR_SEQ_COUNTER table to track next counter value.
 *
 * Per spec §4: same parcel ID must not exist twice in 6 months.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class ParcelIdGenerator {

    private final ChecksumUtil checksumUtil;
    private final JdbcTemplate jdbc;

    /**
     * Generate next Chronopost Parcel ID — counter persisted in DB
     */
    @Transactional
    public String generate(String customerPrefix, String productSuffix) {
        validatePrefix(customerPrefix);
        validateSuffix(productSuffix);

        int counter = nextCounter(customerPrefix);
        String counterStr = String.format("%06d", counter);
        String parcelId   = customerPrefix + counterStr + productSuffix;

        log.debug("Generated Parcel ID: {} (counter={})", parcelId, counter);
        return parcelId;
    }

    /**
     * Get next counter value from DB, persist it atomically
     * Resets to 1 after 999999 (never uses 000000)
     */
    private int nextCounter(String prefix) {
        try {
            // Try to get existing row
            Integer current = jdbc.queryForObject(
                "SELECT COUNTER_VAL FROM CHR_PARCEL_COUNTER WHERE PREFIX = ?",
                Integer.class, prefix);

            int next = (current == null || current >= 999999) ? 1 : current + 1;

            jdbc.update(
                "UPDATE CHR_PARCEL_COUNTER SET COUNTER_VAL = ? WHERE PREFIX = ?",
                next, prefix);

            log.debug("Counter for prefix {}: {} → {}", prefix, current, next);
            return next;

        } catch (Exception e) {
            // Row doesn't exist yet — insert it
            jdbc.update(
                "INSERT INTO CHR_PARCEL_COUNTER (PREFIX, COUNTER_VAL) VALUES (?, 1)",
                prefix);
            log.info("Initialized parcel counter for prefix: {}", prefix);
            return 1;
        }
    }

    /**
     * Generate with specific counter (for recreating from DB)
     */
    public String generateWithCounter(String prefix, int counter, String suffix) {
        validatePrefix(prefix);
        validateSuffix(suffix);
        return prefix + String.format("%06d", counter) + suffix;
    }

    /**
     * Extract counter value from existing parcel ID
     */
    public int extractCounter(String parcelId) {
        if (parcelId == null || parcelId.length() != 13)
            throw new IllegalArgumentException("Parcel ID must be 13 chars");
        return Integer.parseInt(parcelId.substring(5, 11));
    }

    /**
     * Calculate control key (CCKEY) for GEODATA PARCELNUMBERCCKEY field
     */
    public char calculateCcKey(String parcelId) {
        return checksumUtil.calculate(parcelId);
    }

    private void validatePrefix(String p) {
        if (p == null || p.length() != 5)
            throw new IllegalArgumentException(
                "Customer prefix must be 5 chars e.g. HY712");
    }

    private void validateSuffix(String s) {
        if (s == null || s.length() != 2)
            throw new IllegalArgumentException(
                "Product suffix must be 2 chars e.g. JF");
    }
}
