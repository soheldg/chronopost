package com.chronopost.integration.prealert.validator;

import com.chronopost.integration.common.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Validates shipment data before GEODATA file generation
 * Based on mandatory field rules from Doc 1 - GEODATA V3.3.2
 */
@Component
@Slf4j
public class PreAlertValidator {

    /**
     * Validate full shipment for pre-alert
     * Returns list of validation errors (empty = valid)
     */
    public List<String> validate(Shipment shipment) {
        List<String> errors = new ArrayList<>();

        validateShipment(shipment, errors);

        if (shipment.getSender() != null) {
            validateSender(shipment.getSender(), errors);
        } else {
            errors.add("SENDER data is missing");
        }

        if (shipment.getReceiver() != null) {
            validateReceiver(shipment.getReceiver(), errors);
        } else {
            errors.add("RECEIVER data is missing");
        }

        if (shipment.getParcels() == null || shipment.getParcels().isEmpty()) {
            errors.add("At least one PARCEL is required");
        } else {
            shipment.getParcels().forEach(p ->
                validateParcel(p, shipment, errors));
        }

        if (shipment.getCustoms() != null) {
            validateCustoms(shipment.getCustoms(), errors);
        }

        validateWeightRules(shipment, errors);

        if (!errors.isEmpty()) {
            log.warn("Validation failed for shipment {}: {} errors",
                     shipment.getId(), errors.size());
        }

        return errors;
    }

    // ─── SHIPMENT ─────────────────────────────────────────────────────
    private void validateShipment(Shipment s, List<String> errors) {
        if (blank(s.getMpsId()))
            errors.add("SHIPMENT.MPSID is mandatory");

        if (s.getMpscount() == null || s.getMpscount() < 1)
            errors.add("SHIPMENT.MPSCOUNT must be >= 1");

        if (s.getCdate() == null)
            errors.add("SHIPMENT.CDATE is mandatory");

        if (blank(s.getCtime()))
            errors.add("SHIPMENT.CTIME is mandatory");

        if (blank(s.getLinehaul()))
            errors.add("SHIPMENT.LINEHAUL is mandatory (AI/RO/SE)");
        else if (!s.getLinehaul().matches("AI|RO|SE"))
            errors.add("SHIPMENT.LINEHAUL must be AI, RO or SE");

        // Road linehaul: LORRY is mandatory per Doc 1
        if ("RO".equals(s.getLinehaul())) {
            // LORRY field in CONSOLIDATION is mandatory for road transport
            // Validated here as a warning — enforced in builder
            log.warn("SHIPMENT.LINEHAUL=RO: ensure LORRY is set in consolidation");
        }
    }

    // ─── SENDER ───────────────────────────────────────────────────────
    private void validateSender(Sender s, List<String> errors) {
        if (blank(s.getAccountNo()))
            errors.add("SENDER.SCUSTACCNUMBER is mandatory");

        if (blank(s.getCompanyName()) && blank(s.getName1()))
            errors.add("SENDER: SCOMPNAME or SNAME1 is mandatory");

        if (blank(s.getStreet()))
            errors.add("SENDER.SSTREET is mandatory");

        if (blank(s.getZipcode()))
            errors.add("SENDER.SZIPCODE is mandatory");

        if (blank(s.getTown()))
            errors.add("SENDER.STOWN is mandatory");

        if (blank(s.getCountryCode()))
            errors.add("SENDER.SCOUNTRYCODE is mandatory");

        if (blank(s.getBusinessType()))
            errors.add("SENDER.SBUSINESS is mandatory (P or B)");
        else if (!s.getBusinessType().matches("[PB]"))
            errors.add("SENDER.SBUSINESS must be P or B");

        // Phone OR email required
        if (blank(s.getPhone()) && blank(s.getEmail()))
            errors.add("SENDER: SPHONE or SEMAIL is mandatory");

        // Business sender extra rules
        // VAT_NO + EORI columns exist in DB and mapped via @Column — validation enabled
        if ("B".equals(s.getBusinessType())) {
            if (blank(s.getEori()) && blank(s.getVatNo()))
                errors.add("SENDER: SEORI or SVATNO is mandatory for Business");
            if (blank(s.getSellingWebsite()))
                log.warn("SENDER.SENDERWEBSITE recommended for B2B senders");
        }

        // ZIP format check
        if (!blank(s.getZipcode()) &&
            !s.getZipcode().matches("[0-9A-Z]{1,9}"))
            errors.add("SENDER.SZIPCODE: only 0-9A-Z allowed");
    }

    // ─── RECEIVER ─────────────────────────────────────────────────────
    private void validateReceiver(Receiver r, List<String> errors) {
        if (blank(r.getName1()) && blank(r.getCompanyName()))
            errors.add("RECEIVER: RNAME1 or RCOMPNAME is mandatory");

        if (blank(r.getStreet()))
            errors.add("RECEIVER.RSTREET is mandatory");

        if (blank(r.getZipcode()))
            errors.add("RECEIVER.RZIPCODE is mandatory");

        if (blank(r.getTown()))
            errors.add("RECEIVER.RTOWN is mandatory");

        if (blank(r.getCountryCode()))
            errors.add("RECEIVER.RCOUNTRYCODE is mandatory");

        if (blank(r.getBusinessType()))
            errors.add("RECEIVER.RBUSINESS is mandatory (P or B)");
        else if (!r.getBusinessType().matches("[PB]"))
            errors.add("RECEIVER.RBUSINESS must be P or B");

        // Phone OR email required
        if (blank(r.getPhone1()) && blank(r.getEmail()))
            errors.add("RECEIVER: RCONTACTPHO1 or REMAIL is mandatory");

        // Business receiver extra rules
        if ("B".equals(r.getBusinessType())) {
            if (blank(r.getEori()) && blank(r.getVatNo()))
                errors.add("RECEIVER: REORI or RVATNO mandatory for Business");
        }

        // ZIP format check
        if (!blank(r.getZipcode()) &&
            !r.getZipcode().matches("[0-9A-Z]{1,9}"))
            errors.add("RECEIVER.RZIPCODE: only 0-9A-Z allowed");
    }

    // ─── PARCEL ───────────────────────────────────────────────────────
    private void validateParcel(Parcel p, Shipment s, List<String> errors) {
        if (blank(p.getParcelNumber()))
            errors.add("PARCEL.PARCELNUMBER is mandatory for parcel "
                       + p.getId());

        if (p.getServiceCode() == null)
            errors.add("PARCEL.SERVICECODE is mandatory for parcel "
                       + p.getId());
    }

    // ─── CUSTOMS (INTER) ──────────────────────────────────────────────
    private void validateCustoms(Customs c, List<String> errors) {
        String status = c.getClearanceStatus();

        // When CLEARANCECLEARED is N, E, T or I — many fields become mandatory
        if (status != null && status.matches("[NETI]")) {
            if (blank(c.getParcelType()))
                errors.add("INTER.PARCELTYPE mandatory when clearance=N/E/T/I");

            if (c.getCustomsAmount() == null)
                errors.add("INTER.CAMOUNT mandatory when clearance=N/E/T/I");

            if (blank(c.getCurrency()))
                errors.add("INTER.CURRENCY mandatory when clearance=N/E/T/I");

            if (blank(c.getIncoterms()))
                errors.add("INTER.CTERMS mandatory when clearance=N/E/T/I");

            if (blank(c.getPrealertStatus()))
                errors.add("INTER.PREALERTSTATUS mandatory when clearance=N/E/T/I");

            if (blank(c.getCName1()))
                errors.add("INTER.CNAME1 mandatory when clearance=N/E/T/I");

            if (blank(c.getCStreet()))
                errors.add("INTER.CSTREET mandatory when clearance=N/E/T/I");

            if (blank(c.getCCountryCode()))
                errors.add("INTER.CCOUNTRYCODE mandatory when clearance=N/E/T/I");
        }

        // Validate parcel type
        if (!blank(c.getParcelType()) &&
            !c.getParcelType().matches("[DP]"))
            errors.add("INTER.PARCELTYPE must be D or P");

        // Validate incoterms
        if (!blank(c.getIncoterms()) &&
            !c.getIncoterms().matches("01|02|03|05|06|07"))
            errors.add("INTER.CTERMS must be 01-07");

        // Reason for export
        if (!blank(c.getReasonForExport()) &&
            !c.getReasonForExport().matches("01|02|03"))
            errors.add("INTER.REASONFOREXPORT must be 01, 02, or 03");
    }

    // ─── WEIGHT RULES ─────────────────────────────────────────────────
    private void validateWeightRules(Shipment s, List<String> errors) {
        if (s.getMpsweight() == null || s.getParcels() == null) return;

        // Sum of DECLAREDWEIGHT (grams) must equal MPSWEIGHT (grams in DB)
        // Note: MPSWEIGHT is converted to Decagram only in the file output (builder)
        long sumDeclared = s.getParcels().stream()
            .filter(p -> p.getDeclaredWeight() != null)
            .mapToLong(Parcel::getDeclaredWeight)
            .sum();

        if (sumDeclared > 0 && sumDeclared != s.getMpsweight()) {
            errors.add(String.format(
                "Weight rule: Sum of parcel declared weights (%d g) " +
                "must equal MPSWEIGHT (%d g)",
                sumDeclared, s.getMpsweight()));
        }

        // CNETWEIGHT must be less than CGROSSWEIGHT (per invoice line)
        if (s.getInvoiceLines() != null) {
            s.getInvoiceLines().forEach(line -> {
                if (line.getNetWeight() != null &&
                    line.getGrossWeight() != null &&
                    line.getNetWeight() >= line.getGrossWeight()) {
                    errors.add("INTERINVOICELINE: CNETWEIGHT must be < " +
                               "CGROSSWEIGHT for line " + line.getId());
                }
            });
        }
    }

    private boolean blank(String s) {
        return s == null || s.isBlank();
    }
}
