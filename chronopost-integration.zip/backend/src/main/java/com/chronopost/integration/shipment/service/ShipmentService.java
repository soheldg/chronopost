package com.chronopost.integration.shipment.service;

import com.chronopost.integration.common.model.*;
import com.chronopost.integration.common.repository.*;
import com.chronopost.integration.shipment.dto.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ShipmentService {

    private final ShipmentRepository  shipmentRepo;
    private final ParcelRepository    parcelRepo;
    private final SenderRepository    senderRepo;
    private final ReceiverRepository  receiverRepo;

    private final AtomicInteger mpsCounter = new AtomicInteger(1);

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HHmmss");

    // =====================================================================
    // CREATE
    // =====================================================================
    @Transactional
    public ShipmentCreateResponse create(ShipmentCreateRequest req) {
        log.info("Creating shipment for account: {}", req.getSender().getAccountNo());

        String mpsId = generateMpsId(req.getSender().getAccountNo());
        LocalDateTime now = LocalDateTime.now();

        // ── 1. Shipment ───────────────────────────────────────────────
        long totalWeight = req.getParcels().stream()
            .mapToLong(p -> p.getDeclaredWeight() != null ? p.getDeclaredWeight() : 0)
            .sum();

        Shipment shipment = Shipment.builder()
            .mpsId(mpsId)
            .status(Shipment.ShipmentStatus.CREATED)
            .linehaul(req.getLinehaul())
            .serviceCode(req.getServiceCode())
            .mpscount(req.getParcels().size())
            .mpsweight(totalWeight)
            .cdate(LocalDate.now())
            .ctime(now.format(TIME_FMT))
            .sptdate(LocalDate.now())
            .build();

        shipment = shipmentRepo.save(shipment);

        // ── 2. Sender ─────────────────────────────────────────────────
        ShipmentCreateRequest.SenderRequest sr = req.getSender();
        Sender sender = Sender.builder()
            .shipment(shipment)
            .accountNo(sr.getAccountNo())
            .subAccountNo(sr.getSubAccountNo())
            .companyName(sr.getCompanyName())
            .name1(sr.getName1())
            .name2(sr.getName2())
            .street(sr.getStreet())
            .propNum(sr.getPropNum())
            .add2(sr.getAdd2())
            .zipcode(sr.getZipcode())
            .town(sr.getTown())
            .countryCode(sr.getCountryCode())
            .state(sr.getState())
            .phone(sr.getPhone())
            .email(sr.getEmail())
            .businessType(sr.getBusinessType())
            .vatNo(sr.getVatNo())
            .eori(sr.getEori())
            .sellingWebsite(sr.getSellingWebsite())
            .accountOwner(sr.getAccountOwner())
            .build();
        shipment.setSender(sender);

        // ── 3. Receiver ───────────────────────────────────────────────
        ShipmentCreateRequest.ReceiverRequest rr = req.getReceiver();
        Receiver receiver = Receiver.builder()
            .shipment(shipment)
            .name1(rr.getName1())
            .name2(rr.getName2())
            .companyName(rr.getCompanyName())
            .street(rr.getStreet())
            .propNum(rr.getPropNum())
            .add2(rr.getAdd2())
            .zipcode(rr.getZipcode())
            .town(rr.getTown())
            .countryCode(rr.getCountryCode())
            .state(rr.getState())
            .phone1(rr.getPhone1())   // ← phone1, not phone
            .phone2(rr.getPhone2())
            .email(rr.getEmail())
            .businessType(rr.getBusinessType())
            .pudoId(rr.getPudoId())
            .vatNo(rr.getVatNo())
            .eori(rr.getEori())
            .doorCode(rr.getDoorCode())
            .build();
        shipment.setReceiver(receiver);

        // ── 4. Parcels ────────────────────────────────────────────────
        // FIX: Use ParcelDto (not ParcelInfo) — matches ShipmentCreateResponse.parcels field
        List<Parcel> parcels = new ArrayList<>();
        List<ShipmentCreateResponse.ParcelDto> parcelDtos = new ArrayList<>();

        for (int i = 0; i < req.getParcels().size(); i++) {
            ShipmentCreateRequest.ParcelRequest pr = req.getParcels().get(i);
            String tempParcelNo = "PENDING-" + (i + 1);

            Parcel parcel = Parcel.builder()
                .shipment(shipment)
                .parcelNumber(tempParcelNo)
                .serviceCode(req.getServiceCode())
                .declaredWeight(pr.getDeclaredWeight())
                .dimension(pr.getDimension())
                .content(pr.getContent())
                .parcelRank(pr.getParcelRank() != null ? pr.getParcelRank() : i + 1)
                .insAmount(pr.getInsAmount())
                .insCurrency(pr.getInsCurrency())
                .labelStatus(Parcel.LabelStatus.PENDING)
                .build();

            parcels.add(parcel);

            // Build ParcelDto for response
            parcelDtos.add(ShipmentCreateResponse.ParcelDto.builder()
                .parcelNumber(tempParcelNo)
                .parcelRank(i + 1)
                .declaredWeight(pr.getDeclaredWeight())
                .dimension(pr.getDimension())
                .content(pr.getContent())
                .labelStatus("PENDING")
                .build());
        }
        shipment.setParcels(parcels);

        // ── 5. Customs ────────────────────────────────────────────────
        if (req.getCustoms() != null) {
            ShipmentCreateRequest.CustomsRequest cr = req.getCustoms();
            // FIX: auto-populate clearance address from receiver if not provided
            // INTER.CNAME1/CSTREET/CCOUNTRYCODE are mandatory when clearanceStatus=N/E/T/I
            String clearName    = blank(cr.getCName1())     ? nvlReceiver(rr, "name")    : cr.getCName1();
            String clearStreet  = blank(cr.getCStreet())    ? rr.getStreet()             : cr.getCStreet();
            String clearCountry = blank(cr.getCCountryCode())? rr.getCountryCode()       : cr.getCCountryCode();
            String clearZip     = blank(cr.getCZipcode())   ? rr.getZipcode()            : cr.getCZipcode();
            String clearTown    = blank(cr.getCTown())      ? rr.getTown()               : cr.getCTown();
            String clearPhone   = blank(cr.getCPhone())     ? rr.getPhone1()             : cr.getCPhone();
            String clearEmail   = blank(cr.getCEmail())     ? rr.getEmail()              : cr.getCEmail();

            Customs customs = Customs.builder()
                .shipment(shipment)
                .parcelType(cr.getParcelType())
                .customsAmount(cr.getCustomsAmount())
                .currency(cr.getCurrency())
                .incoterms(cr.getIncoterms())
                .clearanceStatus(cr.getClearanceStatus())
                .reasonForExport(cr.getReasonForExport() != null ? cr.getReasonForExport() : "01")
                // FIX: prealertStatus default S04 (sent on departure day)
                .prealertStatus("S04")  // S04 = sent on departure day (Doc 1 default)
                // FIX: clearance address auto-filled from receiver
                .cName1(clearName)
                .cStreet(clearStreet)
                .cCountryCode(clearCountry)
                .cZipcode(clearZip)
                .cTown(clearTown)
                .cPhone(clearPhone)
                .cEmail(clearEmail)
                .cVatNo(cr.getCVatNo())
                .siName1(cr.getSiName1())
                .siStreet(cr.getSiStreet())
                .siZipcode(cr.getSiZipcode())
                .siTown(cr.getSiTown())
                .siCountryCode(cr.getSiCountryCode())
                .numberOfArticle(req.getInvoiceLines() != null ? req.getInvoiceLines().size() : 0)
                .build();
            shipment.setCustoms(customs);
        }

        // ── 6. Invoice Lines ──────────────────────────────────────────
        if (req.getInvoiceLines() != null) {
            List<InvoiceLine> lines = new ArrayList<>();
            for (int i = 0; i < req.getInvoiceLines().size(); i++) {
                ShipmentCreateRequest.InvoiceLineRequest lr = req.getInvoiceLines().get(i);
                lines.add(InvoiceLine.builder()
                    .shipment(shipment)
                    .position(i + 1)
                    .quantity(lr.getQuantity())
                    .content(lr.getContent())
                    .amount(lr.getAmount())
                    .countryOrigin(lr.getCountryOrigin())
                    .netWeight(lr.getNetWeight())
                    .grossWeight(lr.getGrossWeight())
                    .hsCodeRecv(lr.getHsCodeRecv())
                    .hsCodeSend(lr.getHsCodeSend())
                    .prodCode(lr.getProdCode())
                    .prodType(lr.getProdType())
                    .build());
            }
            shipment.setInvoiceLines(lines);
        }

        // ── 7. Final save ─────────────────────────────────────────────
        shipment = shipmentRepo.save(shipment);

        // Update parcel IDs in DTO after save (IDs now generated by DB)
        List<Parcel> savedParcels = shipment.getParcels();
        for (int i = 0; i < savedParcels.size() && i < parcelDtos.size(); i++) {
            parcelDtos.get(i).setId(savedParcels.get(i).getId());
        }

        log.info("Shipment created: id={}, mpsId={}, parcels={}",
                 shipment.getId(), mpsId, parcels.size());

        // FIX: use .shipmentId() — that is the field name in ShipmentCreateResponse
        //      use .parcels(parcelDtos) — List<ParcelDto> matches the response field
        return ShipmentCreateResponse.builder()
            .shipmentId(shipment.getId())   // ← shipmentId (not .id())
            .mpsId(mpsId)
            .status("CREATED")
            .parcelCount(parcels.size())
            .parcels(parcelDtos)            // ← List<ParcelDto> (not ParcelInfo)
            .createdAt(now.toString())
            .message("Shipment created successfully. Next: Generate Label.")
            .build();
    }

    // =====================================================================
    // LIST
    // =====================================================================
    public List<ShipmentListDto> listAll() {
        return shipmentRepo.findAll().stream()
            .map(this::toListDto)
            .collect(Collectors.toList());
    }

    public List<ShipmentListDto> listByStatus(String status) {
        Shipment.ShipmentStatus st =
            Shipment.ShipmentStatus.valueOf(status.toUpperCase());
        return shipmentRepo.findByStatus(st).stream()
            .map(this::toListDto)
            .collect(Collectors.toList());
    }

    // =====================================================================
    // GET DETAIL
    // =====================================================================
    public ShipmentCreateResponse getDetail(Long shipmentId) {
        Shipment s = shipmentRepo.findByIdWithAllDetails(shipmentId)
            .orElseThrow(() -> new IllegalArgumentException("Shipment not found: " + shipmentId));

        // ── Sender DTO ────────────────────────────────────────────────
        ShipmentCreateResponse.SenderDto senderDto = null;
        if (s.getSender() != null) {
            var sd = s.getSender();
            senderDto = ShipmentCreateResponse.SenderDto.builder()
                .id(sd.getId()).accountNo(sd.getAccountNo())
                .companyName(sd.getCompanyName()).name1(sd.getName1())
                .street(sd.getStreet()).add2(sd.getAdd2())
                .zipcode(sd.getZipcode()).town(sd.getTown())
                .countryCode(sd.getCountryCode()).phone(sd.getPhone())
                .email(sd.getEmail()).businessType(sd.getBusinessType())
                .build();
        }

        // ── Receiver DTO ──────────────────────────────────────────────
        ShipmentCreateResponse.ReceiverDto receiverDto = null;
        if (s.getReceiver() != null) {
            var rd = s.getReceiver();
            receiverDto = ShipmentCreateResponse.ReceiverDto.builder()
                .id(rd.getId()).name1(rd.getName1())
                .companyName(rd.getCompanyName())
                .street(rd.getStreet()).add2(rd.getAdd2())
                .zipcode(rd.getZipcode()).town(rd.getTown())
                .countryCode(rd.getCountryCode())
                .phone1(rd.getPhone1())   // ← phone1 for receiver
                .email(rd.getEmail()).businessType(rd.getBusinessType())
                .doorCode(rd.getDoorCode())
                .build();
        }

        // ── Parcel DTOs ───────────────────────────────────────────────
        // FIX: use ParcelDto (not ParcelInfo) — same type as create()
        List<ShipmentCreateResponse.ParcelDto> parcelDtos =
            s.getParcels() == null ? List.of() :
            s.getParcels().stream().map(p ->
                ShipmentCreateResponse.ParcelDto.builder()
                    .id(p.getId())
                    .parcelNumber(p.getParcelNumber())
                    .parcelRank(p.getParcelRank())
                    .declaredWeight(p.getDeclaredWeight())
                    .dimension(p.getDimension())
                    .content(p.getContent())
                    .labelStatus(p.getLabelStatus() != null ? p.getLabelStatus().name() : "PENDING")
                    .routingBarcode(p.getRoutingBarcode())
                    .build())
            .collect(Collectors.toList());

        // ── Customs DTO ───────────────────────────────────────────────
        ShipmentCreateResponse.CustomsDto customsDto = null;
        if (s.getCustoms() != null) {
            var cu = s.getCustoms();
            customsDto = ShipmentCreateResponse.CustomsDto.builder()
                .parcelType(cu.getParcelType())
                .customsAmount(cu.getCustomsAmount() != null ? cu.getCustomsAmount().toPlainString() : null)
                .currency(cu.getCurrency())
                .incoterms(cu.getIncoterms())
                .clearanceStatus(cu.getClearanceStatus())
                .reasonForExport(cu.getReasonForExport())
                .build();
        }

        // ── Invoice Line DTOs ─────────────────────────────────────────
        List<ShipmentCreateResponse.InvoiceLineDto> lineDtos =
            s.getInvoiceLines() == null ? List.of() :
            s.getInvoiceLines().stream().map(ln ->
                ShipmentCreateResponse.InvoiceLineDto.builder()
                    .id(ln.getId())
                    .quantity(ln.getQuantity() != null ? ln.getQuantity().toString() : null)
                    .content(ln.getContent())
                    .amount(ln.getAmount() != null ? ln.getAmount().toPlainString() : null)
                    .countryOrigin(ln.getCountryOrigin())
                    .hsCodeRecv(ln.getHsCodeRecv())
                    .hsCodeSend(ln.getHsCodeSend())
                    .build())
            .collect(Collectors.toList());

        // FIX: use .shipmentId() — not .id()
        return ShipmentCreateResponse.builder()
            .shipmentId(s.getId())          // ← shipmentId (matches DTO field)
            .mpsId(s.getMpsId())
            .status(s.getStatus() != null ? s.getStatus().name() : "CREATED")
            .linehaul(s.getLinehaul())
            .mpsweight(s.getMpsweight())
            .parcelCount(s.getMpscount() != null ? s.getMpscount() : 0)
            .createdAt(s.getCreatedAt() != null ? s.getCreatedAt().toString() : "")
            .sender(senderDto)
            .receiver(receiverDto)
            .parcels(parcelDtos)            // ← List<ParcelDto>
            .customs(customsDto)
            .invoiceLines(lineDtos)
            .build();
    }

    // =====================================================================
    // UPDATE SENDER
    // =====================================================================
    @Transactional
    public void updateSender(Long shipmentId, Map<String, String> fields) {
        Shipment s = shipmentRepo.findByIdWithDetails(shipmentId)
            .orElseThrow(() -> new IllegalArgumentException("Shipment not found: " + shipmentId));
        Sender sender = s.getSender();
        if (sender == null) throw new IllegalStateException("No sender for shipment: " + shipmentId);

        if (fields.containsKey("companyName")) sender.setCompanyName(fields.get("companyName"));
        if (fields.containsKey("name1"))       sender.setName1(fields.get("name1"));
        if (fields.containsKey("street"))      sender.setStreet(fields.get("street"));
        if (fields.containsKey("add2"))        sender.setAdd2(fields.get("add2"));
        if (fields.containsKey("zipcode"))     sender.setZipcode(fields.get("zipcode").toUpperCase());
        if (fields.containsKey("town"))        sender.setTown(fields.get("town"));
        if (fields.containsKey("phone"))       sender.setPhone(fields.get("phone"));
        if (fields.containsKey("email"))       sender.setEmail(fields.get("email"));

        senderRepo.save(sender);
        log.info("Sender updated for shipment {}", shipmentId);
    }

    // =====================================================================
    // UPDATE RECEIVER
    // =====================================================================
    @Transactional
    public void updateReceiver(Long shipmentId, Map<String, String> fields) {
        Shipment s = shipmentRepo.findByIdWithDetails(shipmentId)
            .orElseThrow(() -> new IllegalArgumentException("Shipment not found: " + shipmentId));
        Receiver receiver = s.getReceiver();
        if (receiver == null) throw new IllegalStateException("No receiver for shipment: " + shipmentId);

        if (fields.containsKey("name1"))      receiver.setName1(fields.get("name1"));
        if (fields.containsKey("companyName"))receiver.setCompanyName(fields.get("companyName"));
        if (fields.containsKey("street"))     receiver.setStreet(fields.get("street"));
        if (fields.containsKey("add2"))       receiver.setAdd2(fields.get("add2"));
        if (fields.containsKey("zipcode"))    receiver.setZipcode(fields.get("zipcode").toUpperCase());
        if (fields.containsKey("town"))       receiver.setTown(fields.get("town"));
        if (fields.containsKey("phone1"))     receiver.setPhone1(fields.get("phone1")); // ← phone1
        if (fields.containsKey("email"))      receiver.setEmail(fields.get("email"));
        if (fields.containsKey("doorCode"))   receiver.setDoorCode(fields.get("doorCode"));

        receiverRepo.save(receiver);
        log.info("Receiver updated for shipment {}", shipmentId);
    }

    // =====================================================================
    // PRIVATE: toListDto
    // =====================================================================
    private ShipmentListDto toListDto(Shipment s) {
        String senderName = "", senderCountry = "";
        if (s.getSender() != null) {
            senderName = s.getSender().getName1() != null
                ? s.getSender().getName1() : s.getSender().getCompanyName();
            senderCountry = s.getSender().getCountryCode();
        }
        String receiverName = "", receiverCountry = "", receiverZip = "";
        if (s.getReceiver() != null) {
            receiverName = s.getReceiver().getName1() != null
                ? s.getReceiver().getName1() : s.getReceiver().getCompanyName();
            receiverCountry = s.getReceiver().getCountryCode();
            receiverZip     = s.getReceiver().getZipcode();
        }

        Shipment.ShipmentStatus st = s.getStatus();
        int ord = st != null ? st.ordinal() : 0;

        return ShipmentListDto.builder()
            .id(s.getId())
            .mpsId(s.getMpsId())
            .status(st != null ? st.name() : "CREATED")
            .senderName(senderName)
            .senderCountry(senderCountry)
            .receiverName(receiverName)
            .receiverCountry(receiverCountry)
            .receiverZipcode(receiverZip)
            .parcelCount(s.getMpscount() != null ? s.getMpscount() : 0)
            .totalWeightGrams(s.getMpsweight())
            .linehaul(s.getLinehaul())
            .createdAt(s.getCreatedAt() != null ? s.getCreatedAt().toString() : "")
            .labelReady(ord >= Shipment.ShipmentStatus.LABEL_READY.ordinal())
            .prealertSent(ord >= Shipment.ShipmentStatus.PREALERT_SENT.ordinal())
            .invoiceSent(ord >= Shipment.ShipmentStatus.INVOICE_SENT.ordinal())
            .build();
    }

    // =====================================================================
    // PRIVATE: generateMpsId
    // =====================================================================
    private boolean blank(String s) {
        return s == null || s.isBlank();
    }

    private String nvlReceiver(ShipmentCreateRequest.ReceiverRequest r, String type) {
        if ("name".equals(type)) {
            return r.getName1() != null ? r.getName1() :
                   r.getCompanyName() != null ? r.getCompanyName() : "";
        }
        return "";
    }

    private String generateMpsId(String accountNo) {
        String acc  = (accountNo + "00000000").replaceAll("[^0-9A-Z]", "")
                      .substring(0, Math.min(8, accountNo.length()));
        String date = LocalDate.now().format(DATE_FMT);
        String seq  = String.format("%04d", mpsCounter.getAndIncrement());
        String raw  = acc + date + seq;
        return raw.substring(0, Math.min(14, raw.length()));
    }
}
