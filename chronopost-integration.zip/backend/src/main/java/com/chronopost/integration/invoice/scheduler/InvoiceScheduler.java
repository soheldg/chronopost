package com.chronopost.integration.invoice.scheduler;
import com.chronopost.integration.invoice.service.InvoiceService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
@Component @Slf4j @RequiredArgsConstructor
public class InvoiceScheduler {
    private final InvoiceService invoiceService;
    @Scheduled(cron="0 0/30 * * * *")
    public void fetchInvoices() {
        log.info("Scheduled invoice fetch started");
        try { invoiceService.fetchFromChronopost(); }
        catch(Exception e) { log.error("Invoice fetch failed: {}", e.getMessage(), e); }
    }
}
