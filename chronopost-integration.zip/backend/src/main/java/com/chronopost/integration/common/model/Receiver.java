package com.chronopost.integration.common.model;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name="CHR_RECEIVERS",schema="CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Receiver {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="chr_seq")
    @SequenceGenerator(name="chr_seq",sequenceName="CHR_SEQ",allocationSize=1)
    private Long id;
    @OneToOne(fetch=FetchType.LAZY) @JoinColumn(name="SHIPMENT_ID",nullable=false)
    private Shipment shipment;

    // Core address fields (in DB)
    @Column(name="NAME1",        length=35)  private String name1;
    @Column(name="NAME2",        length=35)  private String name2;
    @Column(name="COMPANY_NAME", length=35)  private String companyName;
    @Column(name="STREET",  nullable=false, length=35) private String street;
    @Column(name="PROP_NUM",     length=8)   private String propNum;
    @Column(name="ADD2",         length=35)  private String add2;
    @Column(name="ZIPCODE", nullable=false, length=9)  private String zipcode;
    @Column(name="TOWN",    nullable=false, length=35) private String town;
    @Column(name="COUNTRY_CODE",nullable=false,length=3) private String countryCode;
    @Column(name="STATE",        length=2)   private String state;
    @Column(name="DOOR_CODE",    length=8)   private String doorCode;
    @Column(name="PHONE1",       length=30)  private String phone1;
    @Column(name="PHONE2",       length=30)  private String phone2;
    @Column(name="EMAIL",        length=100) private String email;
    @Column(name="BUSINESS_TYPE",length=1)   private String businessType;
    @Column(name="PUDO_ID",      length=20)  private String pudoId;

    // @Transient = NOT stored in DB (column missing in older schema)
    // After running alter_add_missing_columns.sql, change to @Column
    @Transient private String vatNo;
    @Transient private String eori;
    @Transient private String gpsLat;
    @Transient private String gpsLong;
}
