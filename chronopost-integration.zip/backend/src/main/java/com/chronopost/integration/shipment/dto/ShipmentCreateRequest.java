package com.chronopost.integration.shipment.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.*;
import java.util.List;

/**
 * Full shipment creation request DTO
 * Contains sender, receiver, parcel, customs and invoice line data
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ShipmentCreateRequest {

    // ─── SHIPMENT LEVEL ───────────────────────────────────────
    @NotBlank(message = "Linehaul is required")
    @Pattern(regexp = "AI|RO|SE",
             message = "Linehaul must be AI (Air), RO (Road) or SE (Sea)")
    private String linehaul;

    @NotNull(message = "Service code is required")
    private Integer serviceCode;     // 327 or 328

    // ─── SENDER ───────────────────────────────────────────────
    @Valid @NotNull(message = "Sender info is required")
    private SenderRequest sender;

    // ─── RECEIVER ─────────────────────────────────────────────
    @Valid @NotNull(message = "Receiver info is required")
    private ReceiverRequest receiver;

    // ─── PARCELS ──────────────────────────────────────────────
    @Valid @NotNull @Size(min=1, message="At least one parcel required")
    private List<ParcelRequest> parcels;

    // ─── CUSTOMS ──────────────────────────────────────────────
    @Valid
    private CustomsRequest customs;

    // ─── INVOICE LINES ────────────────────────────────────────
    @Valid
    private List<InvoiceLineRequest> invoiceLines;

    // ══════════════════════════════════════════════════════════
    // NESTED DTOs
    // ══════════════════════════════════════════════════════════

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class SenderRequest {
        @NotBlank(message = "Account number is required")
        private String accountNo;

        private String subAccountNo;

        private String companyName;    // companyName OR name1 required

        private String name1;

        private String name2;

        @NotBlank(message = "Sender street is required")
        private String street;

        private String propNum;

        private String add2;

        @NotBlank(message = "Sender zipcode is required")
        @Pattern(regexp = "[0-9A-Z]{1,9}",
                 message = "Zipcode: only 0-9 A-Z allowed, max 9 chars")
        private String zipcode;

        @NotBlank(message = "Sender town is required")
        private String town;

        @NotBlank(message = "Sender country code is required")
        @Size(min=2, max=3)
        private String countryCode;

        private String state;

        private String phone;         // phone OR email required

        private String email;

        @NotBlank(message = "Business type is required")
        @Pattern(regexp = "[PB]",
                 message = "Business type must be P (Private) or B (Business)")
        private String businessType;

        private String vatNo;         // vatNo OR eori required if B

        private String eori;

        private String sellingWebsite;// required if B

        private String accountOwner;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ReceiverRequest {
        private String name1;         // name1 OR companyName required

        private String name2;

        private String companyName;

        @NotBlank(message = "Receiver street is required")
        private String street;

        private String propNum;

        private String add2;

        @NotBlank(message = "Receiver zipcode is required")
        @Pattern(regexp = "[0-9A-Z]{1,9}",
                 message = "Zipcode: only 0-9 A-Z allowed, max 9 chars")
        private String zipcode;

        @NotBlank(message = "Receiver town is required")
        private String town;

        @NotBlank(message = "Receiver country code is required")
        @Size(min=2, max=3)
        private String countryCode;

        private String state;

        private String phone1;        // phone1 OR email required

        private String phone2;

        private String email;

        @NotBlank(message = "Business type is required")
        @Pattern(regexp = "[PB]",
                 message = "Business type must be P (Private) or B (Business)")
        private String businessType;

        private String pudoId;

        private String vatNo;

        private String eori;

        private String doorCode;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ParcelRequest {
        @NotNull(message = "Declared weight is required (grams)")
        @Min(value=1, message="Weight must be at least 1 gram")
        private Long declaredWeight;   // in grams

        private String dimension;      // LWH in cm, e.g. "030020015"

        private String content;        // parcel content description

        private Integer parcelRank;    // rank in multi-piece shipment

        private Double insAmount;      // insurance amount

        private String insCurrency;    // insurance currency
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CustomsRequest {
        @Pattern(regexp = "[DP]",
                 message = "Parcel type: D (Document) or P (Non-Document)")
        private String parcelType;

        private Double customsAmount;

        private String currency;

        @Pattern(regexp = "01|02|03|05|06|07",
                 message = "Incoterms: 01=DAP, 02=DDP, 03=DDP+tax, 05=EXW, 06=DAP, 07=DAP enhanced")
        private String incoterms;

        @Pattern(regexp = "[NFETIH]",
                 message = "Clearance: N,F,E,T,I or H")
        private String clearanceStatus;

        @Pattern(regexp = "01|02|03",
                 message = "Reason: 01=Sale, 02=Return, 03=Gift")
        private String reasonForExport = "01";

        // Commercial invoice consignee
        private String cName1;
        private String cStreet;
        private String cCountryCode;
        private String cZipcode;
        private String cTown;
        private String cPhone;
        private String cEmail;
        private String cVatNo;

        // Sender invoice address
        private String siName1;
        private String siStreet;
        private String siZipcode;
        private String siTown;
        private String siCountryCode;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class InvoiceLineRequest {
        @NotNull @Min(1)
        private Integer quantity;

        @NotBlank(message = "Content description is required")
        private String content;

        @NotNull(message = "Line amount is required")
        private Double amount;

        @NotBlank(message = "Country of origin is required")
        @Size(min=2, max=3)
        private String countryOrigin;

        private Long netWeight;        // grams, excl. packaging

        private Long grossWeight;      // grams, incl. packaging

        @NotBlank(message = "HS Code (RCTARIF) is required")
        @Size(max=8)
        private String hsCodeRecv;     // RCTARIF - 8 chars

        @NotBlank(message = "HS Code (SCTARIF) is required")
        @Size(max=10)
        private String hsCodeSend;     // SCTARIF - 10 chars

        private String prodCode;

        private String prodType;

        private Double unitPrice;      // for display only
    }
}
