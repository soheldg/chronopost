package com.chronopost.integration.common.repository;
import com.chronopost.integration.common.model.Sender;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
@Repository
public interface SenderRepository extends JpaRepository<Sender, Long> {
    Optional<Sender> findByShipmentId(Long shipmentId);
}
