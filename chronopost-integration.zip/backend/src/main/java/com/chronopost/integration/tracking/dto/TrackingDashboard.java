package com.chronopost.integration.tracking.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TrackingDashboard {
    private long totalShipments, delivered, inTransit, failed, returned, pending;
}
