package com.chronopost.integration.prealert.sftp;

import com.chronopost.integration.common.config.FtpConfig;
import com.jcraft.jsch.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

/**
 * SFTP Service for Chronopost file exchange
 *
 * FIX: Upgraded from plain FTP (commons-net) to SFTP (JSch)
 *      for production-grade security with key-based auth.
 *
 * FIX: TEST mode support — set testMode=true to route all
 *      operations to /TEST directory instead of /IN and /OUT.
 *
 * Doc 4 §1.1:
 *   Server: ftp.chronopost.fr (SFTP port 22)
 *   Upload (Partner → Chronopost): /IN
 *   Download (Chronopost → Partner): /OUT
 *   Testing: /TEST
 *
 * Doc 4 §1.4 Delete method:
 *   Receiver deletes after download.
 *   We delete from /OUT after successful download.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class SftpService {

    private final FtpConfig ftpConfig;

    // =====================================================================
    // TEST MODE — routes all traffic to /TEST directory
    // Set via: POST /api/invoice/test-mode?enabled=true
    // =====================================================================
    private volatile boolean testMode = false;

    public void setTestMode(boolean enabled) {
        this.testMode = enabled;
        log.info("SFTP test mode: {}", enabled ? "ENABLED (/TEST)" : "DISABLED");
    }

    public boolean isTestMode() {
        return testMode;
    }

    /** Resolve the correct IN directory based on test mode */
    private String inDir() {
        return testMode
            ? ftpConfig.getTestDirectory()
            : ftpConfig.getInDirectory();
    }

    /** Resolve the correct OUT directory based on test mode */
    private String outDir() {
        return testMode
            ? ftpConfig.getTestDirectory()
            : ftpConfig.getOutDirectory();
    }

    // =====================================================================
    // UPLOAD
    // =====================================================================

    /**
     * Upload text file (GEODATA pre-alert) to IN directory
     * Encoding: ISO-8859-1 per Doc 1
     */
    public boolean uploadTextFile(String fileName, String content) {
        Session session = null;
        ChannelSftp channel = null;
        try {
            session = connect();
            channel = openSftpChannel(session);
            channel.cd(inDir());

            byte[] bytes = content.getBytes("ISO-8859-1");
            channel.put(new ByteArrayInputStream(bytes), fileName);

            log.info("SFTP uploaded text: {} ({} bytes) → {}",
                     fileName, bytes.length, inDir());
            return true;

        } catch (Exception e) {
            log.error("SFTP text upload failed for {}: {}", fileName, e.getMessage(), e);
            return false;
        } finally {
            closeChannel(channel);
            closeSession(session);
        }
    }

    /**
     * Upload binary file (Invoice PDF) to IN directory
     * Doc 4 §1.3: INV_EXP_account_parcelId.PDF
     */
    public boolean uploadBinaryFile(String fileName, byte[] fileBytes) {
        Session session = null;
        ChannelSftp channel = null;
        try {
            session = connect();
            channel = openSftpChannel(session);
            channel.cd(inDir());

            channel.put(new ByteArrayInputStream(fileBytes), fileName);

            log.info("SFTP uploaded binary: {} ({} bytes) → {}",
                     fileName, fileBytes.length, inDir());
            return true;

        } catch (Exception e) {
            log.error("SFTP binary upload failed for {}: {}", fileName, e.getMessage(), e);
            return false;
        } finally {
            closeChannel(channel);
            closeSession(session);
        }
    }

    // =====================================================================
    // DOWNLOAD
    // =====================================================================

    /**
     * List files in OUT directory
     */
    public List<String> listOutboundFiles() {
        Session session = null;
        ChannelSftp channel = null;
        List<String> fileNames = new ArrayList<>();
        try {
            session = connect();
            channel = openSftpChannel(session);
            channel.cd(outDir());

            @SuppressWarnings("unchecked")
            Vector<ChannelSftp.LsEntry> entries = channel.ls(".");
            for (ChannelSftp.LsEntry entry : entries) {
                if (!entry.getAttrs().isDir()) {
                    fileNames.add(entry.getFilename());
                }
            }
            log.debug("SFTP listed {} files in {}", fileNames.size(), outDir());

        } catch (Exception e) {
            log.error("SFTP list error: {}", e.getMessage(), e);
        } finally {
            closeChannel(channel);
            closeSession(session);
        }
        return fileNames;
    }

    /**
     * Download text file (tracking feedback) from OUT directory
     */
    public String downloadTextFile(String fileName) {
        Session session = null;
        ChannelSftp channel = null;
        try {
            session = connect();
            channel = openSftpChannel(session);
            channel.cd(outDir());

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            channel.get(fileName, baos);

            String content = baos.toString("ISO-8859-1");
            log.info("SFTP downloaded text: {} ({} bytes)", fileName, baos.size());
            return content;

        } catch (Exception e) {
            log.error("SFTP text download failed for {}: {}", fileName, e.getMessage(), e);
            return null;
        } finally {
            closeChannel(channel);
            closeSession(session);
        }
    }

    /**
     * Download binary file (Invoice PDF) from OUT directory
     * Doc 4 §1.3: INV_DDD_ID15.PDF
     */
    public byte[] downloadBinaryFile(String fileName) {
        Session session = null;
        ChannelSftp channel = null;
        try {
            session = connect();
            channel = openSftpChannel(session);
            channel.cd(outDir());

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            channel.get(fileName, baos);

            log.info("SFTP downloaded binary: {} ({} bytes)", fileName, baos.size());
            return baos.toByteArray();

        } catch (Exception e) {
            log.error("SFTP binary download failed for {}: {}", fileName, e.getMessage(), e);
            return null;
        } finally {
            closeChannel(channel);
            closeSession(session);
        }
    }

    /**
     * Delete file from OUT directory after download
     * Doc 4 §1.4: receiver deletes after reading
     */
    public boolean deleteOutboundFile(String fileName) {
        Session session = null;
        ChannelSftp channel = null;
        try {
            session = connect();
            channel = openSftpChannel(session);
            channel.cd(outDir());
            channel.rm(fileName);
            log.info("SFTP deleted from {}: {}", outDir(), fileName);
            return true;

        } catch (Exception e) {
            log.error("SFTP delete failed for {}: {}", fileName, e.getMessage(), e);
            return false;
        } finally {
            closeChannel(channel);
            closeSession(session);
        }
    }

    /**
     * Test SFTP connection
     */
    public boolean testConnection() {
        Session session = null;
        try {
            session = connect();
            log.info("SFTP connection test OK: {}:{}", ftpConfig.getHost(), ftpConfig.getPort());
            return true;
        } catch (Exception e) {
            log.error("SFTP connection test failed: {}", e.getMessage());
            return false;
        } finally {
            closeSession(session);
        }
    }

    // =====================================================================
    // SFTP CONNECTION HELPERS
    // =====================================================================

    private Session connect() throws JSchException {
        JSch jsch = new JSch();

        // Load private key if configured (preferred over password)
        if (ftpConfig.getPrivateKeyPath() != null
                && !ftpConfig.getPrivateKeyPath().isBlank()) {
            if (ftpConfig.getPrivateKeyPassphrase() != null) {
                jsch.addIdentity(ftpConfig.getPrivateKeyPath(),
                                 ftpConfig.getPrivateKeyPassphrase());
            } else {
                jsch.addIdentity(ftpConfig.getPrivateKeyPath());
            }
            log.debug("SFTP using key auth: {}", ftpConfig.getPrivateKeyPath());
        }

        Session session = jsch.getSession(
            ftpConfig.getUsername(),
            ftpConfig.getHost(),
            ftpConfig.getPort()
        );

        // Password auth fallback
        if (ftpConfig.getPassword() != null) {
            session.setPassword(ftpConfig.getPassword());
        }

        // Strict host key checking — disable in dev, enable in prod
        Properties config = new Properties();
        config.put("StrictHostKeyChecking",
                   ftpConfig.isStrictHostKeyChecking() ? "yes" : "no");
        session.setConfig(config);

        session.setTimeout(ftpConfig.getConnectTimeout());
        session.connect();

        log.debug("SFTP connected to {}:{}", ftpConfig.getHost(), ftpConfig.getPort());
        return session;
    }

    private ChannelSftp openSftpChannel(Session session) throws JSchException {
        Channel channel = session.openChannel("sftp");
        channel.connect();
        return (ChannelSftp) channel;
    }

    private void closeChannel(ChannelSftp channel) {
        if (channel != null && channel.isConnected()) {
            channel.disconnect();
        }
    }

    private void closeSession(Session session) {
        if (session != null && session.isConnected()) {
            session.disconnect();
        }
    }
}
