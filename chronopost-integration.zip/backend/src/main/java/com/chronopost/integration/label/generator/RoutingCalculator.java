package com.chronopost.integration.label.generator;

import com.chronopost.integration.common.util.ChecksumUtil;
import com.chronopost.integration.label.generator.ZipCodeNormalizer;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Calculates routing information for Chronopost label
 *
 * Uses product file and routing file data to determine:
 * - Routing barcode (28 chars + 1 checksum)
 * - Routing display info (Origine Sort, Delivery Sort, etc.)
 * - Geopost routing information (SSS-CC-PPPPP)
 *
 * As per Doc 3, sections 2.6.4.3 and 2.6.4.4
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class RoutingCalculator {

    private final ChecksumUtil       checksumUtil;
    private final ZipCodeNormalizer   zipNormalizer;

    /**
     * Build the Geopost Routing Barcode
     *
     * Structure (28 chars for barcode):
     *   % = prefix (in barcode only, not printed)
     *   B = 7-char delivery zipcode (left-padded with 0)
     *   C = 14-char Geopost tracking ID (without checksum)
     *   D = 3-char service code
     *   E = 3-char numerical country code
     *   F = 1-char checksum (printed below barcode, NOT in barcode content)
     *
     * Example barcoded: %009120099934567992481226250
     * Example printed:  0091 2009 9934 5679 9248 1226 250W
     *
     * @param zipcode       delivery zipcode (will be padded to 7 chars)
     * @param trackingId14  14-char tracking ID WITHOUT checksum
     * @param serviceCode   3-digit service code (e.g., 327 or 328)
     * @param countryCodeNum 3-digit numerical country code (e.g., 250 for France)
     * @return RoutingBarcodeResult with all components
     */
    /**
     * FIX 1: countryCodeNum changed from int → String
     *         RoutingService.getNumCountryCode() returns String e.g. "056"
     * FIX 2: zipcode now arrives already normalized from ZipCodeNormalizer
     *         (7 chars, padded). No need to re-parse/re-pad.
     */
    public RoutingBarcodeResult buildRoutingBarcode(
            String zipcode,          // already normalized 7-char zip from ZipCodeNormalizer
            String trackingId14,
            int    serviceCode,
            String countryCodeNum) { // FIX: String not int ("056" not 56)

        // ZIP already normalized by ZipCodeNormalizer — just ensure 7 chars
        String paddedZip = zipcode != null ? zipcode : "0000000";
        if (paddedZip.length() < 7) {
            paddedZip = "0".repeat(7 - paddedZip.length()) + paddedZip;
        } else if (paddedZip.length() > 7) {
            paddedZip = paddedZip.substring(0, 7);
        }

        String svcCode  = String.format("%03d", serviceCode);
        // FIX: countryCodeNum is already "056" — pad to 3 chars if needed
        String ctryCode = countryCodeNum != null
            ? String.format("%3s", countryCodeNum).replace(' ', '0')
            : "250"; // France fallback

        // 27 chars: zip(7) + trackId14(14) + svc(3) + ctry(3)
        String routing27 = paddedZip + trackingId14 + svcCode + ctryCode;

        String checksum = checksumUtil.calculateRoutingChecksum(routing27);

        // For barcode encoding: % + 27 chars
        String forBarcode = "%" + routing27;

        // For plain text printing below barcode: 27 chars + checksum
        String forPrinting = routing27 + checksum;

        // Formatted for label: groups of 4
        String formatted = formatRoutingForLabel(forPrinting);

        log.debug("Routing barcode built: {} (checksum: {})",
                  formatted, checksum);

        return RoutingBarcodeResult.builder()
            .forBarcode(forBarcode)
            .forPrinting(forPrinting)
            .formattedDisplay(formatted)
            .checksum(checksum)
            .paddedZipcode(paddedZip)
            .serviceCode(svcCode)
            .countryCodeNum(ctryCode)
            .build();
    }

    /**
     * Build Geopost routing display information
     * Format: SSS-CC-PPPPP
     *   SSS = service code (3 digits)
     *   CC  = ISO 3166 country code (2 letters)
     *   PPPPP = delivery zipcode
     *
     * Example: 327-BE-1000
     * As per Doc 3, section 2.6.4.4
     */
    public String buildRoutingInfo(int serviceCode,
                                    String countryCode2,
                                    String zipcode) {
        return String.format("%d-%s-%s",
            serviceCode, countryCode2.toUpperCase(), zipcode);
    }

    /**
     * Build routing display for label
     * From routing file columns:
     *   - Origine Sort (column 5)       → font 24 Bold, left aligned
     *   - CC + agency + lot (col2+10+6) → font 30 Bold, centered
     *   - Distribution Sort (col 7)      → font 24 Bold, right justified
     *
     * Example: A2 | BE-0611-C-52 | 01P50
     */
    public RoutingDisplayInfo buildRoutingDisplay(
            String origineSort,
            String countryCode2,
            String agencyCode,
            String lotAcheminement,
            String distribSort) {

        // FIX: Center display = CC-AgencyCode only (e.g. "BE-0467")
        // lotAcheminement goes with distribSort (e.g. "MAC" + "01P50" = "MAC01P50")
        String centerText = String.format("%s-%s",
            countryCode2.toUpperCase(), agencyCode);

        // DistribSort on label = lot + sort (e.g. "MAC01P50")
        String fullDistrib = (lotAcheminement != null ? lotAcheminement : "")
                           + (distribSort != null ? distribSort : "");

        return RoutingDisplayInfo.builder()
            .origineSort(origineSort)
            .centerDisplay(centerText)
            .distribSort(fullDistrib)
            .build();
    }

    /**
     * Format routing barcode for label printing
     * Groups of 4 characters
     * Example: "0091200999345679924812262500"
     *        → "0091 2009 9934 5679 9248 1226 250W"
     */
    public String formatRoutingForLabel(String routing28) {
        if (routing28 == null || routing28.length() < 28) {
            return routing28;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < routing28.length(); i++) {
            if (i > 0 && i % 4 == 0) sb.append(' ');
            sb.append(routing28.charAt(i));
        }
        return sb.toString();
    }

    // ===== Result DTOs =====

    @Data @Builder
    public static class RoutingBarcodeResult {
        private String forBarcode;       // % + 27 chars (encode in barcode)
        private String forPrinting;      // 27 + checksum (plain text)
        private String formattedDisplay; // grouped by 4 for label
        private String checksum;         // 1 char
        private String paddedZipcode;    // 7 chars
        private String serviceCode;      // 3 chars
        private String countryCodeNum;   // 3 chars
    }

    @Data @Builder
    public static class RoutingDisplayInfo {
        private String origineSort;    // e.g., "A2"  - left, font 24 Bold
        private String centerDisplay;  // e.g., "BE-0611-C-52" - center, font 30 Bold
        private String distribSort;    // e.g., "01P50" - right, font 24 Bold
    }
}
