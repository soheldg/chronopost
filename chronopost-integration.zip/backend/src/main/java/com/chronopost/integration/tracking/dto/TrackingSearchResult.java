package com.chronopost.integration.tracking.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TrackingSearchResult {
    private String parcelNumber, geopostTrackId, latestStatus;
    private String latestEventCode, latestEventDate;
    private int totalEvents;
}
