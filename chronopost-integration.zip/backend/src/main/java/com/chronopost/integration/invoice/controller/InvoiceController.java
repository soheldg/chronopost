package com.chronopost.integration.invoice.controller;

import com.chronopost.integration.common.dto.ApiResponse;
import com.chronopost.integration.invoice.dto.*;
import com.chronopost.integration.invoice.service.InvoiceService;
import com.chronopost.integration.invoice.generator.CommercialInvoicePdfGenerator;
import com.chronopost.integration.prealert.sftp.SftpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * Invoice Controller
 *
 * Endpoints:
 *   POST   /api/invoice/upload           Upload PDF → Chronopost SFTP /IN
 *   POST   /api/invoice/fetch            Fetch PDFs from Chronopost SFTP /OUT
 *   GET    /api/invoice/list/{shipmentId} List invoices for shipment
 *   GET    /api/invoice/all              List all invoices
 *   GET    /api/invoice/view/{id}        View invoice PDF inline
 *   GET    /api/invoice/download/{id}    Download invoice PDF
 *   POST   /api/invoice/retry/{id}       Retry failed upload
 *   POST   /api/invoice/test-mode        Toggle SFTP test mode (/TEST dir)  ← FIX
 *   GET    /api/invoice/test-mode        Get current test mode status        ← FIX
 *   GET    /api/invoice/connection-test  Test SFTP connection                ← FIX
 */
@RestController
@RequestMapping("/invoice")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class InvoiceController {

    private final InvoiceService              invoiceService;
    private final CommercialInvoicePdfGenerator invoicePdfGenerator;
    private final SftpService    sftpService;

    // ── Upload ────────────────────────────────────────────────────────
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<InvoiceUploadResponse>> upload(
            @RequestParam("file")       MultipartFile file,
            @RequestParam("shipmentId") Long          shipmentId,
            @RequestParam(value = "type", defaultValue = "EXP") String invoiceType) {
        try {
            InvoiceUploadResponse r = invoiceService.upload(file, shipmentId, invoiceType);
            return r.isSuccess()
                ? ResponseEntity.ok(ApiResponse.ok("Uploaded", r))
                : ResponseEntity.badRequest().body(
                    ApiResponse.<InvoiceUploadResponse>builder()
                        .success(false).message("Validation failed").data(r).build());
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    // ── Fetch from Chronopost ─────────────────────────────────────────
    @PostMapping("/fetch")
    public ResponseEntity<ApiResponse<InvoiceFetchResult>> fetch() {
        try {
            return ResponseEntity.ok(
                ApiResponse.ok("Fetch complete", invoiceService.fetchFromChronopost()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    // ── List ──────────────────────────────────────────────────────────
    @GetMapping("/list/{shipmentId}")
    public ResponseEntity<ApiResponse<List<InvoiceFileDto>>> list(
            @PathVariable Long shipmentId) {
        try {
            return ResponseEntity.ok(
                ApiResponse.ok(invoiceService.listByShipment(shipmentId)));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<InvoiceFileDto>>> all() {
        try {
            return ResponseEntity.ok(ApiResponse.ok(invoiceService.listAll()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    // ── View / Download ───────────────────────────────────────────────
    @GetMapping("/view/{id}")
    public ResponseEntity<byte[]> view(@PathVariable Long id) {
        try {
            byte[] b = invoiceService.getInvoicePdf(id);
            return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header("Content-Disposition",
                        "inline; filename=invoice_" + id + ".pdf")
                .body(b);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> download(@PathVariable Long id) {
        try {
            byte[] b = invoiceService.getInvoicePdf(id);
            return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header("Content-Disposition",
                        "attachment; filename=invoice_" + id + ".pdf")
                .body(b);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    // ── Retry ─────────────────────────────────────────────────────────
    @PostMapping("/retry/{id}")
    public ResponseEntity<ApiResponse<InvoiceUploadResponse>> retry(
            @PathVariable Long id) {
        try {
            return ResponseEntity.ok(
                ApiResponse.ok("Retry result", invoiceService.retry(id)));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    // ── TEST MODE — Doc 4 §1.1 ────────────────────────────────────────
    /**
     * Toggle SFTP test mode.
     * When enabled, all file operations use /TEST directory.
     *
     * POST /api/invoice/test-mode?enabled=true
     * POST /api/invoice/test-mode?enabled=false
     */
    @PostMapping("/test-mode")
    public ResponseEntity<ApiResponse<Map<String, Object>>> setTestMode(
            @RequestParam boolean enabled) {
        sftpService.setTestMode(enabled);
        log.info("SFTP test mode set to: {}", enabled);
        return ResponseEntity.ok(ApiResponse.ok(
            "Test mode " + (enabled ? "ENABLED" : "DISABLED"),
            Map.of(
                "testMode", enabled,
                "directory", enabled ? "/TEST" : "/IN and /OUT",
                "note", enabled
                    ? "All SFTP operations now use /TEST directory"
                    : "SFTP operations restored to /IN and /OUT"
            )));
    }

    /**
     * Get current test mode status
     * GET /api/invoice/test-mode
     */
    @GetMapping("/test-mode")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getTestMode() {
        boolean enabled = sftpService.isTestMode();
        return ResponseEntity.ok(ApiResponse.ok(
            Map.of(
                "testMode",  enabled,
                "directory", enabled ? "/TEST" : "/IN and /OUT"
            )));
    }

    // ── Connection test ────────────────────────────────────────────────
    /**
     * Test SFTP connection to Chronopost server
     * GET /api/invoice/connection-test
     */
    @GetMapping("/connection-test")
    public ResponseEntity<ApiResponse<Map<String, Object>>> connectionTest() {
        boolean ok = sftpService.testConnection();
        return ResponseEntity.ok(ApiResponse.ok(
            ok ? "SFTP connection OK" : "SFTP connection FAILED",
            Map.of(
                "connected", ok,
                "testMode",  sftpService.isTestMode()
            )));
    
    /**
     * Generate commercial invoice PDF from shipment data
     * GET /invoice/generate/{shipmentId}
     * Returns PDF bytes for preview or download
     */
    @GetMapping("/generate/{shipmentId}")
    public ResponseEntity<byte[]> generateInvoicePdf(
            @PathVariable Long shipmentId,
            @RequestParam(defaultValue = "preview") String mode) {
        try {
            byte[] pdf = invoiceService.generateInvoicePdf(shipmentId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            if ("download".equals(mode)) {
                headers.setContentDisposition(
                    ContentDisposition.attachment()
                        .filename("invoice_" + shipmentId + ".pdf")
                        .build());
            } else {
                headers.setContentDisposition(
                    ContentDisposition.inline()
                        .filename("invoice_" + shipmentId + ".pdf")
                        .build());
            }
            return new ResponseEntity<>(pdf, headers, HttpStatus.OK);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            log.error("Invoice generation error for shipment {}: {}", shipmentId, e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

}
