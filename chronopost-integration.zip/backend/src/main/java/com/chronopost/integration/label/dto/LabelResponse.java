package com.chronopost.integration.label.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class LabelResponse {
    private Long parcelDbId;
    private String chronopostParcelId, geopostTrackingId;
    private String routingBarcodeDisplay, labelFilePath, labelStatus, generatedAt;
}
