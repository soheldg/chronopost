package com.chronopost.integration.prealert.controller;
import com.chronopost.integration.common.dto.ApiResponse;
import com.chronopost.integration.prealert.dto.*;
import com.chronopost.integration.prealert.service.PreAlertService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/prealert") @RequiredArgsConstructor @Slf4j
@CrossOrigin(origins="http://localhost:3000")
public class PreAlertController {
    private final PreAlertService preAlertService;
    @PostMapping("/generate/{shipmentId}")
    public ResponseEntity<ApiResponse<PreAlertResponse>> generate(@PathVariable Long shipmentId) {
        try {
            PreAlertResponse r = preAlertService.generate(shipmentId);
            return r.isSuccess() ? ResponseEntity.ok(ApiResponse.ok("Generated",r))
                : ResponseEntity.badRequest().body(ApiResponse.<PreAlertResponse>builder().success(false).message("Validation failed").data(r).build());
        } catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
    @PostMapping("/send/{shipmentId}")
    public ResponseEntity<ApiResponse<PreAlertResponse>> send(@PathVariable Long shipmentId) {
        try {
            PreAlertResponse r = preAlertService.send(shipmentId);
            return r.isSuccess() ? ResponseEntity.ok(ApiResponse.ok("Sent",r))
                : ResponseEntity.badRequest().body(ApiResponse.<PreAlertResponse>builder().success(false).message("Failed").data(r).build());
        } catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
    @GetMapping("/preview/{shipmentId}")
    public ResponseEntity<String> preview(@PathVariable Long shipmentId) {
        try {
            PreAlertResponse r = preAlertService.generate(shipmentId);
            return !r.isSuccess() ? ResponseEntity.badRequest().body("Errors: "+r.getErrors())
                : ResponseEntity.ok().contentType(MediaType.TEXT_PLAIN).body(r.getFileContent());
        } catch(Exception e) { return ResponseEntity.internalServerError().body("Error: "+e.getMessage()); }
    }
    @GetMapping("/status/{shipmentId}")
    public ResponseEntity<ApiResponse<PreAlertStatusResponse>> status(@PathVariable Long shipmentId) {
        try { return ResponseEntity.ok(ApiResponse.ok(preAlertService.getStatus(shipmentId))); }
        catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
}
