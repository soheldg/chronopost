package com.chronopost.integration.routing;

import jakarta.persistence.*;
import lombok.*;

/**
 * CHR_ROUTING entity — loaded from ROUCHR routing file (417K rows)
 *
 * Lookup key: (SERVICE_TYPE, COUNTRY_CODE, ZIP) where ZIP_FROM <= ZIP <= ZIP_TO
 *
 * Provides for each shipment:
 *   origSort      → label Zone 4 LEFT  (font 24 Bold)
 *   agencyCode    → label Zone 4 CENTER
 *   distribSort   → label Zone 4 RIGHT (font 24 Bold)
 *   numCountry    → routing barcode field E (3-digit numerical country code)
 */
@Entity
@Table(name = "CHR_ROUTING", schema = "CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RoutingEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "chr_seq")
    @SequenceGenerator(name = "chr_seq", sequenceName = "CHR_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "SERVICE_TYPE", nullable = false, length = 6)
    private String serviceType;   // DPD, 12H, INT, IPM

    @Column(name = "COUNTRY_CODE", nullable = false, length = 3)
    private String countryCode;   // FR, BE, GB, DE

    @Column(name = "ZIP_FROM", nullable = false, length = 10)
    private String zipFrom;

    @Column(name = "ZIP_TO", nullable = false, length = 10)
    private String zipTo;

    @Column(name = "ORIG_SORT", length = 10)
    private String origSort;      // Col 5 → label left

    @Column(name = "AGENCY_CODE", length = 10)
    private String agencyCode;    // Col 6 → label center

    @Column(name = "DISTRIB_SORT", length = 10)
    private String distribSort;   // Col 7 → label right

    @Column(name = "ROUTING_ZONE", length = 10)
    private String routingZone;   // Col 8

    @Column(name = "NUM_COUNTRY", length = 5)
    private String numCountry;    // Col 9 → routing barcode E field

    @Column(name = "DELIVERY_PT", length = 10)
    private String deliveryPt;    // Col 10
}
