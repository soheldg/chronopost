package com.chronopost.integration.shipment.dto;

import lombok.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ShipmentListDto {

    private Long    id;          // was shipmentId — renamed for frontend
    private String  mpsId;
    private String  status;
    private String  senderName;
    private String  senderCountry;
    private String  receiverName;
    private String  receiverCountry;
    private String  receiverZipcode;
    private int     parcelCount;
    private Long    totalWeightGrams;
    private String  linehaul;
    private String  createdAt;

    // Progress flags
    private boolean labelReady;
    private boolean prealertSent;
    private boolean invoiceSent;
}
