package com.chronopost.integration.routing;

import com.chronopost.integration.label.generator.ZipCodeNormalizer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Routing lookup service
 *
 * Resolves routing info for a shipment from CHR_ROUTING table (417K rows).
 * Used by LabelService to auto-populate:
 *   - origSort, agencyCode, distribSort  → label Zone 4 display
 *   - numCountryCode                     → routing barcode field E
 *
 * Lookup order:
 *   1. Exact service + country + zip range
 *   2. DPD service + country + zip range (generic international)
 *   3. DPD service + country (country-level fallback)
 *   4. Hardcoded defaults (if DB empty)
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class RoutingService {

    private final RoutingRepository repo;
    private final ZipCodeNormalizer  zipNormalizer;

    public RoutingInfo resolve(String serviceType,
                               String countryCode,
                               String rawZip) {

        String normalizedZip = zipNormalizer.normalize(rawZip, countryCode);
        // For range lookup, use the original zip (not the barcode-padded version)
        String lookupZip = cleanZip(rawZip, countryCode);

        log.debug("Routing lookup: svc={} cc={} zip={} → lookupZip={}",
                  serviceType, countryCode, rawZip, lookupZip);

        // 1. Exact service match
        var entry = repo.findByServiceAndCountryAndZip(
            serviceType, countryCode, lookupZip);

        // 2. DPD fallback (generic international)
        if (entry.isEmpty()) {
            log.debug("No exact match, trying DPD fallback");
            entry = repo.findDpdByCountryAndZip(countryCode, lookupZip);
        }

        // 3. Country-level fallback
        if (entry.isEmpty()) {
            log.debug("No zip match, trying country fallback for {}", countryCode);
            entry = repo.findFirstByCountry(countryCode);
        }

        if (entry.isPresent()) {
            RoutingEntry r = entry.get();
            log.debug("Routing found: origSort={} agency={} distrib={} numCC={}",
                      r.getOrigSort(), r.getAgencyCode(),
                      r.getDistribSort(), r.getNumCountry());
            return RoutingInfo.builder()
                .origSort(nvl(r.getOrigSort()))
                .agencyCode(nvl(r.getAgencyCode()))
                .distribSort(nvl(r.getDistribSort()))
                .numCountryCode(nvl(r.getNumCountry(), "250"))
                .normalizedZip(normalizedZip)
                .build();
        }

        // 4. Last resort defaults
        log.warn("No routing found for {}/{}/{} — using defaults", 
                 serviceType, countryCode, rawZip);
        return RoutingInfo.builder()
            .origSort("")
            .agencyCode("")
            .distribSort("")
            .numCountryCode("250")  // France default
            .normalizedZip(normalizedZip)
            .build();
    }

    /**
     * Clean zip for DB range lookup:
     *   - PT: "1849-003" → "1849003"
     *   - NL: "1000 AC"  → "1000AC"
     *   - GB: keep as-is (already handled by ZipCodeNormalizer)
     *   - Others: remove spaces
     */
    private String cleanZip(String zip, String countryCode) {
        if (zip == null) return "";
        String cc = countryCode != null ? countryCode.toUpperCase() : "";
        String z = zip.trim().toUpperCase();
        return switch (cc) {
            case "PT" -> z.replace("-", "").replace(" ", "");
            case "NL" -> z.replace(" ", "");
            default   -> z.replace(" ", "");
        };
    }

    private String nvl(String s) {
        return s != null ? s.trim() : "";
    }

    private String nvl(String s, String def) {
        return (s != null && !s.isBlank()) ? s.trim() : def;
    }

    @lombok.Data
    @lombok.Builder
    public static class RoutingInfo {
        private String origSort;        // label Zone 4 LEFT (OrigSort)
        private String agencyCode;      // label Zone 4 CENTER
        private String distribSort;     // label Zone 4 RIGHT (DistribSort)
        private String numCountryCode;  // routing barcode field E (e.g. "056"=BE, "250"=FR)
        private String normalizedZip;   // barcode-ready 7-char zip
    }
}
