package com.chronopost.integration.common.util;

import org.springframework.stereotype.Component;

/**
 * Checksum calculation for Geopost Tracking ID and Routing Barcode
 * Algorithm: ISO 7064 mod 37/36
 * As per Doc 3 - Label Specification V25.01, section 2.6.4.1.3
 */
@Component
public class ChecksumUtil {

    private static final int MOD = 36;

    /**
     * Character value table (ISO 7064 mod 37/36)
     * 0-9 = 0-9
     * A-Z = 10-35
     */
    private static int valueOf(char c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'A' && c <= 'Z') return c - 'A' + 10;
        throw new IllegalArgumentException(
            "Invalid character for checksum: " + c);
    }

    /**
     * Reverse: get character from value
     */
    private static char charOf(int val) {
        if (val >= 0  && val <= 9)  return (char) ('0' + val);
        if (val >= 10 && val <= 35) return (char) ('A' + val - 10);
        throw new IllegalArgumentException(
            "Invalid value for checksum char: " + val);
    }

    /**
     * Calculate checksum for a string
     * Used for both Geopost Tracking ID (14 chars)
     * and Routing Barcode (27 chars)
     *
     * @param input the string to calculate checksum for
     *              (14 chars for tracking ID, 27 chars for routing barcode)
     * @return checksum character (1 char)
     */
    public char calculate(String input) {
        if (input == null || input.isEmpty()) {
            throw new IllegalArgumentException(
                "Input cannot be null or empty");
        }

        String upper = input.toUpperCase();
        int cs = MOD;

        for (int i = 0; i < upper.length(); i++) {
            int y = valueOf(upper.charAt(i));
            cs = cs + y;
            if (cs > MOD) cs = cs - MOD;
            cs = cs * 2;
            if (cs > MOD) cs = cs - MOD - 1;
        }

        cs = MOD + 1 - cs;
        if (cs == MOD) cs = 0;

        return charOf(cs);
    }

    /**
     * Calculate Geopost Tracking ID checksum
     * Input: 14-character tracking ID
     * Output: 1-character checksum
     *
     * Example: "99993456799248" → 'V'
     */
    public String calculateTrackingChecksum(String trackingId14) {
        if (trackingId14 == null || trackingId14.length() != 14) {
            throw new IllegalArgumentException(
                "Tracking ID must be exactly 14 characters, got: "
                + (trackingId14 == null ? "null"
                   : trackingId14.length()));
        }
        return String.valueOf(calculate(trackingId14));
    }

    /**
     * Calculate Geopost Routing Barcode checksum
     * Input: 27-character routing barcode (without % prefix and checksum)
     * Output: 1-character checksum
     *
     * Example: "009120082123456789248226250" → '0'
     */
    public String calculateRoutingChecksum(String routing27) {
        if (routing27 == null || routing27.length() != 27) {
            throw new IllegalArgumentException(
                "Routing barcode must be exactly 27 characters, got: "
                + (routing27 == null ? "null"
                   : routing27.length()));
        }
        return String.valueOf(calculate(routing27));
    }

    /**
     * Build complete Geopost Tracking ID with checksum
     *
     * Structure: AAAAAAA BBBBBB C D
     * A = 7-char sender ID
     * B = 6-digit counter
     * C = 0 for international
     * D = checksum
     *
     * @param senderId  7-char unique sender ID (provided by Chronopost)
     * @param counter   6-digit counter (incremented per parcel)
     * @return 15-char tracking ID with checksum
     */
    public String buildTrackingId(String senderId, String counter) {
        if (senderId == null || senderId.length() != 7) {
            throw new IllegalArgumentException(
                "Sender ID must be exactly 7 characters");
        }
        if (counter == null || counter.length() != 6) {
            throw new IllegalArgumentException(
                "Counter must be exactly 6 digits");
        }

        // 14 chars: 7 sender + 6 counter + 0 (international)
        String trackingId14 = senderId + counter + "0";
        String checksum = calculateTrackingChecksum(trackingId14);

        return trackingId14 + checksum;  // 15 chars
    }

    /**
     * Build complete Geopost Routing Barcode with checksum
     *
     * Structure: % BBBBBBB CCCCCCCCCCCCCC DDD EEE F
     * B = 7-char delivery zipcode (left-padded with 0)
     * C = 14-char Geopost tracking ID (without checksum)
     * D = 3-char service code
     * E = 3-char numerical country code
     * F = 1-char checksum
     * (% prefix is in barcode only, not in plain text)
     *
     * @param zipcode       delivery zipcode (padded to 7 chars)
     * @param trackingId14  14-char tracking ID without checksum
     * @param serviceCode   3-char service code (e.g., "327")
     * @param countryCode   3-char numerical country code (e.g., "250")
     * @return full routing barcode string for barcode encoding
     *         (includes % prefix) and printed text (without %)
     */
    public RoutingBarcode buildRoutingBarcode(
            String zipcode, String trackingId14,
            String serviceCode, String countryCode) {

        // Pad zipcode to 7 chars
        String paddedZip = String.format("%7s", zipcode)
                                 .replace(' ', '0');

        // 27 chars for checksum calculation
        String routing27 = paddedZip + trackingId14
                         + serviceCode + countryCode;

        String checksum = calculateRoutingChecksum(routing27);

        return RoutingBarcode.builder()
            .forBarcode("%" + routing27)       // includes % prefix
            .forPrinting(routing27 + checksum)  // without %, with checksum
            .checksum(checksum)
            .build();
    }

    @lombok.Data
    @lombok.Builder
    public static class RoutingBarcode {
        private String forBarcode;   // % + 27 chars (for Code128 encoding)
        private String forPrinting;  // 27 chars + checksum (plain text below barcode)
        private String checksum;     // 1 char
    }
}
