package com.chronopost.integration.label.dto;

import jakarta.validation.constraints.*;
import lombok.*;

/**
 * Label generation request
 *
 * Minimized: previously required 10+ fields.
 * Now auto-resolved from DB:
 *   productSuffix + serviceCode → CHR_PRODUCTS (by parcel weight)
 *   origSort / agencyCode / distribSort / numCountryCode → CHR_ROUTING (by country+zip)
 *
 * Caller only needs:
 *   shipmentId, parcelId, customerPrefix, geopostSenderId
 *   customsClearanceCode (HY-DP or HY-NP)
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class LabelRequest {

    @NotNull
    private Long shipmentId;

    @NotNull
    private Long parcelId;

    /** 5-char prefix provided by Chronopost e.g. "HY712" */
    @NotBlank @Size(min=5, max=5)
    private String customerPrefix;

    /** 7-char Geopost sender ID provided by Chronopost e.g. "0407112" */
    @NotBlank @Size(min=7, max=7)
    private String geopostSenderId;

    /** HY-DP (duty paid) or HY-NP (not paid) */
    private String customsClearanceCode;

    /** Optional routing file version override (default: current loaded version) */
    private String routingVersion;
}
