package com.chronopost.integration.prealert.dto;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PreAlertResponse {
    private Long shipmentId;
    private String fileName, fileContent, ftpStatus, sentAt;
    private boolean success;
    private List<String> errors;
}
