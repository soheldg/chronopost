package com.chronopost.integration.label.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class LabelData {
    private String parcelId, geopostTrackingId, masterParcelGeopostId;
    private String routingBarcodeForEncoding, routingBarcodeForPrinting;
    private String origineSort, routingCenterDisplay, distribSort;
    private String geopostRoutingInfo, geopostServiceMention;
    private String sortCode, parcelTag, routingVersion, senderIdentification;
    private String receiverName1, receiverName2, receiverStreet, receiverStreet2;
    private String receiverCity, receiverZipcode, receiverCountryCode, receiverCountryName;
    private String receiverPhone, consigneeCode;
    private String senderAccountNo, senderName, senderAddress, senderCity;
    private String senderCountry, senderPhone, senderReference;
    private String weightKg;
    private Integer parcelRank, totalParcels;
    private String customsValue, customsCurrency, customsClearanceCode;
    private String deliveryServiceName;
}
