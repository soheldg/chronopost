package com.chronopost.integration.tracking.service;

import com.chronopost.integration.common.model.*;
import com.chronopost.integration.common.repository.*;
import com.chronopost.integration.prealert.sftp.SftpService;
import com.chronopost.integration.tracking.dto.*;
import com.chronopost.integration.tracking.parser.TrackingFileParser;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Tracking Service
 *
 * Responsibilities:
 * 1. Poll Chronopost FTP /OUT for tracking files
 * 2. Parse semicolon-delimited tracking lines
 * 3. Match tracking events to parcels in DB
 * 4. Save events to CHR_TRACKING_EVENTS
 * 5. Update parcel/shipment status
 * 6. Provide tracking query APIs
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class TrackingService {

    private final SftpService           sftpService;
    private final TrackingFileParser    parser;
    private final ParcelRepository      parcelRepo;
    private final TrackingEventRepository trackingEventRepo;
    private final ShipmentRepository    shipmentRepo;

    // =====================================================================
    // POLL AND PROCESS tracking files from FTP
    // =====================================================================

    /**
     * Poll FTP /OUT, download tracking files, process them
     * Called by scheduler every 30 minutes
     *
     * @return processing result summary
     */
    @Transactional
    public TrackingPollResult pollAndProcess() {
        log.info("Starting tracking file poll from FTP /OUT");

        List<String> allFiles = sftpService.listOutboundFiles();

        // Filter only tracking files (not invoices)
        List<String> trackingFiles = allFiles.stream()
            .filter(f -> !f.toUpperCase().startsWith("INV_"))
            .filter(f -> f.length() > 0)
            .collect(Collectors.toList());

        log.debug("Found {} tracking files in FTP /OUT",
                  trackingFiles.size());

        int totalEvents = 0;
        int processed   = 0;
        int failed      = 0;
        List<String> processedFiles = new ArrayList<>();

        for (String fileName : trackingFiles) {
            try {
                TrackingFileResult result = processFile(fileName);
                totalEvents += result.getEventsProcessed();
                processed++;
                processedFiles.add(fileName);

                // Delete from FTP after successful processing
                sftpService.deleteOutboundFile(fileName);
                log.info("Processed and deleted tracking file: {}", fileName);

            } catch (Exception e) {
                log.error("Error processing tracking file {}: {}",
                          fileName, e.getMessage(), e);
                failed++;
            }
        }

        log.info("Tracking poll complete: {} files, {} events, {} failed",
                 processed, totalEvents, failed);

        return TrackingPollResult.builder()
            .filesFound(trackingFiles.size())
            .filesProcessed(processed)
            .filesFailed(failed)
            .totalEventsProcessed(totalEvents)
            .processedFileNames(processedFiles)
            .polledAt(LocalDateTime.now().toString())
            .build();
    }

    /**
     * Process a single tracking file
     */
    @Transactional
    public TrackingFileResult processFile(String fileName) {
        log.debug("Processing tracking file: {}", fileName);

        // Download from FTP
        String content = sftpService.downloadTextFile(fileName);
        if (content == null) {
            throw new RuntimeException(
                "Could not download tracking file: " + fileName);
        }

        return processContent(content, fileName);
    }

    /**
     * Process tracking file content (can be called directly for testing)
     */
    @Transactional
    public TrackingFileResult processContent(String content, String fileName) {
        List<TrackingEventDto> events = parser.parseFile(content);

        int saved    = 0;
        int skipped  = 0;
        int notFound = 0;

        for (TrackingEventDto dto : events) {
            try {
                ProcessResult result = processEvent(dto);
                switch (result) {
                    case SAVED    -> saved++;
                    case SKIPPED  -> skipped++;
                    case NOT_FOUND-> notFound++;
                }
            } catch (Exception e) {
                log.warn("Error saving event for tracking {}: {}",
                         dto.getChronopostTrackNo(), e.getMessage());
                skipped++;
            }
        }

        log.info("File {} processed: {} saved, {} skipped, {} not found",
                 fileName, saved, skipped, notFound);

        return TrackingFileResult.builder()
            .fileName(fileName)
            .totalLines(events.size())
            .eventsProcessed(saved)
            .eventsSkipped(skipped)
            .parcelsNotFound(notFound)
            .build();
    }

    /**
     * Process a single tracking event DTO
     */
    private ProcessResult processEvent(TrackingEventDto dto) {
        if (dto.getChronopostTrackNo() == null) return ProcessResult.SKIPPED;

        // Find parcel by Chronopost tracking number
        // The tracking no is the 13-char parcel ID (first 13 chars of field 03)
        String trackNo = dto.getChronopostTrackNo().trim();

        Optional<Parcel> parcelOpt = parcelRepo
            .findByParcelNumber(trackNo);

        // Also try by Geopost tracking ID
        if (parcelOpt.isEmpty()) {
            parcelOpt = parcelRepo.findByGeopostTrackId(
                dto.getDpdGroupTrackNo());
        }

        if (parcelOpt.isEmpty()) {
            log.debug("Parcel not found for tracking no: {}", trackNo);
            return ProcessResult.NOT_FOUND;
        }

        Parcel parcel = parcelOpt.get();

        // Check for duplicate event
        boolean isDuplicate = trackingEventRepo
            .findByParcelIdOrderByEventDateDescEventTimeDesc(parcel.getId())
            .stream()
            .anyMatch(e ->
                Objects.equals(e.getEventCode(), dto.getEventCode()) &&
                Objects.equals(e.getEventDate(), dto.getEventDate()) &&
                Objects.equals(e.getEventTime(), dto.getEventTime())
            );

        if (isDuplicate) {
            log.debug("Duplicate event skipped for parcel: {}", trackNo);
            return ProcessResult.SKIPPED;
        }

        // Save tracking event — all EDIPOD fields
        TrackingEvent event = TrackingEvent.builder()
            .parcel(parcel)
            .contractNo(dto.getContractNo())
            .eventCode(dto.getEventCode())
            .reasonCode(dto.getReasonCode())
            .eventDate(dto.getEventDate())
            .eventTime(dto.getEventTime())
            .location(buildLocation(dto))
            .channel(dto.getCommChannel())
            .channelAddr(dto.getChannelAddress())
            .deliveryInst(dto.getDeliveryInstruction())
            .deskClerk(dto.getDeskClerk())
            .weight(dto.getDeclaredWeight())
            // FIX: previously parsed but not saved
            .pickupPudoCode(dto.getPickupPudoCode())    // F44
            .disposalPlaceCode(dto.getDisposalPlaceCode()) // F42
            .newDeliveryDate(dto.getNewDeliveryDate())  // F43
            .lengthCm(dto.getLengthCm())                // F48
            .widthCm(dto.getWidthCm())                  // F49
            .heightCm(dto.getHeightCm())                // F50
            .podImageUrl(dto.getPodImageUrl())           // F51
            .rawLine(dto.getRawLine())
            .build();

        trackingEventRepo.save(event);

        // Update shipment status based on event
        updateShipmentStatus(parcel, dto.getEventCode());

        return ProcessResult.SAVED;
    }

    // =====================================================================
    // QUERY APIs
    // =====================================================================

    /**
     * Get all tracking events for a parcel by parcel number
     */
    public TrackingResponse getByParcelNumber(String parcelNumber) {
        Parcel parcel = parcelRepo
            .findByParcelNumber(parcelNumber)
            .orElseThrow(() -> new IllegalArgumentException(
                "Parcel not found: " + parcelNumber));

        return buildTrackingResponse(parcel);
    }

    /**
     * Get tracking for all parcels in a shipment
     */
    public List<TrackingResponse> getByShipmentId(Long shipmentId) {
        List<Parcel> parcels = parcelRepo.findByShipmentId(shipmentId);
        return parcels.stream()
            .map(this::buildTrackingResponse)
            .collect(Collectors.toList());
    }

    /**
     * Get tracking dashboard summary
     */
    public TrackingDashboard getDashboard() {
        List<Shipment> allShipments = shipmentRepo.findAll();

        long total     = allShipments.size();
        long delivered = allShipments.stream()
            .filter(s -> s.getStatus() ==
                        Shipment.ShipmentStatus.DELIVERED)
            .count();
        long inTransit = allShipments.stream()
            .filter(s -> s.getStatus() ==
                        Shipment.ShipmentStatus.IN_TRANSIT)
            .count();
        long failed    = allShipments.stream()
            .filter(s -> s.getStatus() ==
                        Shipment.ShipmentStatus.FAILED)
            .count();
        long returned  = allShipments.stream()
            .filter(s -> s.getStatus() ==
                        Shipment.ShipmentStatus.RETURNED)
            .count();
        long pending   = total - delivered - inTransit - failed - returned;

        return TrackingDashboard.builder()
            .totalShipments(total)
            .delivered(delivered)
            .inTransit(inTransit)
            .failed(failed)
            .returned(returned)
            .pending(pending)
            .build();
    }

    /**
     * Search parcels by various criteria
     */
    public List<TrackingSearchResult> search(String query) {
        List<TrackingSearchResult> results = new ArrayList<>();

        // Try by parcel number
        parcelRepo.findByParcelNumber(query).ifPresent(p ->
            results.add(toSearchResult(p)));

        // Try by Geopost tracking ID
        if (results.isEmpty()) {
            parcelRepo.findByGeopostTrackId(query).ifPresent(p ->
                results.add(toSearchResult(p)));
        }

        // Try by MPSID (shipment level)
        if (results.isEmpty()) {
            shipmentRepo.findByMpsId(query).ifPresent(s ->
                s.getParcels().forEach(p ->
                    results.add(toSearchResult(p))));
        }

        return results;
    }

    // =====================================================================
    // PRIVATE HELPERS
    // =====================================================================

    /**
     * Update shipment status based on latest event code
     */
    private void updateShipmentStatus(Parcel parcel, String eventCode) {
        if (eventCode == null) return;
        Shipment shipment = parcel.getShipment();
        if (shipment == null) return;

        // FIX: Use parser's resolveShipmentStatus() which has complete
        //      official event code mapping from Evenements_Chronopost_2023-06-30.xlsx
        //      Previous switch had wrong codes (DL, RT, ND) — real codes are D, R, N
        String statusStr = parser.resolveShipmentStatus(eventCode);
        if (statusStr == null) return;

        Shipment.ShipmentStatus newStatus = switch (statusStr) {
            case "DELIVERED"  -> Shipment.ShipmentStatus.DELIVERED;
            case "IN_TRANSIT" -> Shipment.ShipmentStatus.IN_TRANSIT;
            case "FAILED"     -> Shipment.ShipmentStatus.FAILED;
            case "RETURNED"   -> Shipment.ShipmentStatus.RETURNED;
            default           -> null;
        };

        if (newStatus != null &&
            // Don't downgrade from DELIVERED
            shipment.getStatus() != Shipment.ShipmentStatus.DELIVERED) {
            shipment.setStatus(newStatus);
            shipmentRepo.save(shipment);
            log.debug("Shipment {} status → {}",
                      shipment.getId(), newStatus);
        }
    }

    private String buildLocation(TrackingEventDto dto) {
        if (dto.getConsigneeCity() != null) {
            return dto.getConsigneeCity()
                + (dto.getConsigneeCountry() != null
                   ? ", " + dto.getConsigneeCountry() : "");
        }
        return null;
    }

    private TrackingResponse buildTrackingResponse(Parcel parcel) {
        List<TrackingEvent> events = trackingEventRepo
            .findByParcelIdOrderByEventDateDescEventTimeDesc(parcel.getId());

        String currentStatus = events.isEmpty() ? "NO_EVENTS"
            : parser.getEventDescription(events.get(0).getEventCode());

        List<TrackingEventItem> items = events.stream()
            .map(e -> TrackingEventItem.builder()
                .eventCode(e.getEventCode())
                .eventDescription(
                    parser.getEventDescription(e.getEventCode()))
                .reasonCode(e.getReasonCode())
                .eventDate(e.getEventDate() != null
                           ? e.getEventDate().toString() : null)
                .eventTime(e.getEventTime())
                .location(e.getLocation())
                .deskClerk(e.getDeskClerk())
                .deliveryInstruction(e.getDeliveryInst())
                .instructionDescription(
                    parser.getInstructionDescription(e.getDeliveryInst()))
                .channel(e.getChannel())
                .weight(e.getWeight())
                .build())
            .collect(Collectors.toList());

        return TrackingResponse.builder()
            .parcelNumber(parcel.getParcelNumber())
            .geopostTrackingId(parcel.getGeopostTrackId())
            .currentStatus(currentStatus)
            .isDelivered(events.stream()
                .anyMatch(e -> "DL".equalsIgnoreCase(e.getEventCode())))
            .totalEvents(events.size())
            .events(items)
            .build();
    }

    private TrackingSearchResult toSearchResult(Parcel p) {
        List<TrackingEvent> events = trackingEventRepo
            .findByParcelIdOrderByEventDateDescEventTimeDesc(p.getId());

        String latestStatus = events.isEmpty() ? "NO_EVENTS"
            : parser.getEventDescription(events.get(0).getEventCode());

        return TrackingSearchResult.builder()
            .parcelNumber(p.getParcelNumber())
            .geopostTrackId(p.getGeopostTrackId())
            .latestStatus(latestStatus)
            .latestEventCode(events.isEmpty() ? null
                             : events.get(0).getEventCode())
            .latestEventDate(events.isEmpty() ? null
                : events.get(0).getEventDate() != null
                  ? events.get(0).getEventDate().toString() : null)
            .totalEvents(events.size())
            .build();
    }

    private enum ProcessResult { SAVED, SKIPPED, NOT_FOUND }
}
