package com.chronopost.integration.label.generator;

import com.chronopost.integration.common.util.ChecksumUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Generates Geopost Tracking ID (15 characters)
 *
 * Structure: AAAAAAA BBBBBB C D
 *   A = 7-char unique sender ID in Geopost network
 *       (provided by Chronopost, first 4 chars in BOLD on label)
 *   B = 6-digit counter (same as parcel ID counter)
 *   C = 0 for international shipments
 *   D = 1-char checksum (ISO 7064 mod 37/36)
 *
 * Example: 0407112 000002 0 S  →  04071120000020S
 * As per Doc 3 - Label Specification, section 2.6.4.1
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class TrackingIdGenerator {

    private final ChecksumUtil checksumUtil;

    /**
     * Build complete 15-char Geopost Tracking ID
     *
     * @param geopostSenderId  7-char sender ID (provided by Chronopost)
     *                         e.g., "0407112"
     * @param counter          6-digit counter string
     *                         e.g., "000002"
     * @return 15-char tracking ID with checksum
     *         e.g., "04071120000020S"
     */
    public String generate(String geopostSenderId, String counter) {
        validateSenderId(geopostSenderId);
        validateCounter(counter);

        // Build 14-char base: senderId(7) + counter(6) + "0"(international)
        String trackingId14 = geopostSenderId + counter + "0";

        // Calculate checksum
        String checksum = checksumUtil.calculateTrackingChecksum(trackingId14);

        String result = trackingId14 + checksum;  // 15 chars

        log.debug("Generated Tracking ID: {} (base: {}, checksum: {})",
                  result, trackingId14, checksum);

        return result;
    }

    /**
     * Generate tracking ID from a Chronopost parcel ID
     * Extracts the counter from the parcel ID
     *
     * @param parcelId        13-char Chronopost parcel ID (e.g., "HY712000002JF")
     * @param geopostSenderId 7-char Geopost sender ID (e.g., "0407112")
     * @return 15-char tracking ID
     */
    public String generateFromParcelId(String parcelId, String geopostSenderId) {
        if (parcelId == null || parcelId.length() != 13) {
            throw new IllegalArgumentException(
                "Parcel ID must be 13 characters");
        }

        // Extract 6-digit counter (positions 5-10)
        String counter = parcelId.substring(5, 11);
        return generate(geopostSenderId, counter);
    }

    /**
     * Extract the 14-char base (without checksum) from full tracking ID
     * Used for routing barcode construction
     */
    public String extractBase14(String trackingId15) {
        if (trackingId15 == null || trackingId15.length() != 15) {
            throw new IllegalArgumentException(
                "Tracking ID must be 15 characters");
        }
        return trackingId15.substring(0, 14);
    }

    /**
     * Validate an existing tracking ID's checksum
     */
    public boolean validate(String trackingId15) {
        if (trackingId15 == null || trackingId15.length() != 15) {
            return false;
        }
        String base14   = trackingId15.substring(0, 14);
        char   expected = checksumUtil.calculate(base14);
        char   actual   = trackingId15.charAt(14);
        return expected == actual;
    }

    // ===== Formatted display for label printing =====

    /**
     * Format tracking ID for label display
     * Groups: XXXX XXXX XXXX XXX
     * First group in BOLD (font weight handled in PDF generator)
     *
     * Example: "04071120000020S" → "0407 1120 0000 20S"
     */
    public String formatForLabel(String trackingId15) {
        if (trackingId15 == null || trackingId15.length() != 15) {
            throw new IllegalArgumentException(
                "Tracking ID must be 15 characters");
        }
        return trackingId15.substring(0, 4)  + " "
             + trackingId15.substring(4, 8)  + " "
             + trackingId15.substring(8, 12) + " "
             + trackingId15.substring(12);
    }

    private void validateSenderId(String id) {
        if (id == null || id.length() != 7) {
            throw new IllegalArgumentException(
                "Geopost Sender ID must be exactly 7 characters");
        }
    }

    private void validateCounter(String counter) {
        if (counter == null || counter.length() != 6) {
            throw new IllegalArgumentException(
                "Counter must be exactly 6 digits");
        }
        if (!counter.matches("\\d{6}")) {
            throw new IllegalArgumentException(
                "Counter must be numeric");
        }
    }
}
