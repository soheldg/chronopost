package com.chronopost.integration.common.repository;
import com.chronopost.integration.common.model.TrackingEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface TrackingEventRepository extends JpaRepository<TrackingEvent,Long> {
    List<TrackingEvent> findByParcelIdOrderByEventDateDescEventTimeDesc(Long parcelId);
}
