package com.chronopost.integration.routing;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface RoutingRepository extends JpaRepository<RoutingEntry, Long> {

    /**
     * Find routing entry by service type, country and zip code (range lookup).
     * ZIP_FROM <= zipCode <= ZIP_TO
     * Priority: exact service match first, then DPD fallback
     */
    @Query("""
        SELECT r FROM RoutingEntry r
        WHERE r.serviceType = :serviceType
          AND r.countryCode = :countryCode
          AND r.zipFrom <= :zip
          AND r.zipTo   >= :zip
        ORDER BY r.zipFrom DESC
        LIMIT 1
        """)
    Optional<RoutingEntry> findByServiceAndCountryAndZip(
        @Param("serviceType") String serviceType,
        @Param("countryCode") String countryCode,
        @Param("zip")         String zip);

    /**
     * Fallback: find by DPD service (generic international routing)
     */
    @Query("""
        SELECT r FROM RoutingEntry r
        WHERE r.serviceType = 'DPD'
          AND r.countryCode = :countryCode
          AND r.zipFrom <= :zip
          AND r.zipTo   >= :zip
        ORDER BY r.zipFrom DESC
        LIMIT 1
        """)
    Optional<RoutingEntry> findDpdByCountryAndZip(
        @Param("countryCode") String countryCode,
        @Param("zip")         String zip);

    /**
     * Country-level fallback (wide range 0001-9999)
     */
    @Query("""
        SELECT r FROM RoutingEntry r
        WHERE r.serviceType = 'DPD'
          AND r.countryCode = :countryCode
        ORDER BY r.zipFrom ASC
        LIMIT 1
        """)
    Optional<RoutingEntry> findFirstByCountry(
        @Param("countryCode") String countryCode);
}
