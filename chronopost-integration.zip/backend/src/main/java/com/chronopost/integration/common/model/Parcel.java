package com.chronopost.integration.common.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name="CHR_PARCELS",schema="CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Parcel {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="chr_seq")
    @SequenceGenerator(name="chr_seq",sequenceName="CHR_SEQ",allocationSize=1)
    private Long id;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="SHIPMENT_ID",nullable=false)
    private Shipment shipment;
    @Column(name="PARCEL_NUMBER",nullable=false,length=14) private String parcelNumber;
    @Column(name="PARCEL_CCKEY",length=1) private String parcelCcKey;
    @Column(name="GEOPOST_TRACK_ID",length=15) private String geopostTrackId;
    @Column(name="ROUTING_BARCODE",length=29) private String routingBarcode;
    @Column(name="PARCEL_RANK") private Integer parcelRank;
    @Column(name="SERVICE_CODE",nullable=false) private Integer serviceCode;
    @Column(name="DECLARED_WEIGHT") private Long declaredWeight;
    @Column(name="MEASURED_WEIGHT") private Long measuredWeight;
    @Column(name="DIMENSION",length=9) private String dimension;
    @Column(name="LABEL_PATH",length=255) private String labelPath;
    @Enumerated(EnumType.STRING) @Column(name="LABEL_STATUS",length=20)
    @Builder.Default private LabelStatus labelStatus = LabelStatus.PENDING;
    @Column(name="PCONTENT",length=200) private String content;
    @Column(name="OWNER_BU",length=3) @Builder.Default private String ownerBu="CHR";
    @Column(name="HAZLQ") @Builder.Default private Integer hazlq=0;
    @Column(name="INS_AMOUNT") private Double insAmount;
    @Column(name="INS_CURRENCY",length=3) private String insCurrency;
    @Column(name="ASCODE",length=6) private String ascode;
    @Column(name="HZD_PACK_CODE",length=3) private String hzdPackCode;
    @Column(name="CREATED_AT") @Builder.Default private LocalDateTime createdAt=LocalDateTime.now();
    public enum LabelStatus { PENDING, GENERATED, PRINTED, ERROR }
}
