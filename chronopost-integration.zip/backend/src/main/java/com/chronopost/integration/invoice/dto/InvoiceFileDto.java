package com.chronopost.integration.invoice.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class InvoiceFileDto {
    private Long id, shipmentId;
    private String fileName, direction, ftpStatus, uploadedAt, createdAt;
    private long fileSize;
}
