package com.chronopost.integration.common.repository;
import com.chronopost.integration.common.model.Parcel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public interface ParcelRepository extends JpaRepository<Parcel,Long> {
    Optional<Parcel> findByParcelNumber(String parcelNumber);
    Optional<Parcel> findByGeopostTrackId(String geopostTrackId);
    List<Parcel> findByShipmentId(Long shipmentId);
}
