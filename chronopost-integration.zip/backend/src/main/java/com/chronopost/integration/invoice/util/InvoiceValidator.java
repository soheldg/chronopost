package com.chronopost.integration.invoice.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

/**
 * Validates invoice PDF files before SFTP upload
 * Doc 4 — Commercial Invoice Exchange v1.1
 *
 * Rules:
 *   - Must be PDF format (magic bytes %PDF)
 *   - Images must be ≥ 300 DPI (Doc 4 §1.2)
 *   - One file per shipment
 *   - Max file size 10MB
 *   - Label must be generated first (parcel ID required for naming)
 */
@Component
@Slf4j
public class InvoiceValidator {

    private static final long   MAX_FILE_SIZE = 10 * 1024 * 1024;  // 10MB
    private static final int    MIN_DPI       = 300;                // Doc 4 §1.2
    private static final byte[] PDF_MAGIC     = {0x25, 0x50, 0x44, 0x46}; // %PDF

    /**
     * Validate uploaded invoice file
     *
     * @param file       uploaded multipart file
     * @param shipmentId shipment this invoice belongs to
     * @return list of validation errors (empty = valid)
     */
    public List<String> validate(MultipartFile file, Long shipmentId) {
        List<String> errors = new ArrayList<>();

        if (file == null || file.isEmpty()) {
            errors.add("Invoice file is empty or missing");
            return errors;
        }

        // ── File size ──────────────────────────────────────────────────
        if (file.getSize() > MAX_FILE_SIZE) {
            errors.add(String.format(
                "File size %d bytes exceeds maximum of 10MB", file.getSize()));
        }

        // ── File extension ────────────────────────────────────────────
        String name = file.getOriginalFilename();
        if (name == null || !name.toUpperCase().endsWith(".PDF")) {
            errors.add("File must be a PDF (.pdf extension required)");
        }

        byte[] bytes;
        try {
            bytes = file.getBytes();
        } catch (Exception e) {
            errors.add("Could not read file: " + e.getMessage());
            return errors;
        }

        // ── PDF magic bytes ───────────────────────────────────────────
        if (!isPdf(bytes)) {
            errors.add("File is not a valid PDF (missing %PDF header)");
            return errors;  // no point checking DPI if not PDF
        }

        // ── DPI check — Doc 4 §1.2: images must be ≥ 300 DPI ─────────
        // FIX: actual DPI validation via PDFBox (was just size heuristic)
        List<String> dpiErrors = checkDpi(bytes);
        errors.addAll(dpiErrors);

        if (errors.isEmpty()) {
            log.debug("Invoice file valid: {} ({} bytes)", name, file.getSize());
        } else {
            log.warn("Invoice validation failed for shipment {}: {}", shipmentId, errors);
        }

        return errors;
    }

    /**
     * Validate raw bytes (programmatically generated invoices)
     */
    public List<String> validateBytes(byte[] bytes, String fileName) {
        List<String> errors = new ArrayList<>();
        if (bytes == null || bytes.length == 0) {
            errors.add("Bytes are empty");
            return errors;
        }
        if (!isPdf(bytes)) {
            errors.add("Bytes do not represent a valid PDF");
        }
        if (bytes.length > MAX_FILE_SIZE) {
            errors.add("File too large: " + bytes.length + " bytes");
        }
        errors.addAll(checkDpi(bytes));
        return errors;
    }

    // ==================================================================
    // DPI VALIDATION — Doc 4 §1.2
    // ==================================================================

    /**
     * Check that all embedded images in the PDF are ≥ 300 DPI.
     *
     * DPI = pixels / (physical size in inches)
     * Physical size comes from the PDF page dimensions (in points, 1pt = 1/72 inch).
     * If a page has embedded images, we check each image's resolution.
     *
     * Note: If the PDF contains no embedded raster images (text-only or
     * vector PDF), DPI check is skipped — vectors are resolution-independent.
     */
    private List<String> checkDpi(byte[] bytes) {
        List<String> errors = new ArrayList<>();
        try (PDDocument pdf = Loader.loadPDF(bytes)) {

            int pageNum = 0;
            for (PDPage page : pdf.getPages()) {
                pageNum++;

                // Page dimensions in points (1pt = 1/72 inch)
                float pageWidthInch  = page.getMediaBox().getWidth()  / 72f;
                float pageHeightInch = page.getMediaBox().getHeight() / 72f;

                // Check each embedded image on this page
                var resources = page.getResources();
                if (resources == null) continue;

                for (var xobjName : resources.getXObjectNames()) {
                    try {
                        var xobj = resources.getXObject(xobjName);
                        if (!(xobj instanceof PDImageXObject image)) continue;

                        int  pixWidth  = image.getWidth();
                        int  pixHeight = image.getHeight();

                        // Calculate effective DPI
                        float dpiX = pixWidth  / pageWidthInch;
                        float dpiY = pixHeight / pageHeightInch;
                        float dpi  = Math.min(dpiX, dpiY);

                        log.debug("Page {}: image {}x{} px on {}x{} inch page → {:.0f} DPI",
                                  pageNum, pixWidth, pixHeight,
                                  pageWidthInch, pageHeightInch, dpi);

                        if (dpi < MIN_DPI) {
                            errors.add(String.format(
                                "Page %d: image DPI %.0f is below minimum %d DPI "
                                + "(Doc 4 §1.2 requires ≥ %d DPI)",
                                pageNum, dpi, MIN_DPI, MIN_DPI));
                        }
                    } catch (Exception e) {
                        log.debug("Could not check image on page {}: {}", pageNum, e.getMessage());
                    }
                }
            }

            if (pageNum == 0) {
                errors.add("PDF has no pages");
            }

        } catch (Exception e) {
            // DPI check failed — warn but don't block (PDF may still be valid)
            log.warn("DPI check skipped (PDF parse error): {}", e.getMessage());
        }
        return errors;
    }

    private boolean isPdf(byte[] bytes) {
        if (bytes.length < 4) return false;
        return bytes[0] == PDF_MAGIC[0]
            && bytes[1] == PDF_MAGIC[1]
            && bytes[2] == PDF_MAGIC[2]
            && bytes[3] == PDF_MAGIC[3];
    }
}
