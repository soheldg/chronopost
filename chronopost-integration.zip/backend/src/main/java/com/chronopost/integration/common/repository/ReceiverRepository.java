package com.chronopost.integration.common.repository;
import com.chronopost.integration.common.model.Receiver;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
@Repository
public interface ReceiverRepository extends JpaRepository<Receiver, Long> {
    Optional<Receiver> findByShipmentId(Long shipmentId);
}
