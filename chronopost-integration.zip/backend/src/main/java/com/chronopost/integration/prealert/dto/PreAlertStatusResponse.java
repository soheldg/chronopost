package com.chronopost.integration.prealert.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PreAlertStatusResponse {
    private Long shipmentId;
    private String mpsId, shipmentStatus, fileName, sentAt;
    private boolean prealertSent;
}
