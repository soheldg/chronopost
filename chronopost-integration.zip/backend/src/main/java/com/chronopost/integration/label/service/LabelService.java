package com.chronopost.integration.label.service;

import com.chronopost.integration.common.config.ChronopostConfig;
import com.chronopost.integration.common.model.Parcel;
import com.chronopost.integration.common.model.Receiver;
import com.chronopost.integration.common.model.Sender;
import com.chronopost.integration.common.model.Shipment;
import com.chronopost.integration.common.repository.ParcelRepository;
import com.chronopost.integration.common.repository.ShipmentRepository;
import com.chronopost.integration.label.dto.LabelData;
import com.chronopost.integration.label.dto.LabelRequest;
import com.chronopost.integration.label.dto.LabelResponse;
import com.chronopost.integration.label.generator.*;
import com.chronopost.integration.product.ProductService;
import com.chronopost.integration.routing.RoutingService;
import com.chronopost.integration.routing.RoutingService.RoutingInfo;
import com.chronopost.integration.product.ProductService.ProductInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Label Service - orchestrates the full label generation process
 *
 * Steps:
 * 1. Load shipment + parcel + sender + receiver from DB
 * 2. Generate Chronopost Parcel ID (13 chars)
 * 3. Generate Geopost Tracking ID (15 chars)
 * 4. Build Routing Barcode (28+1 chars)
 * 5. Build routing display info
 * 6. Assemble LabelData
 * 7. Generate PDF
 * 8. Save PDF to disk
 * 9. Update Parcel in DB (parcel number, tracking ID, label path)
 * 10. Update Shipment status → LABEL_READY
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class LabelService {

    private final ShipmentRepository  shipmentRepo;
    private final ParcelRepository     parcelRepo;
    private final ParcelIdGenerator    parcelIdGen;
    private final TrackingIdGenerator  trackingIdGen;
    private final RoutingCalculator    routingCalc;
    private final LabelPdfGenerator    pdfGenerator;
    private final ChronopostConfig     config;
    private final ProductService        productService;
    private final RoutingService        routingService;

    /**
     * Generate label for a specific parcel in a shipment
     */
    @Transactional
    public LabelResponse generateLabel(LabelRequest request)
            throws Exception {

        log.info("Generating label for shipment: {}, parcel: {}",
                 request.getShipmentId(), request.getParcelId());

        // ─── 1. Load data from DB ─────────────────────────────────────
        Shipment shipment = shipmentRepo
            .findByIdWithDetails(request.getShipmentId())
            .orElseThrow(() -> new IllegalArgumentException(
                "Shipment not found: " + request.getShipmentId()));

        Parcel parcel = parcelRepo
            .findById(request.getParcelId())
            .orElseThrow(() -> new IllegalArgumentException(
                "Parcel not found: " + request.getParcelId()));

        Sender   sender   = shipment.getSender();
        Receiver receiver = shipment.getReceiver();

        // ─── 2. Resolve product info from CHR_PRODUCTS (replaces hardcoded values)
        // Auto-selects 327 (normal >3kg) or 328 (small ≤3kg) based on weight
        ProductInfo product = productService.resolveByWeight(parcel.getDeclaredWeight());
        log.info("Product resolved: code={} suffix={} name={}",
                 product.getServiceCode(), product.getProductSuffix(),
                 product.getDeliveryServiceName());

        // ─── 3. Generate Chronopost Parcel ID ────────────────────────
        String parcelId13 = parcelIdGen.generate(
            request.getCustomerPrefix(),
            product.getProductSuffix()   // from DB, was hardcoded "JF"
        );
        char ccKey = parcelIdGen.calculateCcKey(parcelId13);

        log.info("Generated Parcel ID: {}", parcelId13);

        // ─── 3. Generate Geopost Tracking ID ─────────────────────────
        // Extract counter from parcel ID (chars 5-10)
        String counter = parcelId13.substring(5, 11);
        String trackingId15 = trackingIdGen.generate(
            request.getGeopostSenderId(),
            counter
        );

        log.info("Generated Tracking ID: {}", trackingId15);

        // ─── 4. Auto-resolve routing from CHR_ROUTING table ──────────────
        // FIX: Previously caller had to manually provide origSort, agencyCode,
        //      distribSort, countryNumericalCode — now auto-resolved from DB
        RoutingInfo routing = routingService.resolve(
            "DPD",                       // service type for international B2C
            receiver.getCountryCode(),   // e.g. "BE", "FR", "DE"
            receiver.getZipcode()        // raw zip, normalizer handles GB/NL/PT
        );

        log.info("Routing resolved: origSort={} agency={} distrib={} numCC={}",
                 routing.getOrigSort(), routing.getAgencyCode(),
                 routing.getDistribSort(), routing.getNumCountryCode());

        // ─── 5. Build Routing Barcode ─────────────────────────────────────
        String trackingId14 = trackingIdGen.extractBase14(trackingId15);

        RoutingCalculator.RoutingBarcodeResult routingBarcode =
            routingCalc.buildRoutingBarcode(
                routing.getNormalizedZip(),           // already normalized for barcode
                trackingId14,
                product.getServiceCode(),
                routing.getNumCountryCode()           // from CHR_ROUTING col 9
            );

        log.debug("Routing barcode: {}", routingBarcode.getFormattedDisplay());

        // ─── 6. Build routing display info ────────────────────────────────
        RoutingCalculator.RoutingDisplayInfo routingDisplay =
            routingCalc.buildRoutingDisplay(
                routing.getOrigSort(),                // from CHR_ROUTING col 5
                receiver.getCountryCode(),
                routing.getAgencyCode(),              // from CHR_ROUTING col 6
                routing.getDistribSort(),             // from CHR_ROUTING col 7
                null                                  // lotAcheminement in distribSort
            );

        String routingInfo = routingCalc.buildRoutingInfo(
            product.getServiceCode(),
            receiver.getCountryCode(),
            receiver.getZipcode()
        );

        // ─── 6. Assemble LabelData ────────────────────────────────────
        LabelData labelData = buildLabelData(
            shipment, parcel, sender, receiver,
            parcelId13, trackingId15,
            routingBarcode, routingDisplay,
            routingInfo, request, product  // pass resolved product
        );

        // ─── 7. Generate PDF ──────────────────────────────────────────
        byte[] pdfBytes = pdfGenerator.generate(labelData);

        // ─── 8. Save PDF to disk ──────────────────────────────────────
        String fileName = parcelId13 + "_"
            + LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
            + ".pdf";

        Path outputDir = Paths.get(config.getLabel().getOutputPath());
        Files.createDirectories(outputDir);
        Path labelPath = outputDir.resolve(fileName);
        Files.write(labelPath, pdfBytes);

        log.info("Label saved: {}", labelPath);

        // ─── 9. Update Parcel in DB ───────────────────────────────────
        parcel.setParcelNumber(parcelId13);
        parcel.setParcelCcKey(String.valueOf(ccKey));
        parcel.setGeopostTrackId(trackingId15);
        parcel.setRoutingBarcode(routingBarcode.getForPrinting());
        parcel.setLabelPath(labelPath.toString());
        parcel.setLabelStatus(Parcel.LabelStatus.GENERATED);
        parcelRepo.save(parcel);

        // ─── 10. Update Shipment status ───────────────────────────────
        boolean allLabelsGenerated = shipment.getParcels().stream()
            .allMatch(p -> Parcel.LabelStatus.GENERATED
                          .equals(p.getLabelStatus()));

        if (allLabelsGenerated) {
            shipment.setStatus(Shipment.ShipmentStatus.LABEL_READY);
            shipmentRepo.save(shipment);
            log.info("All labels generated for shipment: {}",
                     shipment.getId());
        }

        return LabelResponse.builder()
            .parcelDbId(parcel.getId())
            .chronopostParcelId(parcelId13)
            .geopostTrackingId(trackingId15)
            .routingBarcodeDisplay(routingBarcode.getFormattedDisplay())
            .labelFilePath(labelPath.toString())
            .labelStatus(Parcel.LabelStatus.GENERATED.name())
            .generatedAt(LocalDateTime.now().toString())
            .build();
    }

    /**
     * Get label PDF bytes for preview/download
     */
    public byte[] getLabelPdf(Long parcelId) throws IOException {
        Parcel parcel = parcelRepo.findById(parcelId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Parcel not found: " + parcelId));

        if (parcel.getLabelPath() == null) {
            throw new IllegalStateException(
                "Label not yet generated for parcel: " + parcelId);
        }

        return Files.readAllBytes(Paths.get(parcel.getLabelPath()));
    }

    // =====================================================================
    // PRIVATE HELPER
    // =====================================================================

    private LabelData buildLabelData(
            Shipment     shipment,
            Parcel       parcel,
            Sender       sender,
            Receiver     receiver,
            String       parcelId13,
            String       trackingId15,
            RoutingCalculator.RoutingBarcodeResult routingBarcode,
            RoutingCalculator.RoutingDisplayInfo   routingDisplay,
            String       routingInfo,
            LabelRequest request,
            ProductInfo  product) {    // FIX: product info from DB

        // Weight in KG formatted
        String weightKg = parcel.getDeclaredWeight() != null
            ? String.format("%.3f", parcel.getDeclaredWeight() / 1000.0)
            : "0.000";

        // Determine customs clearance code
        String clearanceCode = request.getCustomsClearanceCode() != null
            ? request.getCustomsClearanceCode()
            : "HY-NP";

        return LabelData.builder()
            // Identifiers
            .parcelId(parcelId13)
            .geopostTrackingId(
                trackingIdGen.formatForLabel(trackingId15))
            .masterParcelGeopostId(trackingId15)

            // Routing barcode
            .routingBarcodeForEncoding(routingBarcode.getForBarcode())
            .routingBarcodeForPrinting(routingBarcode.getFormattedDisplay())

            // Routing display
            .origineSort(routingDisplay.getOrigineSort())
            .routingCenterDisplay(routingDisplay.getCenterDisplay())
            .distribSort(routingDisplay.getDistribSort())
            .geopostRoutingInfo(routingInfo)
            .geopostServiceMention(product.getGeopostServiceMention()) // from CHR_PRODUCTS col 5
            .routingVersion(request.getRoutingVersion())
            .sortCode("MAR")
            .parcelTag("")

            // Receiver
            .receiverName1(receiver.getName1())
            .receiverName2(receiver.getName2())
            .receiverStreet(receiver.getStreet())
            .receiverStreet2(receiver.getAdd2())
            .receiverCity(receiver.getTown())
            .receiverZipcode(receiver.getZipcode())
            .receiverCountryCode(receiver.getCountryCode())
            .receiverCountryName(receiver.getCountryCode())
            .receiverPhone(receiver.getPhone1())
            .consigneeCode(receiver.getName1())

            // Sender
            .senderAccountNo(sender.getAccountNo())
            .senderName(sender.getName1() != null
                         ? sender.getName1()
                         : sender.getCompanyName())
            .senderAddress(sender.getStreet())
            .senderCity(sender.getTown())
            .senderCountry(sender.getCountryCode())
            .senderPhone(sender.getPhone())
            .senderReference(shipment.getMpsId())

            // Shipment details
            .weightKg(weightKg)
            .parcelRank(parcel.getParcelRank())
            .totalParcels(shipment.getMpscount())

            // Customs
            .customsValue(null)
            .customsCurrency("EUR")
            .customsClearanceCode(clearanceCode)

            // Service
            .deliveryServiceName(product.getDeliveryServiceName())  // from CHR_PRODUCTS col 17
            .build();
    }
}
