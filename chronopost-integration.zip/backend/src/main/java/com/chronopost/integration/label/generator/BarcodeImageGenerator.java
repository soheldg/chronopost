package com.chronopost.integration.label.generator;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Generates Code128 barcodes using ZXing library
 *
 * Two barcodes are needed per label:
 * 1. Chronopost Parcel ID barcode (13 chars, Code128)
 * 2. Geopost Routing barcode (28 chars, Code128)
 *
 * As per Doc 3 sections 2.6.1.1 and 2.5.1
 */
@Component
@Slf4j
public class BarcodeImageGenerator {

    private static final int DEFAULT_HEIGHT  = 60;  // pixels
    private static final int DEFAULT_MARGIN  = 0;

    /**
     * Generate Code128 barcode as byte array (PNG)
     *
     * @param content barcode content string
     * @param width   barcode width in pixels
     * @param height  barcode height in pixels
     * @return PNG image as byte array
     */
    public byte[] generateCode128(String content, int width, int height)
            throws WriterException, IOException {

        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.MARGIN, DEFAULT_MARGIN);

        MultiFormatWriter writer = new MultiFormatWriter();
        BitMatrix bitMatrix = writer.encode(
            content,
            BarcodeFormat.CODE_128,
            width,
            height,
            hints
        );

        BufferedImage image = MatrixToImageWriter.toBufferedImage(bitMatrix);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "PNG", baos);

        log.debug("Generated Code128 barcode for content length: {}",
                  content.length());

        return baos.toByteArray();
    }

    /**
     * Generate Chronopost Parcel ID barcode
     * Width: ~170mm at 300 DPI ≈ 2008px → scaled to label width
     * Height: 0.3cm = ~34px at 300 DPI
     *
     * Uses subsets B and C as per spec:
     *   Subset B: first 3 chars (e.g., "HY7")
     *   Subset C: next 8 digits (e.g., "12000002")
     *   Subset B: last 2 chars (e.g., "JF")
     */
    public byte[] generateParcelIdBarcode(String parcelId13)
            throws WriterException, IOException {

        if (parcelId13 == null || parcelId13.length() != 13) {
            throw new IllegalArgumentException(
                "Parcel ID must be 13 characters");
        }

        // Width for parcel ID barcode on 102mm label
        // At 300 DPI: 102mm = ~1205px, barcode ~70% of width
        return generateCode128(parcelId13, 800, DEFAULT_HEIGHT);
    }

    /**
     * Generate Geopost Routing barcode
     * Content: % prefix + 27 chars (% is in barcode, not printed below)
     * Checksum character is printed below barcode but NOT in barcode content
     *
     * As per Doc 3, section 2.5.1
     */
    public byte[] generateRoutingBarcode(String routingForBarcode)
            throws WriterException, IOException {

        if (routingForBarcode == null
                || !routingForBarcode.startsWith("%")
                || routingForBarcode.length() != 28) {
            throw new IllegalArgumentException(
                "Routing barcode content must start with % and be 28 chars");
        }

        // Full width of label for routing barcode
        return generateCode128(routingForBarcode, 1100, DEFAULT_HEIGHT + 10);
    }

    /**
     * Generate barcode as BufferedImage (for direct use in PDF)
     */
    public BufferedImage generateCode128Image(String content,
                                               int width,
                                               int height)
            throws WriterException {

        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.MARGIN, DEFAULT_MARGIN);

        MultiFormatWriter writer = new MultiFormatWriter();
        BitMatrix bitMatrix = writer.encode(
            content,
            BarcodeFormat.CODE_128,
            width,
            height,
            hints
        );

        return MatrixToImageWriter.toBufferedImage(bitMatrix);
    }
}
