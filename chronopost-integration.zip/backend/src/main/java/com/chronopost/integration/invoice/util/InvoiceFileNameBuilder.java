package com.chronopost.integration.invoice.util;

import org.springframework.stereotype.Component;

/**
 * Builds invoice file names per Doc 4 - Commercial Invoice Exchange
 *
 * Naming convention:
 *   Flow from Partner to Chronopost: INV_type_account_ID15.PDF
 *   Flow from Chronopost to Partner: INV_DDD_ID15.PDF
 *
 * Where:
 *   type    = EXP (export) or IMP (import)
 *   account = Chronopost account number
 *   ID15    = Chronopost parcel reference (15 chars)
 *   DDD     = trigram of destination (IATA/partner code)
 */
@Component
public class InvoiceFileNameBuilder {

    /**
     * Build file name for upload to Chronopost
     * Format: INV_EXP_account_parcelId.PDF
     *
     * @param type      "EXP" or "IMP"
     * @param account   Chronopost account number
     * @param parcelId  Chronopost parcel reference
     * @return file name, e.g. "INV_EXP_12345678_HY712000001JF.PDF"
     */
    public String buildUploadFileName(String type,
                                       String account,
                                       String parcelId) {
        validateType(type);
        return String.format("INV_%s_%s_%s.PDF",
            type.toUpperCase(),
            sanitize(account),
            sanitize(parcelId));
    }

    /**
     * Build export invoice file name
     */
    public String buildExportFileName(String account, String parcelId) {
        return buildUploadFileName("EXP", account, parcelId);
    }

    /**
     * Build import invoice file name
     */
    public String buildImportFileName(String account, String parcelId) {
        return buildUploadFileName("IMP", account, parcelId);
    }

    /**
     * Parse file name downloaded from Chronopost
     * Format: INV_DDD_ID15.PDF
     */
    public ParsedInvoiceFileName parseDownloadedFileName(String fileName) {
        if (fileName == null || !fileName.toUpperCase().endsWith(".PDF")) {
            throw new IllegalArgumentException(
                "Invalid invoice file name: " + fileName);
        }

        // Remove .PDF extension
        String base = fileName.substring(0, fileName.lastIndexOf('.'));
        String[] parts = base.split("_", 3);

        if (parts.length < 3 || !"INV".equals(parts[0])) {
            throw new IllegalArgumentException(
                "Invalid invoice file name format: " + fileName);
        }

        return ParsedInvoiceFileName.builder()
            .originalName(fileName)
            .destination(parts[1])    // DDD
            .parcelId(parts[2])       // ID15
            .build();
    }

    /**
     * Check if a file name looks like an invoice file
     */
    public boolean isInvoiceFile(String fileName) {
        return fileName != null
            && fileName.toUpperCase().startsWith("INV_")
            && fileName.toUpperCase().endsWith(".PDF");
    }

    private void validateType(String type) {
        if (!"EXP".equalsIgnoreCase(type) && !"IMP".equalsIgnoreCase(type)) {
            throw new IllegalArgumentException(
                "Invoice type must be EXP or IMP, got: " + type);
        }
    }

    private String sanitize(String s) {
        return s == null ? "" : s.replaceAll("[^A-Za-z0-9]", "");
    }

    @lombok.Data
    @lombok.Builder
    public static class ParsedInvoiceFileName {
        private String originalName;
        private String destination;  // DDD
        private String parcelId;     // ID15
    }
}
