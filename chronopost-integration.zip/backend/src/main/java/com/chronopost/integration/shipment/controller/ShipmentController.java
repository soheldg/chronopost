package com.chronopost.integration.shipment.controller;

import com.chronopost.integration.common.dto.ApiResponse;
import com.chronopost.integration.shipment.dto.*;
import com.chronopost.integration.shipment.service.ShipmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Shipment REST Controller
 *
 * Endpoints:
 *   POST /shipment/create         → Create new shipment
 *   GET  /shipment/list           → List all shipments
 *   GET  /shipment/list?status=   → Filter by status
 *   GET  /shipment/{id}           → Get shipment detail
 */
@RestController
@RequestMapping("/shipment")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class ShipmentController {

    private final ShipmentService shipmentService;

    /**
     * Create a new shipment
     * POST /shipment/create
     */
    @PostMapping("/create")
    public ResponseEntity<ApiResponse<ShipmentCreateResponse>> create(
            @Valid @RequestBody ShipmentCreateRequest request) {

        log.info("Create shipment request: account={}",
                 request.getSender().getAccountNo());
        try {
            ShipmentCreateResponse response =
                shipmentService.create(request);
            return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok(
                    "Shipment created. Next step: Generate Label.", response));
        } catch (Exception e) {
            log.error("Shipment create error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * List shipments (all or by status)
     * GET /shipment/list
     * GET /shipment/list?status=CREATED
     */
    @GetMapping("/list")
    public ResponseEntity<ApiResponse<List<ShipmentListDto>>> list(
            @RequestParam(required = false) String status) {
        try {
            List<ShipmentListDto> result = status != null
                ? shipmentService.listByStatus(status)
                : shipmentService.listAll();
            return ResponseEntity.ok(ApiResponse.ok(result));
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * Update sender address fields
     * PUT /shipment/{id}/sender
     * Body: { "name1":"...", "street":"...", "zipcode":"...", "town":"...", ... }
     */
    @PutMapping("/{id}/sender")
    public ResponseEntity<ApiResponse<String>> updateSender(
            @PathVariable Long id,
            @RequestBody Map<String, String> fields) {
        try {
            shipmentService.updateSender(id, fields);
            return ResponseEntity.ok(ApiResponse.ok("Sender updated successfully", "OK"));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            log.error("Sender update error for {}: {}", id, e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * Update receiver address fields
     * PUT /shipment/{id}/receiver
     * Body: { "name1":"...", "street":"...", "zipcode":"...", "town":"...", ... }
     */
    @PutMapping("/{id}/receiver")
    public ResponseEntity<ApiResponse<String>> updateReceiver(
            @PathVariable Long id,
            @RequestBody Map<String, String> fields) {
        try {
            shipmentService.updateReceiver(id, fields);
            return ResponseEntity.ok(ApiResponse.ok("Receiver updated successfully", "OK"));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            log.error("Receiver update error for {}: {}", id, e.getMessage(), e);
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }

    /**
     * Get shipment detail
     * GET /shipment/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ShipmentCreateResponse>> getDetail(
            @PathVariable Long id) {
        try {
            return ResponseEntity.ok(
                ApiResponse.ok(shipmentService.getDetail(id)));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError()
                .body(ApiResponse.error(e.getMessage()));
        }
    }
}
