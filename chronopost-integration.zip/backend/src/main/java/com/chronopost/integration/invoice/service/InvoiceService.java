package com.chronopost.integration.invoice.service;

import com.chronopost.integration.common.config.ChronopostConfig;
import com.chronopost.integration.common.model.*;
import com.chronopost.integration.common.repository.ParcelRepository;
import com.chronopost.integration.common.repository.ShipmentRepository;
import com.chronopost.integration.invoice.dto.*;
import com.chronopost.integration.invoice.repository.InvoiceFileRepository;
import com.chronopost.integration.invoice.util.*;
import com.chronopost.integration.prealert.sftp.SftpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Invoice Service
 *
 * Handles:
 * 1. Upload invoice PDF from customer → Chronopost FTP /IN
 * 2. Download invoice PDF from Chronopost FTP /OUT
 * 3. List invoice files for a shipment
 * 4. Track upload/download status in DB
 *
 * File naming (Doc 4):
 *   Upload: INV_EXP_account_parcelId.PDF
 *   Download: INV_DDD_ID15.PDF
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class InvoiceService {

    private final ShipmentRepository    shipmentRepo;
    private final ParcelRepository      parcelRepo;
    private final InvoiceFileRepository invoiceFileRepo;
    private final SftpService           sftpService;
    private final InvoiceValidator      validator;
    private final InvoiceFileNameBuilder fileNameBuilder;
    private final ChronopostConfig      config;

    // =====================================================================
    // UPLOAD: Customer → Chronopost FTP
    // =====================================================================

    /**
     * Upload invoice PDF to Chronopost FTP /IN directory
     *
     * @param file        PDF file uploaded by user
     * @param shipmentId  shipment this invoice belongs to
     * @param invoiceType "EXP" or "IMP"
     * @return upload result
     */
    @Transactional
    public InvoiceUploadResponse upload(MultipartFile file,
                                         Long shipmentId,
                                         String invoiceType) throws IOException {

        log.info("Invoice upload request: shipment={}, type={}",
                 shipmentId, invoiceType);

        // ─── 1. Validate file ─────────────────────────────────────────
        List<String> errors = validator.validate(file, shipmentId);
        if (!errors.isEmpty()) {
            return InvoiceUploadResponse.builder()
                .shipmentId(shipmentId)
                .success(false)
                .errors(errors)
                .build();
        }

        // ─── 2. Load shipment + parcel ────────────────────────────────
        Shipment shipment = shipmentRepo
            .findByIdWithDetails(shipmentId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Shipment not found: " + shipmentId));

        // Use first parcel's number for file name
        Parcel firstParcel = shipment.getParcels().stream()
            .findFirst()
            .orElseThrow(() -> new IllegalStateException(
                "No parcels found for shipment: " + shipmentId));

        if (firstParcel.getParcelNumber() == null) {
            return InvoiceUploadResponse.builder()
                .shipmentId(shipmentId)
                .success(false)
                .errors(List.of(
                    "Label must be generated before uploading invoice"))
                .build();
        }

        String accountNo = shipment.getSender().getAccountNo();

        // ─── 3. Build file name ───────────────────────────────────────
        String fileName = fileNameBuilder.buildUploadFileName(
            invoiceType,
            accountNo,
            firstParcel.getParcelNumber()
        );

        // ─── 4. Save file to local disk ───────────────────────────────
        byte[] fileBytes = file.getBytes();
        Path outputDir  = Paths.get(config.getInvoice().getOutputPath());
        Files.createDirectories(outputDir);
        Path localPath = outputDir.resolve(fileName);
        Files.write(localPath, fileBytes);

        log.debug("Invoice saved locally: {}", localPath);

        // ─── 5. Upload to Chronopost FTP ──────────────────────────────
        boolean uploaded = sftpService.uploadBinaryFile(fileName, fileBytes);

        String ftpStatus = uploaded ? "SENT" : "FAILED";
        String errorMsg  = uploaded ? null : "FTP upload failed";

        // ─── 6. Save record to DB ─────────────────────────────────────
        InvoiceFile invoiceFile = InvoiceFile.builder()
            .shipment(shipment)
            .fileName(fileName)
            .filePath(localPath.toString())
            .direction("OUT")
            .ftpStatus(ftpStatus)
            .errorMsg(errorMsg)
            .uploadedAt(uploaded ? LocalDateTime.now() : null)
            .build();

        invoiceFileRepo.save(invoiceFile);

        // ─── 7. Update shipment status ────────────────────────────────
        if (uploaded) {
            shipment.setStatus(Shipment.ShipmentStatus.INVOICE_SENT);
            shipmentRepo.save(shipment);
            log.info("Invoice uploaded: {}", fileName);
        } else {
            log.error("Invoice FTP upload failed: {}", fileName);
        }

        return InvoiceUploadResponse.builder()
            .shipmentId(shipmentId)
            .invoiceFileId(invoiceFile.getId())
            .fileName(fileName)
            .fileSize(fileBytes.length)
            .ftpStatus(ftpStatus)
            .success(uploaded)
            .uploadedAt(uploaded ? LocalDateTime.now().toString() : null)
            .errors(uploaded ? null : List.of("FTP upload failed"))
            .build();
    }

    // =====================================================================
    // FETCH: Download new invoices from Chronopost FTP /OUT
    // =====================================================================

    /**
     * Poll Chronopost FTP /OUT directory and download new invoice files
     * Called by scheduler every N minutes
     *
     * @return number of invoices downloaded
     */
    @Transactional
    public InvoiceFetchResult fetchFromChronopost() {
        log.info("Fetching invoices from Chronopost FTP /OUT");

        List<String> allFiles    = sftpService.listOutboundFiles();
        List<String> invoiceFiles = allFiles.stream()
            .filter(fileNameBuilder::isInvoiceFile)
            .collect(Collectors.toList());

        log.debug("Found {} invoice files in FTP /OUT", invoiceFiles.size());

        int downloaded = 0;
        int failed     = 0;
        List<String> downloadedNames = new ArrayList<>();

        for (String fileName : invoiceFiles) {
            try {
                boolean success = downloadSingleInvoice(fileName);
                if (success) {
                    downloaded++;
                    downloadedNames.add(fileName);
                    // Delete from FTP after successful download (per Doc 4)
                    sftpService.deleteOutboundFile(fileName);
                } else {
                    failed++;
                }
            } catch (Exception e) {
                log.error("Error downloading invoice {}: {}",
                          fileName, e.getMessage(), e);
                failed++;
            }
        }

        log.info("Invoice fetch complete: {} downloaded, {} failed",
                 downloaded, failed);

        return InvoiceFetchResult.builder()
            .totalFound(invoiceFiles.size())
            .downloaded(downloaded)
            .failed(failed)
            .fileNames(downloadedNames)
            .fetchedAt(LocalDateTime.now().toString())
            .build();
    }

    /**
     * Download a single invoice from FTP and save to DB + disk
     */
    private boolean downloadSingleInvoice(String fileName) throws IOException {

        // Skip if already downloaded
        if (invoiceFileRepo.existsByFileNameAndDirection(fileName, "IN")) {
            log.debug("Invoice already downloaded: {}", fileName);
            return true;
        }

        // Download from FTP
        byte[] fileBytes = sftpService.downloadBinaryFile(fileName);
        if (fileBytes == null) {
            log.error("Download returned null for: {}", fileName);
            return false;
        }

        // Parse file name to get parcel ID
        InvoiceFileNameBuilder.ParsedInvoiceFileName parsed =
            fileNameBuilder.parseDownloadedFileName(fileName);

        // Find matching parcel
        Parcel parcel = parcelRepo
            .findByParcelNumber(parsed.getParcelId())
            .orElse(null);

        // Save file to disk
        Path outputDir = Paths.get(config.getInvoice().getOutputPath(),
                                    "received");
        Files.createDirectories(outputDir);
        Path localPath = outputDir.resolve(fileName);
        Files.write(localPath, fileBytes);

        // Save record to DB
        InvoiceFile invoiceFile = InvoiceFile.builder()
            .shipment(parcel != null ? parcel.getShipment() : null)
            .fileName(fileName)
            .filePath(localPath.toString())
            .direction("IN")
            .ftpStatus("RECEIVED")
            .uploadedAt(LocalDateTime.now())
            .build();

        invoiceFileRepo.save(invoiceFile);

        log.info("Invoice downloaded and saved: {} ({} bytes)",
                 fileName, fileBytes.length);
        return true;
    }

    // =====================================================================
    // LIST invoices for a shipment
    // =====================================================================

    public List<InvoiceFileDto> listByShipment(Long shipmentId) {
        return invoiceFileRepo.findByShipmentId(shipmentId)
            .stream()
            .map(this::toDto)
            .collect(Collectors.toList());
    }

    /**
     * Get all invoices (both sent and received)
     */
    public List<InvoiceFileDto> listAll() {
        return invoiceFileRepo.findAll()
            .stream()
            .map(this::toDto)
            .collect(Collectors.toList());
    }

    // =====================================================================
    // DOWNLOAD invoice PDF to browser
    // =====================================================================

    public byte[] getInvoicePdf(Long invoiceFileId) throws IOException {
        InvoiceFile invoiceFile = invoiceFileRepo
            .findById(invoiceFileId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Invoice file not found: " + invoiceFileId));

        if (invoiceFile.getFilePath() == null) {
            throw new IllegalStateException(
                "No local file path for invoice: " + invoiceFileId);
        }

        return Files.readAllBytes(Paths.get(invoiceFile.getFilePath()));
    }

    // =====================================================================
    // RETRY failed upload
    // =====================================================================

    @Transactional
    public InvoiceUploadResponse retry(Long invoiceFileId) throws IOException {
        InvoiceFile invoiceFile = invoiceFileRepo
            .findById(invoiceFileId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Invoice file not found: " + invoiceFileId));

        if (!"FAILED".equals(invoiceFile.getFtpStatus())) {
            return InvoiceUploadResponse.builder()
                .success(false)
                .errors(List.of("Invoice is not in FAILED status"))
                .build();
        }

        byte[] fileBytes = Files.readAllBytes(
            Paths.get(invoiceFile.getFilePath()));

        boolean uploaded = sftpService.uploadBinaryFile(
            invoiceFile.getFileName(), fileBytes);

        invoiceFile.setFtpStatus(uploaded ? "SENT" : "FAILED");
        invoiceFile.setUploadedAt(uploaded ? LocalDateTime.now() : null);
        invoiceFile.setErrorMsg(uploaded ? null : "Retry FTP upload failed");
        invoiceFileRepo.save(invoiceFile);

        return InvoiceUploadResponse.builder()
            .invoiceFileId(invoiceFileId)
            .fileName(invoiceFile.getFileName())
            .ftpStatus(invoiceFile.getFtpStatus())
            .success(uploaded)
            .build();
    }

    // =====================================================================
    // HELPER
    // =====================================================================

    private InvoiceFileDto toDto(InvoiceFile f) {
        return InvoiceFileDto.builder()
            .id(f.getId())
            .shipmentId(f.getShipment() != null
                        ? f.getShipment().getId() : null)
            .fileName(f.getFileName())
            .direction(f.getDirection())
            .ftpStatus(f.getFtpStatus())
            .fileSize(f.getFilePath() != null
                      ? getFileSize(f.getFilePath()) : 0)
            .uploadedAt(f.getUploadedAt() != null
                        ? f.getUploadedAt().toString() : null)
            .createdAt(f.getCreatedAt() != null
                       ? f.getCreatedAt().toString() : null)
            .build();
    }

    private long getFileSize(String path) {
        try {
            return Files.size(Paths.get(path));
        } catch (IOException e) {
            return 0;
        }
    
    // =====================================================================
    // GENERATE INVOICE PDF FROM SHIPMENT DATA
    // =====================================================================
    public byte[] generateInvoicePdf(Long shipmentId) {
        Shipment shipment = shipmentRepo.findByIdWithAllDetails(shipmentId)
            .orElseThrow(() -> new IllegalArgumentException(
                "Shipment not found: " + shipmentId));
        return invoicePdfGenerator.generate(shipment);
    }

}
