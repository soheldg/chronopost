package com.chronopost.integration.invoice.repository;
import com.chronopost.integration.common.model.InvoiceFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface InvoiceFileRepository extends JpaRepository<InvoiceFile,Long> {
    List<InvoiceFile> findByShipmentId(Long shipmentId);
    List<InvoiceFile> findByFtpStatus(String ftpStatus);
    List<InvoiceFile> findByDirection(String direction);
    boolean existsByFileNameAndDirection(String fileName, String direction);
    List<InvoiceFile> findByShipmentIdAndDirection(Long shipmentId, String direction);
}
