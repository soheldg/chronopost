package com.chronopost.integration.common.config;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration
@ConfigurationProperties(prefix = "chronopost")
@Data
public class ChronopostConfig {
    @Data public static class GeoDataConfig {
        private String version="3.32", encoding="ISO-8859-1", dataflow="CONSO", destination="CHR";
    }
    @Data public static class DepotConfig {
        private String sender="0029999", receiver="0020456";
    }
    @Data public static class LabelConfig {
        private String outputPath="./labels";
        private double widthMm=102, heightMm=144;
    }
    @Data public static class InvoiceConfig {
        private String outputPath="./invoices";
    }
    private GeoDataConfig geodata = new GeoDataConfig();
    private DepotConfig depot = new DepotConfig();
    private LabelConfig label = new LabelConfig();
    private InvoiceConfig invoice = new InvoiceConfig();
}
