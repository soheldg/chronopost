package com.chronopost.integration.tracking.dto;

import lombok.*;
import java.time.LocalDate;

/**
 * Parsed tracking event from EDIPOD flat file
 * Maps all 51 fields from Doc 2 - EDIPOD2018 V21.01
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrackingEventDto {

    // ─── Metadata ─────────────────────────────────────────────────────
    private int    lineNumber;
    private String rawLine;

    // ─── Field 01-04: Parcel Identification ───────────────────────────
    /** Field 01: Contract number at carrier (AN8) */
    private String contractNo;

    /** Field 02: Sub account number (AN3) */
    private String subAccountNo;

    /** Field 03: Chronopost tracking number (AN13) e.g. AA123456789FR */
    private String chronopostTrackNo;

    /** Field 04: DPD Group tracking number (AN15) */
    private String dpdGroupTrackNo;

    // ─── Field 05-13: Sender ──────────────────────────────────────────
    private String senderName1;
    private String senderName2;
    private String senderAddress1;
    private String senderAddress2;
    private String senderPostalCode;
    private String senderCity;
    private String senderCountryCode;
    private String senderPhone;
    private String senderEmail;

    // ─── Field 14-23: Consignee ───────────────────────────────────────
    /** Field 14: Consignee code (customer code) */
    private String consigneeCode;
    private String consigneeName1;
    private String consigneeName2;
    private String consigneeAddress1;
    private String consigneeAddress2;
    private String consigneePostalCode;
    private String consigneeCity;
    private String consigneeCountry;
    private String consigneePhone;
    private String consigneeEmail;

    // ─── Field 24-34: Parcel Info ─────────────────────────────────────
    /** Field 24: Parcel deposit date (YYYYMMDD) */
    private LocalDate depositDate;

    /** Field 25: Sender internal reference */
    private String senderRef;

    /** Field 26: Sender internal barcode */
    private String senderBarcode;

    /** Field 27: Beginning of delivery slot (dd/MM/yyyy HH:mm) */
    private String deliverySlotStart;

    /** Field 28: End of delivery slot */
    private String deliverySlotEnd;

    /** Field 29: Product code (AN2) */
    private String productCode;

    /** Field 30: Service code (AN3) */
    private String serviceCode;

    /** Field 31: Insured value amount */
    private String insuredAmount;

    /** Field 32: Insured value currency */
    private String insuredCurrency;

    /** Field 33: Cash on delivery amount */
    private String codAmount;

    /** Field 34: Cash on delivery currency */
    private String codCurrency;

    // ─── Field 35-51: Tracking Event ──────────────────────────────────

    /**
     * Field 35: Parcel event code (AN3)
     * SM=Shipped, DL=Delivered, AT=Attempt, HO=Held, RT=Return etc.
     */
    private String eventCode;

    /** Field 36: Parcel reason code (AN3) e.g. MIS */
    private String reasonCode;

    /** Field 37: Event date (YYYYMMDD) */
    private LocalDate eventDate;

    /** Field 38: Event local hour (hhmm) */
    private String eventTime;

    /**
     * Field 39: Communication channel (AN4)
     * MAIL or SMS (only if event = SM meaning notification sent)
     */
    private String commChannel;

    /** Field 40: Address/phone of communication channel used */
    private String channelAddress;

    /**
     * Field 41: Delivery instruction received
     * MDR, MDBP, MDA, DAT, ANNUL, CHRDV, COMPADD, RVOISIN...
     */
    private String deliveryInstruction;

    /** Field 42: Code of disposal place wanted by consignee */
    private String disposalPlaceCode;

    /** Field 43: New delivery date asked by consignee (YYYYMMDD) */
    private LocalDate newDeliveryDate;

    /** Field 44: Code of PickUp PUDO associated with event */
    private String pickupPudoCode;

    /** Field 45: Name of desk clerk at delivery */
    private String deskClerk;

    /** Field 46: Code of transmitter of the event */
    private String transmitterCode;

    /**
     * Field 47: Declared or measured weight (AN7)
     * Format: kkk.gg (e.g. "0001.60" = 1.6 kg)
     */
    private String declaredWeight;

    /** Field 48: Length in cm */
    private String lengthCm;

    /** Field 49: Width in cm */
    private String widthCm;

    /** Field 50: Height in cm */
    private String heightCm;

    /** Field 51: URL to proof of delivery image */
    private String podImageUrl;

    // ─── Computed fields (not from file) ──────────────────────────────

    /** Human-readable event description */
    private String eventDescription;

    /** Human-readable instruction description */
    private String instructionDescription;

    /** True if this is a delivery event */
    public boolean isDelivered() {
        return "DL".equalsIgnoreCase(eventCode);
    }

    /** True if this is a failed delivery attempt */
    public boolean isFailedAttempt() {
        return "AT".equalsIgnoreCase(eventCode) ||
               "ND".equalsIgnoreCase(eventCode);
    }

    /** True if parcel is in transit */
    public boolean isInTransit() {
        return "SM".equalsIgnoreCase(eventCode) ||
               "EN".equalsIgnoreCase(eventCode) ||
               "EX".equalsIgnoreCase(eventCode) ||
               "LO".equalsIgnoreCase(eventCode) ||
               "AR".equalsIgnoreCase(eventCode) ||
               "WC".equalsIgnoreCase(eventCode) ||
               "OD".equalsIgnoreCase(eventCode);
    }
}
