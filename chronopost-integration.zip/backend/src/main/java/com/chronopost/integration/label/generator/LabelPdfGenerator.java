package com.chronopost.integration.label.generator;

import com.chronopost.integration.label.dto.LabelData;
import com.google.zxing.WriterException;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Chronopost Label PDF Generator
 * Doc 3 — Label ROW-FR-ROE GB V25.01
 *
 * Correct column structure (from audit):
 *
 *   ◄── 50mm ──►◄─ 23mm ─►◄── 19mm ──►◄─10mm─►
 *   0              50         73           92      102mm
 *   +--------------------------------------------------------+ ← 0mm
 *   | r1c1  Zone 1 — Legal disclaimer (7mm, full width)      | ↕ 7mm
 *   +--------------------------------------------------------+ ← 7mm
 *   | r2c1=73mm                      |r2c2=19mm |r2c3=10mm  | ↕
 *   |  Delivery address              | Sender   | Logo      | ↕ 51mm
 *   +---------------------------+----|          |           + ← 58mm
 *   | r3c1=50mm     |r3c2=23mm  |r3c3=19mm*|r3c4=10mm*    | ↕
 *   |  Parcel bc    | MAR       |  HY-DP   | COM INT       | ↕ 28mm
 *   +--------------------------------------------------------+ ← 86mm
 *   | r4c1=73mm                      |r4c2=29mm             | ↕
 *   |  Tracking ID + Routing sort    | D-B2C + DistribSort  | ↕ 27mm
 *   +--------------------------------------------------------+ ← 113mm
 *   | r5  Routing barcode (full width)                       | ↕ 31mm
 *   +--------------------------------------------------------+ ← 144mm
 *
 *   r3c3 and r3c4 are merged with r2c2 and r2c3 (no hline at 58mm there)
 *   Vertical line x=73mm spans Zone 2 + Zone 3 + Zone 4
 *   Vertical line x=92mm spans Zone 2 + Zone 3 only
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class LabelPdfGenerator {

    private final BarcodeImageGenerator barcodeGenerator;

    // ── Label total dimensions ─────────────────────────────────────────
    private static final float MM  = 2.8346f;
    private static final float LW  = 102 * MM;   // 289.13pt
    private static final float LH  = 144 * MM;   // 408.18pt

    // ── Zone heights ───────────────────────────────────────────────────
    private static final float Z1H =  7 * MM;    //  19.84pt
    private static final float Z2H = 51 * MM;    // 144.56pt
    private static final float Z3H = 28 * MM;    //  79.37pt
    private static final float Z4H = 27 * MM;    //  76.53pt
    private static final float Z5H = 31 * MM;    //  87.87pt

    // ── Column X positions (from left edge) ───────────────────────────
    // r2: 73mm | 19mm | 10mm
    private static final float X_73  = 73 * MM;  // 206.93pt  r2c1/r2c2 divider
    private static final float X_92  = 92 * MM;  // 260.78pt  r2c2/r2c3 divider
    // r3: 50mm | 23mm | then merges with r2c2 and r2c3
    private static final float X_50  = 50 * MM;  // 141.73pt  r3c1/r3c2 divider

    // ── Barcode heights ────────────────────────────────────────────────
    private static final float BC1H =  3 * MM;   // Parcel ID barcode — doc §2.6.1.1
    private static final float BC2H = 20 * MM;   // Routing barcode

    // ── Margins ────────────────────────────────────────────────────────
    private static final float MX   = 2 * MM;

    // ── Font sizes per spec ────────────────────────────────────────────
    private static final float F_LEGAL   =  6f;  // Zone1 disclaimer
    private static final float F_ADDR    =  6f;  // Delivery address (Bold)
    private static final float F_SENDER  =  6f;  // Sender address (rotated)
    private static final float F_INFO    =  8f;  // Phone, Ref, Consignment
    private static final float F_WEIGHT  = 12f;  // Weight & rank — spec §2.6.6
    private static final float F_BC_TEXT = 10f;  // Parcel ID text above barcode
    private static final float F_CLEAR   = 14f;  // HY-DP / HY-NP
    private static final float F_TRACK   = 10f;  // Geopost Tracking ID
    private static final float F_ORIG    = 24f;  // OrigSort — spec §8
    private static final float F_CENTER  = 30f;  // Center routing — spec §8
    private static final float F_DISTRIB = 24f;  // DistribSort — spec §8
    private static final float F_ROUTE   = 10f;  // Routing info SSS-CC-PPPPP
    private static final float F_FOOTER  =  6f;  // Date/VP/CHREDI footer
    private static final float F_LOGO    = 12f;  // CHRONOPOST logo text

    private static final DeviceRgb BLACK = new DeviceRgb(0, 0, 0);

    // ==================================================================
    // MAIN ENTRY
    // ==================================================================
    public byte[] generate(LabelData data) throws IOException, WriterException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PdfWriter   writer = new PdfWriter(baos);
        PdfDocument pdfDoc = new PdfDocument(writer);
        Document    doc    = new Document(pdfDoc, new PageSize(LW, LH));
        doc.setMargins(0, 0, 0, 0);

        PdfCanvas cv   = new PdfCanvas(pdfDoc.addNewPage());
        PdfFont   reg  = PdfFontFactory.createFont();
        PdfFont   bold = PdfFontFactory.createFont();

        float top = LH;
        top = drawZone1(cv, reg, top);
        top = drawZone2(cv, doc, reg, bold, data, top);
        top = drawZone3(cv, doc, reg, bold, data, top);
        top = drawZone4(cv, reg, bold, data, top);
        drawZone5(cv, doc, reg, data, top);

        doc.close();
        log.debug("Label generated: {}", data.getParcelId());
        return baos.toByteArray();
    }

    // ==================================================================
    // ZONE 1 — Legal disclaimer (7mm, full width)
    // Font 6pt, max 2 lines
    // ==================================================================
    private float drawZone1(PdfCanvas cv, PdfFont reg, float top)
            throws IOException {
        float bot      = top - Z1H;
        float baseline = bot + (Z1H / 2) - 2f;

        cv.setFontAndSize(reg, F_LEGAL).setFillColor(BLACK)
          .beginText().moveText(MX, baseline)
          // Official text from Mentions_Légales.txt provided by Chronopost
          // Note: "subjet" is Chronopost's official text (not a typo we should fix)
          .showText("On delivery, damage or theft must be the subjet of precise and complete")
          .endText()
          .beginText().moveText(MX, baseline - 7f)
          .showText("reservations, dated and signed by the consignee, on the delivery note.")
          .endText();

        hLine(cv, bot);
        return bot;
    }

    // ==================================================================
    // ZONE 2 — Address area (51mm)
    // Columns: r2c1=73mm | r2c2=19mm | r2c3=10mm
    // Vertical lines at x=73mm and x=92mm
    // ==================================================================
    private float drawZone2(PdfCanvas cv, Document doc,
                             PdfFont reg, PdfFont bold,
                             LabelData d, float top)
            throws IOException, WriterException {

        float bot = top - Z2H;
        float y   = top - 8f;

        // ─ r2c1: Delivery address (Bold 6pt) ──────────────────────────
        cv.setFontAndSize(bold, F_ADDR).setFillColor(BLACK);
        for (String line : new String[]{
            trunc(d.getReceiverName1(), 35),
            trunc(d.getReceiverName2(), 35),
            trunc(d.getReceiverStreet(), 35),
            trunc(d.getReceiverStreet2(), 35),
            trunc(d.getReceiverCity(), 30),
            trunc(d.getReceiverZipcode(), 5),
            trunc(d.getReceiverCountryCode(), 2)
                + " - " + trunc(d.getReceiverCountryName(), 20)
        }) {
            if (notBlank(line)) {
                cv.beginText().moveText(MX, y).showText(line).endText();
                y -= 8f;
            }
        }

        // ─ r2c1: Phone (8pt) ──────────────────────────────────────────
        y -= 2f;
        cv.setFontAndSize(reg, F_INFO);
        if (notBlank(d.getReceiverPhone())) {
            cv.beginText().moveText(MX, y)
              .showText("Phone  " + d.getReceiverPhone()).endText();
            y -= 9f;
        }

        // ─ r2c1: Ref (8pt) ────────────────────────────────────────────
        cv.beginText().moveText(MX, y)
          .showText("Ref  " + nvl(d.getConsigneeCode())).endText();

        // ─ r2c2: Weight label + value (font 12 — spec §2.6.6) ─────────
        // FIX: was 8f, spec says 12pt for weight field
        if (notBlank(d.getWeightKg())) {
            cv.setFontAndSize(bold, F_WEIGHT);
            cv.beginText().moveText(X_73 + MX, y).showText("Weight").endText();
            y -= 14f;
            cv.beginText().moveText(X_73 + MX, y)
              .showText(d.getWeightKg() + " KG").endText();
        }
        y -= 10f;

        // ─ r2c1: Parcel rank — multi-piece bulking (font 12 — spec §2.6.6) ─
        // FIX: was missing entirely
        if (d.getParcelRank() != null && d.getTotalParcels() != null
                && d.getTotalParcels() > 1) {
            cv.setFontAndSize(bold, F_WEIGHT);
            String rankStr = d.getParcelRank() + "/" + d.getTotalParcels();
            cv.beginText().moveText(MX, y).showText(rankStr).endText();
            y -= 14f;
        }

        // ─ r2c1+r2c2: Consignment (8pt) ──────────────────────────────
        cv.setFontAndSize(reg, F_INFO);
        cv.beginText().moveText(MX, y)
          .showText("Consignement  " + nvl(d.getMasterParcelGeopostId())).endText();
        y -= 9f;

        // ─ r2c2: Phone again (col2 area) ─────────────────────────────
        if (notBlank(d.getReceiverPhone())) {
            cv.setFontAndSize(reg, F_INFO);
            cv.beginText().moveText(X_73 + MX, y).showText("Phone").endText();
            cv.beginText().moveText(X_73 + MX, y - 9f)
              .showText(d.getReceiverPhone()).endText();
        }

        // ─ r2c2+r2c3: CHRONOPOST + sender (rotated 90°) ───────────────
        drawSenderRotated(cv, reg, bold, d, top, bot);

        // ─ Vertical separators (Zone 2 only) ──────────────────────────
        vLine(cv, X_73, top, bot);
        vLine(cv, X_92, top, bot);

        // ─ Horizontal line at 58mm — partial only (0→73mm) ───────────
        // x=73 and x=92 lines CONTINUE into Zone 3 (no hline there)
        hLinePartial(cv, bot, 0, X_50);     // Zone 1/3 left boundary
        // x=73 vertical continues down — draw nothing between X_50 and LW
        // Full right edge still closes
        hLine(cv, bot);  // full line drawn (Zone 3 will redraw content under)

        return bot;
    }

    // ==================================================================
    // ZONE 3 — Parcel ID barcode + customs (28mm)
    // Columns: r3c1=50mm | r3c2=23mm | r3c3=19mm(merged) | r3c4=10mm(merged)
    // Vertical line x=50mm NEW here
    // Vertical lines x=73mm and x=92mm continue from Zone 2
    // ==================================================================
    private float drawZone3(PdfCanvas cv, Document doc,
                              PdfFont reg, PdfFont bold,
                              LabelData d, float top)
            throws IOException, WriterException {

        float bot = top - Z3H;
        float y   = top - 9f;

        // ─ r3c1: Date (8pt) ───────────────────────────────────────────
        LocalDateTime now = LocalDateTime.now();
        String dateStr = now.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
        cv.setFontAndSize(reg, F_INFO).setFillColor(BLACK);
        cv.beginText().moveText(MX, y).showText("Date : " + dateStr).endText();
        y -= 9f;

        // ─ r3c1: Parcel ID text above barcode (font 10) ───────────────
        cv.setFontAndSize(bold, F_BC_TEXT);
        cv.beginText().moveText(MX, y)
          .showText(formatParcelId(d.getParcelId())).endText();
        y -= 5f;

        // ─ r3c1: Parcel ID barcode (height=3mm per doc §2.6.1.1) ──────
        byte[] bc1 = barcodeGenerator.generateParcelIdBarcode(d.getParcelId());
        Image  bi1 = new Image(ImageDataFactory.create(bc1));
        bi1.setFixedPosition(MX, y - BC1H);
        bi1.scaleToFit(X_50 - MX * 2, BC1H);
        doc.add(bi1);
        y -= (BC1H + 4f);

        // ─ r3c2: MAR sort code (Bold 12pt, right of barcode) ──────────
        cv.setFontAndSize(bold, 12f);
        cv.beginText().moveText(X_50 + MX, y)
          .showText(nvl(d.getSortCode(), "MAR")).endText();
        y -= 14f;

        // ─ r3c1: VALEUR DOUANE (8pt) ──────────────────────────────────
        if (notBlank(d.getCustomsValue())) {
            cv.setFontAndSize(reg, F_INFO);
            cv.beginText().moveText(MX, y)
              .showText("VALEUR DOUANE " + d.getCustomsValue()
                      + " " + nvl(d.getCustomsCurrency())).endText();
            y -= 10f;
        }

        // ─ r3c1+r3c2: HY-DP / HY-NP (Bold 14pt) ─────────────────────
        cv.setFontAndSize(bold, F_CLEAR);
        String clearance = "HY-DP".equals(d.getCustomsClearanceCode())
                           ? "HY-DP" : "HY-NP";
        cv.beginText().moveText(MX, y).showText(clearance).endText();

        // ─ r3c3+r3c4: COM INT (Bold 14pt, right side) ─────────────────
        cv.beginText().moveText(X_73 + MX, y)
          .showText(nvl(d.getDeliveryServiceName(), "COM INT")).endText();

        // ─ Zone 3 vertical lines ───────────────────────────────────────
        vLine(cv, X_50, top, bot);   // new at Zone 3
        vLine(cv, X_73, top, bot);   // continues from Zone 2
        vLine(cv, X_92, top, bot);   // continues from Zone 2

        hLine(cv, bot);
        return bot;
    }

    // ==================================================================
    // ZONE 4 — Geopost Tracking ID + Routing sort (27mm)
    // Columns: r4c1=73mm | r4c2=29mm
    // Vertical line x=73mm continues from Zone 3
    // ==================================================================
    private float drawZone4(PdfCanvas cv, PdfFont reg, PdfFont bold,
                             LabelData d, float top) throws IOException {

        float bot = top - Z4H;

        // ─ Row A: Geopost Tracking ID ─────────────────────────────────
        // First 4 chars BOLD, rest normal, groups: 0407 1120 0000 10W
        float rowA = top - 9f;

        String tid = nvl(d.getGeopostTrackingId()).replace(" ", "");
        while (tid.length() < 15) tid += "0";
        tid = tid.substring(0, 15);

        // First 4 bold
        cv.setFontAndSize(bold, F_TRACK).setFillColor(BLACK);
        cv.beginText().moveText(MX, rowA).showText(tid.substring(0, 4)).endText();

        // "Track" label below
        cv.setFontAndSize(reg, F_FOOTER);
        cv.beginText().moveText(MX, rowA - 8f).showText("Track").endText();

        // Rest: groups [4:8] [8:12] [12:15]
        cv.setFontAndSize(reg, F_TRACK);
        String rest = " " + tid.substring(4, 8)
                    + " " + tid.substring(8, 12)
                    + " " + tid.substring(12);
        cv.beginText().moveText(MX + 28f, rowA).showText(rest).endText();

        // D-B2C right side in r4c2
        cv.setFontAndSize(reg, 9f);
        String svc = nvl(d.getGeopostServiceMention(), "D-B2C");
        float svcW = reg.getWidth(svc, 9f);
        cv.beginText().moveText(LW - MX - svcW, rowA).showText(svc).endText();
        cv.setFontAndSize(reg, F_FOOTER);
        cv.beginText().moveText(LW - MX - svcW, rowA - 8f)
          .showText("Service").endText();

        // ─ Row B: Parcel tag + Routing sort display ────────────────────
        // rowB: font-30 ascender = +24pt → must be < rowA-14 = top-23
        // rowB = top - 44f (safe: ascender reaches top-20, clears rowA)
        float rowB = top - 46f;

        // Parcel tag box (left of OrigSort)
        if (notBlank(d.getParcelTag())) {
            float bSz = 14f;
            cv.setStrokeColor(BLACK).setLineWidth(0.8f)
              .rectangle(MX, rowB - 4f, bSz, bSz).stroke();
            cv.setFontAndSize(bold, 8f).setFillColor(BLACK);
            cv.beginText().moveText(MX + 2f, rowB + 2f)
              .showText(d.getParcelTag()).endText();
        }

        // OrigSort — left, font 24 Bold (spec §8)
        cv.setFontAndSize(bold, F_ORIG).setFillColor(BLACK);
        cv.beginText().moveText(MX + 18f, rowB)
          .showText(nvl(d.getOrigineSort())).endText();

        // Center — centered, font 30 Bold (spec §8)
        cv.setFontAndSize(bold, F_CENTER);
        String center = nvl(d.getRoutingCenterDisplay(), "BE-0467");
        float  cW     = bold.getWidth(center, F_CENTER);
        cv.beginText().moveText((LW - cW) / 2f, rowB).showText(center).endText();

        // DistribSort — right, font 24 Bold (spec §8)
        cv.setFontAndSize(bold, F_DISTRIB);
        String distrib = nvl(d.getDistribSort());
        float  dW      = bold.getWidth(distrib, F_DISTRIB);
        cv.beginText().moveText(LW - MX - dW, rowB).showText(distrib).endText();

        // ─ Row C: Routing info SSS-CC-PPPPP (font 10) ─────────────────
        float rowC = top - 62f;
        cv.setFontAndSize(reg, F_ROUTE).setFillColor(BLACK);
        cv.beginText().moveText(MX, rowC)
          .showText(nvl(d.getGeopostRoutingInfo(), "327-BE-1000")).endText();

        // ─ Row D: Date/time VP CHREDI V25.01 (font 6) ─────────────────
        // FIX: hh:mm printing time added per spec §9
        float rowD = top - 73f;
        cv.setFontAndSize(reg, F_FOOTER);
        cv.beginText().moveText(MX, rowD)
          .showText(buildDateVersion(d)).endText();

        // ─ Zone 4 vertical line (x=73mm only, continues from Zone 3) ──
        vLine(cv, X_73, top, bot);

        hLine(cv, bot);
        return bot;
    }

    // ==================================================================
    // ZONE 5 — Routing barcode (31mm, full width)
    // ==================================================================
    private void drawZone5(PdfCanvas cv, Document doc,
                            PdfFont reg, LabelData d, float top)
            throws IOException, WriterException {

        float bot = top - Z5H;
        float bH  = BC2H;
        float bY  = top - 5f - bH;

        byte[] bc2 = barcodeGenerator
            .generateRoutingBarcode(d.getRoutingBarcodeForEncoding());
        Image img = new Image(ImageDataFactory.create(bc2));
        img.setFixedPosition(MX, bY);
        img.scaleToFit(LW - MX * 2, bH);
        doc.add(img);

        // Plain text: font 10, groups of 4, chars 2-28 + checksum
        String txt = nvl(d.getRoutingBarcodeForPrinting());
        cv.setFontAndSize(reg, F_ROUTE).setFillColor(BLACK);
        float tW = reg.getWidth(txt, F_ROUTE);
        cv.beginText().moveText((LW - tW) / 2f, bY - 12f)
          .showText(txt).endText();

        hLine(cv, bot);
    }

    // ==================================================================
    // SENDER — Rotated 90° in r2c2+r2c3 area (19+10=29mm wide)
    // CHRONOPOST Bold 12pt + sender details 6pt
    // ==================================================================
    private void drawSenderRotated(PdfCanvas cv, PdfFont reg, PdfFont bold,
                                    LabelData d, float zTop, float zBot)
            throws IOException {

        // Center X of (r2c2 + r2c3) = x=73 to x=102
        float cx = X_73 + (LW - X_73) / 2f;

        cv.saveState().concatMatrix(0, 1, -1, 0, cx + 8f, zBot + 6f);

        // CHRONOPOST — Bold 12pt (spec §3.ข)
        cv.setFontAndSize(bold, F_LOGO).setFillColor(BLACK);
        cv.beginText().moveText(0, 0).showText("CHRONOPOST").endText();

        // Sender fields — 6pt (spec §3.ค)
        cv.setFontAndSize(reg, F_SENDER);
        float tx = 18f;
        for (String line : new String[]{
            trunc(nvl(d.getSenderName()), 35),
            trunc(nvl(d.getSenderAddress()), 35),
            trunc(nvl(d.getSenderCity()), 30) + " " + nvl(d.getSenderCountry()),
            "Phone: " + nvl(d.getSenderPhone()),
            "Ref: "   + nvl(d.getSenderReference()),
            "COMPTE N. " + nvl(d.getSenderAccountNo())
        }) {
            if (notBlank(line)) {
                cv.beginText().moveText(tx, 0).showText(line).endText();
                tx += 7.5f;
            }
        }
        cv.restoreState();
    }

    // ==================================================================
    // HELPERS
    // ==================================================================

    /** Full-width horizontal line */
    private void hLine(PdfCanvas cv, float y) {
        cv.setStrokeColor(BLACK).setLineWidth(0.3f)
          .moveTo(0, y).lineTo(LW, y).stroke();
    }

    /** Partial horizontal line from x1 to x2 */
    private void hLinePartial(PdfCanvas cv, float y, float x1, float x2) {
        cv.setStrokeColor(BLACK).setLineWidth(0.3f)
          .moveTo(x1, y).lineTo(x2, y).stroke();
    }

    /** Vertical line from top to bot */
    private void vLine(PdfCanvas cv, float x, float top, float bot) {
        cv.setStrokeColor(BLACK).setLineWidth(0.3f)
          .moveTo(x, top).lineTo(x, bot).stroke();
    }

    /**
     * Format 13-char parcel ID for display above barcode
     * "HY712000001JF" → "HY 712 000 001 JF"
     */
    private String formatParcelId(String id) {
        if (id == null || id.length() < 13) return nvl(id);
        return id.substring(0, 2)  + " "
             + id.substring(2, 5)  + " "
             + id.substring(5, 8)  + " "
             + id.substring(8, 11) + " "
             + id.substring(11);
    }

    /**
     * Build date/version footer string per spec §9:
     * "dd/mm/yy hh:mm VP6 CHREDI-TT897 V25.01"
     * FIX: hh:mm printing time was missing
     */
    private String buildDateVersion(LabelData d) {
        LocalDateTime now = LocalDateTime.now();
        String date = now.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
        String time = now.format(DateTimeFormatter.ofPattern("HH:mm")); // FIX
        return date
            + " " + time
            + " VP" + nvl(d.getRoutingVersion(), "6")
            + " CHREDI-" + nvl(d.getSenderIdentification(), "TT897")
            + " V25.01";
    }

    /** Truncate string to max length, return empty if null */
    private String trunc(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }

    private String nvl(String s) { return s != null ? s : ""; }
    private String nvl(String s, String def) {
        return (s != null && !s.isBlank()) ? s : def;
    }
    private boolean notBlank(String s) {
        return s != null && !s.isBlank();
    }
}
