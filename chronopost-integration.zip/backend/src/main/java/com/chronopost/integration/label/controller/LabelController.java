package com.chronopost.integration.label.controller;

import com.chronopost.integration.common.dto.ApiResponse;
import com.chronopost.integration.label.dto.LabelRequest;
import com.chronopost.integration.label.dto.LabelResponse;
import com.chronopost.integration.label.service.LabelService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

/**
 * Label REST Controller
 *
 * Endpoints:
 *   POST /label/generate   → Generate label for a parcel
 *   GET  /label/preview/{parcelId}  → Get PDF for preview
 *   GET  /label/download/{parcelId} → Download PDF
 *   GET  /label/status/{shipmentId} → Check label status
 */
@RestController
@RequestMapping("/label")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class LabelController {

    private final LabelService labelService;

    /**
     * Generate label for a parcel
     * POST /label/generate
     */
    @PostMapping("/generate")
    public ResponseEntity<ApiResponse<LabelResponse>> generateLabel(
            @Valid @RequestBody LabelRequest request) {

        log.info("Label generation request for shipment: {}",
                 request.getShipmentId());

        try {
            LabelResponse response = labelService.generateLabel(request);
            return ResponseEntity.ok(
                ApiResponse.ok("Label generated successfully", response));

        } catch (IllegalArgumentException e) {
            log.warn("Label generation failed - bad request: {}",
                     e.getMessage());
            return ResponseEntity.badRequest().body(
                ApiResponse.error(e.getMessage()));

        } catch (Exception e) {
            log.error("Label generation failed: {}", e.getMessage(), e);
            return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ApiResponse.error(
                    "Label generation failed: " + e.getMessage()));
        }
    }

    /**
     * Preview label PDF in browser
     * GET /label/preview/{parcelId}
     */
    @GetMapping("/preview/{parcelId}")
    public ResponseEntity<byte[]> previewLabel(
            @PathVariable Long parcelId) {

        try {
            byte[] pdfBytes = labelService.getLabelPdf(parcelId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(
                ContentDisposition.inline()
                    .filename("label_" + parcelId + ".pdf")
                    .build());

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);

        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            log.error("Error fetching label PDF: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Download label PDF
     * GET /label/download/{parcelId}
     */
    @GetMapping("/download/{parcelId}")
    public ResponseEntity<byte[]> downloadLabel(
            @PathVariable Long parcelId) {

        try {
            byte[] pdfBytes = labelService.getLabelPdf(parcelId);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDisposition(
                ContentDisposition.attachment()
                    .filename("label_" + parcelId + ".pdf")
                    .build());

            return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);

        } catch (Exception e) {
            log.error("Error downloading label: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Check label status for all parcels in a shipment
     * GET /label/status/{shipmentId}
     */
    @GetMapping("/status/{shipmentId}")
    public ResponseEntity<ApiResponse<?>> getLabelStatus(
            @PathVariable Long shipmentId) {

        // Returns list of parcels with their label status
        // Implementation in service layer
        return ResponseEntity.ok(
            ApiResponse.ok("Label status retrieved", null));
    }
}
