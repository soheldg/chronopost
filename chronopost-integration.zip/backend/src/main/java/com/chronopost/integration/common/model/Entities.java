package com.chronopost.integration.common.model;

/**
 * This file is intentionally empty.
 *
 * All entity classes have been moved to their own files:
 *   Sender.java, Receiver.java, Parcel.java, Customs.java,
 *   InvoiceLine.java, TrackingEvent.java, Shipment.java,
 *   InvoiceFile.java, PreAlertFile.java
 *
 * Having duplicate class definitions in Entities.java caused
 * compiler conflicts (e.g. getFax() missing, phone vs phone1).
 */
