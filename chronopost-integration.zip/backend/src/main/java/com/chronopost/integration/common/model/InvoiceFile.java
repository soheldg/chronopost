package com.chronopost.integration.common.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name="CHR_INVOICE_FILES",schema="CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class InvoiceFile {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="chr_seq")
    @SequenceGenerator(name="chr_seq",sequenceName="CHR_SEQ",allocationSize=1)
    private Long id;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="SHIPMENT_ID",nullable=false)
    private Shipment shipment;
    @Column(name="FILE_NAME",nullable=false,length=255) private String fileName;
    @Column(name="FILE_PATH",length=255) private String filePath;
    @Column(name="DIRECTION",length=3) @Builder.Default private String direction="OUT";
    @Column(name="FTP_STATUS",length=20) @Builder.Default private String ftpStatus="PENDING";
    @Column(name="ERROR_MSG",length=500) private String errorMsg;
    @Column(name="UPLOADED_AT") private LocalDateTime uploadedAt;
    @Column(name="CREATED_AT") @Builder.Default private LocalDateTime createdAt=LocalDateTime.now();
}
