package com.chronopost.integration.invoice.generator;

import com.chronopost.integration.common.model.*;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Commercial Invoice PDF Generator
 * Generates a professional A4 invoice from shipment data.
 * Output is ≥300 DPI (iText vector PDF — no DPI limitation).
 *
 * Used for Chronopost customs clearance (Doc 4 requirement).
 */
@Component
@Slf4j
public class CommercialInvoicePdfGenerator {

    private static final DeviceRgb BLUE_DARK  = new DeviceRgb(0,  51,  102);
    private static final DeviceRgb BLUE_LIGHT = new DeviceRgb(230, 240, 255);
    private static final DeviceRgb GRAY_LIGHT = new DeviceRgb(245, 245, 245);
    private static final DeviceRgb GRAY_MID   = new DeviceRgb(200, 200, 200);
    private static final DateTimeFormatter DATE_FMT =
        DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public byte[] generate(Shipment shipment) {
        log.info("Generating commercial invoice PDF for shipment: {}", shipment.getId());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        try {
            PdfWriter  writer   = new PdfWriter(baos);
            PdfDocument pdfDoc  = new PdfDocument(writer);
            Document    doc     = new Document(pdfDoc, PageSize.A4);
            doc.setMargins(36, 36, 36, 36);

            PdfFont regular = PdfFontFactory.createFont(
                com.itextpdf.io.font.constants.StandardFonts.HELVETICA);
            PdfFont bold    = PdfFontFactory.createFont(
                com.itextpdf.io.font.constants.StandardFonts.HELVETICA_BOLD);

            Sender     sender   = shipment.getSender();
            Receiver   receiver = shipment.getReceiver();
            Customs    customs  = shipment.getCustoms();
            List<InvoiceLine> lines = shipment.getInvoiceLines();

            // ── 1. Header bar ─────────────────────────────────────────
            Table header = new Table(UnitValue.createPercentArray(new float[]{60, 40}))
                .useAllAvailableWidth()
                .setMarginBottom(16);

            // Left: Company name
            Cell titleCell = new Cell().setBorder(Border.NO_BORDER)
                .add(new Paragraph("COMMERCIAL INVOICE")
                    .setFont(bold).setFontSize(18).setFontColor(BLUE_DARK))
                .add(new Paragraph(safe(sender != null ? sender.getCompanyName() : ""))
                    .setFont(bold).setFontSize(11).setFontColor(ColorConstants.BLACK))
                .add(new Paragraph(safe(sender != null ? sender.getStreet() : ""))
                    .setFont(regular).setFontSize(9).setFontColor(ColorConstants.DARK_GRAY))
                .add(new Paragraph(safe(sender != null
                        ? sender.getZipcode() + " " + sender.getTown() + ", " + sender.getCountryCode()
                        : ""))
                    .setFont(regular).setFontSize(9));
            header.addCell(titleCell);

            // Right: Invoice meta
            String invoiceNo   = "INV-" + shipment.getMpsId();
            String invoiceDate = LocalDate.now().format(DATE_FMT);
            Cell metaCell = new Cell().setBorder(Border.NO_BORDER)
                .setTextAlignment(TextAlignment.RIGHT)
                .add(new Paragraph("Invoice No: " + invoiceNo)
                    .setFont(bold).setFontSize(10))
                .add(new Paragraph("Date: " + invoiceDate)
                    .setFont(regular).setFontSize(9))
                .add(new Paragraph("Shipment: " + safe(shipment.getMpsId()))
                    .setFont(regular).setFontSize(9))
                .add(new Paragraph("Transport: " + lhLabel(shipment.getLinehaul()))
                    .setFont(regular).setFontSize(9));
            header.addCell(metaCell);
            doc.add(header);

            // Divider
            doc.add(new LineSeparator(new com.itextpdf.layout.element.IBlockElement() {
                public <T1> void setProperty(int p, T1 v) {}
                public <T> T getProperty(int p) { return null; }
                public <T> T getOwnProperty(int p) { return null; }
                public <T> T getDefaultProperty(int p) { return null; }
                public void deleteOwnProperty(int p) {}
                public boolean hasProperty(int p) { return false; }
                public boolean hasOwnProperty(int p) { return false; }
            }.getClass().isInterface()
                ? new com.itextpdf.layout.element.Paragraph() : null));

            // Blue divider line
            doc.add(new Table(1).useAllAvailableWidth()
                .addCell(new Cell().setHeight(3).setBackgroundColor(BLUE_DARK)
                    .setBorder(Border.NO_BORDER))
                .setMarginBottom(12));

            // ── 2. Seller / Buyer addresses ───────────────────────────
            Table parties = new Table(UnitValue.createPercentArray(new float[]{50, 50}))
                .useAllAvailableWidth()
                .setMarginBottom(16);

            parties.addCell(buildAddressCell("SELLER / EXPORTER", sender, bold, regular));
            parties.addCell(buildBuyerCell("BUYER / CONSIGNEE", receiver, bold, regular));
            doc.add(parties);

            // ── 3. Customs info row ───────────────────────────────────
            Table customsRow = new Table(UnitValue.createPercentArray(new float[]{25,25,25,25}))
                .useAllAvailableWidth()
                .setMarginBottom(16);

            String reason = "01".equals(customs != null ? customs.getReasonForExport() : "01")
                ? "Sale" : "02".equals(customs != null ? customs.getReasonForExport() : "") ? "Return" : "Gift";
            String incoterms = customs != null ? safe(customs.getIncoterms()) : "07";
            String clearance = customs != null ? safe(customs.getClearanceStatus()) : "N";
            String currency  = customs != null && customs.getCurrency() != null
                ? customs.getCurrency() : "EUR";

            addInfoCell(customsRow, "Reason for Export", reason, bold, regular);
            addInfoCell(customsRow, "Incoterms", incotermsLabel(incoterms), bold, regular);
            addInfoCell(customsRow, "Clearance", clearance, bold, regular);
            addInfoCell(customsRow, "Currency", currency, bold, regular);
            doc.add(customsRow);

            // ── 4. Invoice lines table ────────────────────────────────
            float[] colWidths = {5, 28, 8, 10, 10, 10, 10, 10, 9};
            Table lineTable = new Table(UnitValue.createPercentArray(colWidths))
                .useAllAvailableWidth()
                .setMarginBottom(12);

            // Table header row
            String[] headers = {"#", "Description", "Qty", "Unit Price",
                                 "Total", "Net Wt(g)", "Gross Wt(g)", "HS Code", "Origin"};
            for (String h : headers) {
                lineTable.addHeaderCell(new Cell()
                    .setBackgroundColor(BLUE_DARK)
                    .setBorder(Border.NO_BORDER)
                    .add(new Paragraph(h)
                        .setFont(bold).setFontSize(8)
                        .setFontColor(ColorConstants.WHITE)
                        .setTextAlignment(TextAlignment.CENTER)));
            }

            // Table rows
            double grandTotal    = 0;
            long   totalNetWt    = 0;
            long   totalGrossWt  = 0;
            boolean altRow       = false;

            if (lines != null) {
                for (InvoiceLine line : lines) {
                    DeviceRgb bg = altRow ? GRAY_LIGHT : null;
                    altRow = !altRow;

                    double unitPrice = line.getAmount() != null && line.getQuantity() != null
                        && line.getQuantity() > 0
                        ? line.getAmount() / line.getQuantity() : 0;
                    double total = line.getAmount() != null ? line.getAmount() : 0;
                    grandTotal  += total;
                    if (line.getNetWeight()   != null) totalNetWt   += line.getNetWeight();
                    if (line.getGrossWeight() != null) totalGrossWt += line.getGrossWeight();

                    addDataCell(lineTable, String.valueOf(line.getPosition() != null ? line.getPosition() : 1),
                        regular, 8, TextAlignment.CENTER, bg);
                    addDataCell(lineTable, safe(line.getContent()), regular, 8, TextAlignment.LEFT, bg);
                    addDataCell(lineTable, String.valueOf(line.getQuantity() != null ? line.getQuantity() : 1),
                        regular, 8, TextAlignment.CENTER, bg);
                    addDataCell(lineTable, String.format("%.2f", unitPrice),
                        regular, 8, TextAlignment.RIGHT, bg);
                    addDataCell(lineTable, String.format("%.2f", total),
                        bold, 8, TextAlignment.RIGHT, bg);
                    addDataCell(lineTable, line.getNetWeight() != null ? String.valueOf(line.getNetWeight()) : "—",
                        regular, 8, TextAlignment.RIGHT, bg);
                    addDataCell(lineTable, line.getGrossWeight() != null ? String.valueOf(line.getGrossWeight()) : "—",
                        regular, 8, TextAlignment.RIGHT, bg);
                    addDataCell(lineTable, safe(line.getHsCodeSend()), regular, 8, TextAlignment.CENTER, bg);
                    addDataCell(lineTable, safe(line.getCountryOrigin()),
                        regular, 8, TextAlignment.CENTER, bg);
                }
            }

            // Total row
            lineTable.addCell(new Cell(1, 4).setBorder(Border.NO_BORDER)
                .setBackgroundColor(BLUE_LIGHT)
                .add(new Paragraph("TOTAL")
                    .setFont(bold).setFontSize(9).setTextAlignment(TextAlignment.RIGHT)));
            addDataCell(lineTable, String.format("%.2f %s", grandTotal, currency),
                bold, 9, TextAlignment.RIGHT, new DeviceRgb(230, 240, 255));
            addDataCell(lineTable, String.valueOf(totalNetWt),
                bold, 8, TextAlignment.RIGHT, new DeviceRgb(230, 240, 255));
            addDataCell(lineTable, String.valueOf(totalGrossWt),
                bold, 8, TextAlignment.RIGHT, new DeviceRgb(230, 240, 255));
            lineTable.addCell(new Cell(1, 2).setBorder(Border.NO_BORDER)
                .setBackgroundColor(BLUE_LIGHT));

            doc.add(lineTable);

            // ── 5. Total box ──────────────────────────────────────────
            Table totalBox = new Table(UnitValue.createPercentArray(new float[]{70, 30}))
                .useAllAvailableWidth().setMarginBottom(20);
            totalBox.addCell(new Cell().setBorder(Border.NO_BORDER));
            totalBox.addCell(new Cell()
                .setBackgroundColor(BLUE_DARK)
                .setBorderRadius(new com.itextpdf.layout.properties.BorderRadius(4))
                .add(new Paragraph(String.format("INVOICE TOTAL: %.2f %s", grandTotal, currency))
                    .setFont(bold).setFontSize(11)
                    .setFontColor(ColorConstants.WHITE)
                    .setTextAlignment(TextAlignment.CENTER)));
            doc.add(totalBox);

            // ── 6. Declaration + Signature ────────────────────────────
            doc.add(new Paragraph(
                "I hereby certify that the information on this invoice is true and correct " +
                "and that the contents of this shipment are as stated above.")
                .setFont(regular).setFontSize(8)
                .setFontColor(ColorConstants.DARK_GRAY)
                .setMarginBottom(20));

            Table sigRow = new Table(UnitValue.createPercentArray(new float[]{50, 50}))
                .useAllAvailableWidth();
            sigRow.addCell(new Cell().setBorder(Border.NO_BORDER)
                .add(new Paragraph("Authorized Signature:").setFont(bold).setFontSize(9))
                .add(new Paragraph("\n\n_________________________________")
                    .setFont(regular).setFontSize(9))
                .add(new Paragraph(safe(sender != null ? sender.getCompanyName() : ""))
                    .setFont(regular).setFontSize(8).setFontColor(ColorConstants.DARK_GRAY))
                .add(new Paragraph(LocalDate.now().format(DATE_FMT))
                    .setFont(regular).setFontSize(8)));
            sigRow.addCell(new Cell().setBorder(Border.NO_BORDER)
                .add(new Paragraph("Company Stamp:").setFont(bold).setFontSize(9))
                .add(new Paragraph("\n\n\n").setFont(regular).setFontSize(9)));
            doc.add(sigRow);

            // ── 7. Footer ─────────────────────────────────────────────
            doc.add(new Table(1).useAllAvailableWidth()
                .addCell(new Cell().setHeight(2).setBackgroundColor(BLUE_DARK)
                    .setBorder(Border.NO_BORDER))
                .setMarginTop(10));
            doc.add(new Paragraph(
                "Generated by Chronopost Integration System · " +
                "Shipment ID: " + shipment.getId() + " · MPS ID: " + safe(shipment.getMpsId()))
                .setFont(regular).setFontSize(7)
                .setFontColor(ColorConstants.LIGHT_GRAY)
                .setTextAlignment(TextAlignment.CENTER));

            doc.close();
            log.info("Invoice PDF generated: {} bytes", baos.size());

        } catch (Exception e) {
            log.error("Invoice PDF generation failed: {}", e.getMessage(), e);
            throw new RuntimeException("Invoice PDF generation failed: " + e.getMessage(), e);
        }

        return baos.toByteArray();
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private Cell buildAddressCell(String title, Sender s, PdfFont bold, PdfFont regular) {
        Cell cell = new Cell()
            .setBackgroundColor(GRAY_LIGHT)
            .setBorder(new SolidBorder(GRAY_MID, 1))
            .setPadding(8);
        cell.add(new Paragraph(title).setFont(bold).setFontSize(8)
            .setFontColor(BLUE_DARK));
        if (s != null) {
            if (s.getCompanyName() != null)
                cell.add(new Paragraph(s.getCompanyName()).setFont(bold).setFontSize(10));
            if (s.getName1() != null)
                cell.add(new Paragraph(s.getName1()).setFont(regular).setFontSize(9));
            cell.add(new Paragraph(safe(s.getStreet())).setFont(regular).setFontSize(9));
            cell.add(new Paragraph(s.getZipcode() + " " + s.getTown()).setFont(regular).setFontSize(9));
            cell.add(new Paragraph(safe(s.getCountryCode())).setFont(bold).setFontSize(9));
            if (s.getPhone() != null)
                cell.add(new Paragraph("Tel: " + s.getPhone()).setFont(regular).setFontSize(8)
                    .setFontColor(ColorConstants.DARK_GRAY));
            if (s.getEmail() != null)
                cell.add(new Paragraph(s.getEmail()).setFont(regular).setFontSize(8)
                    .setFontColor(ColorConstants.DARK_GRAY));
            if (s.getVatNo() != null)
                cell.add(new Paragraph("VAT: " + s.getVatNo()).setFont(regular).setFontSize(8)
                    .setFontColor(ColorConstants.DARK_GRAY));
        }
        return cell;
    }

    private Cell buildBuyerCell(String title, Receiver r, PdfFont bold, PdfFont regular) {
        Cell cell = new Cell()
            .setBackgroundColor(GRAY_LIGHT)
            .setBorder(new SolidBorder(GRAY_MID, 1))
            .setPadding(8);
        cell.add(new Paragraph(title).setFont(bold).setFontSize(8).setFontColor(BLUE_DARK));
        if (r != null) {
            if (r.getCompanyName() != null)
                cell.add(new Paragraph(r.getCompanyName()).setFont(bold).setFontSize(10));
            if (r.getName1() != null)
                cell.add(new Paragraph(r.getName1()).setFont(regular).setFontSize(9));
            cell.add(new Paragraph(safe(r.getStreet())).setFont(regular).setFontSize(9));
            if (r.getAdd2() != null)
                cell.add(new Paragraph(r.getAdd2()).setFont(regular).setFontSize(9));
            cell.add(new Paragraph(r.getZipcode() + " " + r.getTown()).setFont(regular).setFontSize(9));
            cell.add(new Paragraph(safe(r.getCountryCode())).setFont(bold).setFontSize(9));
            if (r.getPhone1() != null)
                cell.add(new Paragraph("Tel: " + r.getPhone1()).setFont(regular).setFontSize(8)
                    .setFontColor(ColorConstants.DARK_GRAY));
            if (r.getEmail() != null)
                cell.add(new Paragraph(r.getEmail()).setFont(regular).setFontSize(8)
                    .setFontColor(ColorConstants.DARK_GRAY));
            if (r.getVatNo() != null)
                cell.add(new Paragraph("VAT: " + r.getVatNo()).setFont(regular).setFontSize(8)
                    .setFontColor(ColorConstants.DARK_GRAY));
        }
        return cell;
    }

    private void addInfoCell(Table t, String label, String value, PdfFont bold, PdfFont regular) {
        t.addCell(new Cell()
            .setBorder(new SolidBorder(GRAY_MID, 1))
            .setBackgroundColor(GRAY_LIGHT)
            .setPadding(6)
            .add(new Paragraph(label).setFont(bold).setFontSize(7).setFontColor(BLUE_DARK))
            .add(new Paragraph(safe(value)).setFont(bold).setFontSize(9)));
    }

    private void addDataCell(Table t, String text, PdfFont font, float size,
                              TextAlignment align, DeviceRgb bg) {
        Cell c = new Cell()
            .setBorder(new SolidBorder(GRAY_MID, 0.5f))
            .setPadding(4)
            .add(new Paragraph(safe(text)).setFont(font).setFontSize(size)
                .setTextAlignment(align));
        if (bg != null) c.setBackgroundColor(bg);
        t.addCell(c);
    }

    private String safe(String s)  { return s != null ? s : ""; }

    private String lhLabel(String lh) {
        if ("AI".equals(lh)) return "Air Freight";
        if ("RO".equals(lh)) return "Road";
        if ("SE".equals(lh)) return "Sea Freight";
        return safe(lh);
    }

    private String incotermsLabel(String code) {
        return switch (safe(code)) {
            case "01", "06" -> "DAP";
            case "02", "03" -> "DDP";
            case "05"       -> "EXW";
            case "07"       -> "DAP";
            default         -> safe(code);
        };
    }
}
