package com.chronopost.integration.admin;

import com.chronopost.integration.common.dto.ApiResponse;
import com.chronopost.integration.product.Product;
import com.chronopost.integration.product.ProductRepository;
import com.chronopost.integration.routing.RoutingService;
import com.chronopost.integration.routing.RoutingService.RoutingInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Admin Controller — Reference Data endpoints
 *
 * GET /admin/products                                  → CHR_PRODUCTS all rows
 * GET /admin/products?natInter=I&isPrimary=P           → filtered
 * GET /admin/routing/lookup?country=BE&zip=1000        → routing lookup
 * GET /admin/routing/lookup?country=GB&zip=SW1A&service=DPD
 */
@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {

    private final ProductRepository productRepo;
    private final RoutingService    routingService;

    // ── GET /admin/products ───────────────────────────────────────────────
    @GetMapping("/products")
    public ResponseEntity<ApiResponse<List<Product>>> listProducts(
            @RequestParam(required = false) String natInter,
            @RequestParam(required = false) String isPrimary) {
        try {
            List<Product> all = productRepo.findAll();
            if (natInter != null && !natInter.isBlank()) {
                final String n = natInter.toUpperCase();
                all = all.stream().filter(p -> n.equals(p.getNatInter())).toList();
            }
            if (isPrimary != null && !isPrimary.isBlank()) {
                final String p2 = isPrimary.toUpperCase();
                all = all.stream().filter(p -> p2.equals(p.getIsPrimary())).toList();
            }
            log.debug("Admin products: {} rows", all.size());
            return ResponseEntity.ok(ApiResponse.ok(all));
        } catch (Exception e) {
            log.error("Admin products error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage()));
        }
    }

    // ── GET /admin/routing/lookup ─────────────────────────────────────────
    @GetMapping("/routing/lookup")
    public ResponseEntity<ApiResponse<Map<String, Object>>> routingLookup(
            @RequestParam String country,
            @RequestParam String zip,
            @RequestParam(defaultValue = "DPD") String service) {
        try {
            RoutingInfo info = routingService.resolve(service, country, zip);
            Map<String, Object> result = Map.of(
                "country",        country.toUpperCase(),
                "zip",            zip,
                "serviceType",    service,
                "origSort",       info.getOrigSort(),
                "agencyCode",     info.getAgencyCode(),
                "distribSort",    info.getDistribSort(),
                "numCountryCode", info.getNumCountryCode(),
                "normalizedZip",  info.getNormalizedZip()
            );
            log.debug("Routing lookup {}/{} → origSort={} numCC={}",
                      country, zip, info.getOrigSort(), info.getNumCountryCode());
            return ResponseEntity.ok(ApiResponse.ok(result));
        } catch (Exception e) {
            log.error("Routing lookup error: {}", e.getMessage(), e);
            return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage()));
        }
    }
}
