package com.chronopost.integration.invoice.dto;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class InvoiceUploadResponse {
    private Long invoiceFileId, shipmentId;
    private String fileName, ftpStatus, uploadedAt;
    private long fileSize;
    private boolean success;
    private List<String> errors;
}
