package com.chronopost.integration.common.repository;
import com.chronopost.integration.common.model.Shipment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public interface ShipmentRepository extends JpaRepository<Shipment,Long> {
    Optional<Shipment> findByMpsId(String mpsId);
    List<Shipment> findByStatus(Shipment.ShipmentStatus status);
    @Query("SELECT s FROM Shipment s LEFT JOIN FETCH s.sender LEFT JOIN FETCH s.receiver WHERE s.id=:id")
    Optional<Shipment> findByIdWithDetails(Long id);

    /** Full detail fetch: sender + receiver + parcels + customs + invoiceLines */
    @Query("""
        SELECT DISTINCT s FROM Shipment s
        LEFT JOIN FETCH s.sender
        LEFT JOIN FETCH s.receiver
        LEFT JOIN FETCH s.parcels
        LEFT JOIN FETCH s.customs
        LEFT JOIN FETCH s.invoiceLines
        WHERE s.id = :id
        """)
    Optional<Shipment> findByIdWithAllDetails(Long id);
}
