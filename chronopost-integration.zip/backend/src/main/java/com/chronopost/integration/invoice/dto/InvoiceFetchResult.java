package com.chronopost.integration.invoice.dto;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class InvoiceFetchResult {
    private int totalFound, downloaded, failed;
    private List<String> fileNames;
    private String fetchedAt;
}
