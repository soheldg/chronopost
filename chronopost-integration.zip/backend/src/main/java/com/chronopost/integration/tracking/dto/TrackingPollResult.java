package com.chronopost.integration.tracking.dto;
import lombok.*;
import java.util.List;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TrackingPollResult {
    private int filesFound, filesProcessed, filesFailed, totalEventsProcessed;
    private List<String> processedFileNames;
    private String polledAt;
}
