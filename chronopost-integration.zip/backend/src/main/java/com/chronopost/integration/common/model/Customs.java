package com.chronopost.integration.common.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
@Entity @Table(name="CHR_CUSTOMS",schema="CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Customs {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="chr_seq")
    @SequenceGenerator(name="chr_seq",sequenceName="CHR_SEQ",allocationSize=1)
    private Long id;
    @OneToOne(fetch=FetchType.LAZY) @JoinColumn(name="SHIPMENT_ID",nullable=false)
    private Shipment shipment;
    @Column(name="PARCEL_TYPE",length=1) private String parcelType;
    @Column(name="CUSTOMS_AMOUNT") private Double customsAmount;
    @Column(name="CURRENCY",length=3) private String currency;
    @Column(name="CUSTOMS_AMOUNT_EX") private Double customsAmountEx;
    @Column(name="CURRENCY_EX",length=3) private String currencyEx;
    @Column(name="INCOTERMS",length=2) private String incoterms;
    @Column(name="CLEARANCE_STATUS",length=1) private String clearanceStatus;
    @Column(name="HIGH_LOW_VALUE",length=1) private String highLowValue;
    @Column(name="PREALERT_STATUS",length=3) private String prealertStatus;
    @Column(name="INVOICE_NO",length=20) private String invoiceNo;
    @Column(name="INVOICE_DATE") private LocalDate invoiceDate;
    @Column(name="REASON_FOR_EXPORT",length=2) @Builder.Default private String reasonForExport="01";
    @Column(name="NUMBER_OF_ARTICLE") private Integer numberOfArticle;
    @Column(name="DEST_COUNTRY_REG",length=15) private String destCountryReg;
    @Column(name="TRANSPORT_COST") private Double transportCost;
    @Column(name="TRANSPORT_COST_CUR",length=3) private String transportCostCur;
    @Column(name="C_NAME1",length=35) private String cName1;
    @Column(name="C_STREET",length=35) private String cStreet;
    @Column(name="C_COUNTRY_CODE",length=3) private String cCountryCode;
    @Column(name="C_ZIPCODE",length=9) private String cZipcode;
    @Column(name="C_TOWN",length=35) private String cTown;
    @Column(name="C_CONTACT",length=35) private String cContact;
    @Column(name="C_PHONE",length=30) private String cPhone;
    @Column(name="C_EMAIL",length=100) private String cEmail;
    @Column(name="C_VAT_NO",length=20) private String cVatNo;
    @Column(name="C_EORI",length=20) private String cEori;
    @Column(name="SI_NAME1",length=35) private String siName1;
    @Column(name="SI_NAME2",length=35) private String siName2;
    @Column(name="SI_STREET",length=35) private String siStreet;
    @Column(name="SI_ZIPCODE",length=9) private String siZipcode;
    @Column(name="SI_TOWN",length=35) private String siTown;
    @Column(name="SI_COUNTRY_CODE",length=3) private String siCountryCode;
    @Column(name="SI_EORI",length=20) private String siEori;
}
