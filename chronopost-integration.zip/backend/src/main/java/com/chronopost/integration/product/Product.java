package com.chronopost.integration.product;

import jakarta.persistence.*;
import lombok.*;

/**
 * CHR_PRODUCTS entity — loaded from PRODUIT.CSV
 *
 * App looks up this table to resolve:
 *   - productSuffix  (col 15 SUFFIXE)  → Parcel ID suffix e.g. "JF"
 *   - deliveryServiceName (col 17 LIBEL25) → label text e.g. "COM INT"
 *   - serviceText    (col 5)            → label mention e.g. "D-B2C"
 *
 * Key for lookup: CODE_GEOPOST (service code 327/328)
 */
@Entity
@Table(name = "CHR_PRODUCTS", schema = "CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "chr_seq")
    @SequenceGenerator(name = "chr_seq", sequenceName = "CHR_SEQ", allocationSize = 1)
    private Long id;

    @Column(name = "CODE_GEOPOST", nullable = false)
    private Integer codeGeopost;          // Col 1: 327/328

    @Column(name = "PLTRI", length = 4)
    private String pltri;                 // Col 2: DPD.

    @Column(name = "SERVICE_MARK", length = 2)
    private String serviceMark;           // Col 3: X=small, E=express

    @Column(name = "FAMILLE_GEO", length = 4)
    private String familleGeo;            // Col 4

    @Column(name = "SERVICE_TEXT", length = 20)
    private String serviceText;           // Col 5: D-B2C

    @Column(name = "DESCRIPTION", length = 35)
    private String description;           // Col 6

    @Column(name = "PRODUIT_CHR", length = 1)
    private String produitChr;            // Col 7: O/S/N/T

    @Column(name = "NAT_INTER", length = 1)
    private String natInter;              // Col 8: N=national, I=international

    @Column(name = "JOUR", length = 2)
    private String jour;                  // Col 9: SE/VE/DI

    @Column(name = "SUFFIXE", length = 4)
    private String suffixe;               // Col 15: JF — used in Parcel ID

    @Column(name = "CODE_FACT", length = 4)
    private String codeFact;              // Col 16: billing code

    @Column(name = "LIBEL25", length = 25)
    private String libel25;               // Col 17: COM INT — label service name

    @Column(name = "CODE_EXP", length = 4)
    private String codeExp;               // Col 18: export code

    @Column(name = "LIBELLE_FA", length = 35)
    private String libelleFa;             // Col 20: full service label

    @Column(name = "IS_PRIMARY", length = 1)
    private String isPrimary;             // P=Primary, O=Other

    @Column(name = "ACTIVE")
    @Builder.Default
    private Integer active = 1;

    // ── Convenience helpers ────────────────────────────────────────────

    /** Returns clean suffix without trailing dots/spaces */
    public String getCleanSuffix() {
        return suffixe != null ? suffixe.trim().replace(".", "") : "JF";
    }

    /** Returns clean service name e.g. "COM INT" */
    public String getCleanLibel25() {
        return libel25 != null ? libel25.trim().replace(".", "") : "COM INT";
    }

    /** Returns clean service text e.g. "D-B2C" */
    public String getCleanServiceText() {
        return serviceText != null ? serviceText.trim().replace(".", "") : "D-B2C";
    }

    /** True if this is the small parcel variant (service_mark = X) */
    public boolean isSmall() {
        return "X".equals(serviceMark);
    }
}
