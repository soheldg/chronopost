package com.chronopost.integration.common.repository;
import com.chronopost.integration.common.model.PreAlertFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface PreAlertFileRepository extends JpaRepository<PreAlertFile,Long> {
    List<PreAlertFile> findByFtpStatus(String ftpStatus);
}
