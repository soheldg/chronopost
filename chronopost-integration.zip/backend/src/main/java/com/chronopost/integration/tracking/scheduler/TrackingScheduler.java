package com.chronopost.integration.tracking.scheduler;
import com.chronopost.integration.tracking.service.TrackingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
@Component @Slf4j @RequiredArgsConstructor
public class TrackingScheduler {
    private final TrackingService trackingService;
    @Scheduled(cron="0 0/30 * * * *")
    public void pollTrackingFiles() {
        log.info("Scheduled tracking poll started");
        try { trackingService.pollAndProcess(); }
        catch(Exception e) { log.error("Tracking poll failed: {}", e.getMessage(), e); }
    }
}
