package com.chronopost.integration.product;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Looks up Chronopost product info from CHR_PRODUCTS table.
 *
 * This replaces hardcoded values like "JF", "COM INT", "D-B2C"
 * in LabelService with dynamic DB lookups.
 *
 * Weight rule:
 *   ≤ 3000g → serviceCode 328 (SMALL, service_mark=X)
 *   > 3000g → serviceCode 327 (NORMAL)
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository repo;

    // Fallback defaults if DB lookup fails
    private static final int    DEFAULT_CODE_NORMAL = 327;
    private static final int    DEFAULT_CODE_SMALL  = 328;
    private static final String DEFAULT_SUFFIX      = "JF";
    private static final String DEFAULT_SERVICE_NAME = "COM INT";
    private static final String DEFAULT_SERVICE_TEXT = "D-B2C";
    private static final long   SMALL_MAX_GRAMS     = 3000L;

    /**
     * Resolve product info for a parcel weight (grams).
     * Automatically selects 327 (normal) or 328 (small).
     *
     * @param weightGrams parcel declared weight in grams
     * @return ProductInfo with suffix, serviceName, serviceText, serviceCode
     */
    public ProductInfo resolveByWeight(Long weightGrams) {
        int code = (weightGrams != null && weightGrams <= SMALL_MAX_GRAMS)
                   ? DEFAULT_CODE_SMALL    // 328 ≤3kg
                   : DEFAULT_CODE_NORMAL;  // 327 >3kg
        return resolveByCode(code);
    }

    /**
     * Resolve product info for a specific service code.
     * Falls back to defaults if not found in DB.
     */
    public ProductInfo resolveByCode(int serviceCode) {
        return repo.findFirstByCodeGeopostAndIsPrimary(serviceCode, "P")
            .map(p -> {
                log.debug("Product resolved: code={} suffix={} name={}",
                          serviceCode, p.getCleanSuffix(), p.getCleanLibel25());
                return ProductInfo.builder()
                    .serviceCode(serviceCode)
                    .productSuffix(p.getCleanSuffix())
                    .deliveryServiceName(p.getCleanLibel25())
                    .geopostServiceMention(p.getCleanServiceText())
                    .isSmall(p.isSmall())
                    .build();
            })
            .orElseGet(() -> {
                log.warn("Product not found in DB for code={}, using defaults", serviceCode);
                return defaultInfo(serviceCode);
            });
    }

    private ProductInfo defaultInfo(int code) {
        return ProductInfo.builder()
            .serviceCode(code)
            .productSuffix(DEFAULT_SUFFIX)
            .deliveryServiceName(DEFAULT_SERVICE_NAME)
            .geopostServiceMention(DEFAULT_SERVICE_TEXT)
            .isSmall(code == DEFAULT_CODE_SMALL)
            .build();
    }

    @lombok.Data @lombok.Builder
    public static class ProductInfo {
        private int     serviceCode;           // 327 or 328
        private String  productSuffix;         // "JF"
        private String  deliveryServiceName;   // "COM INT"
        private String  geopostServiceMention; // "D-B2C"
        private boolean isSmall;               // true if code=328
    }
}
