package com.chronopost.integration.common.model;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name="CHR_SENDERS",schema="CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Sender {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="chr_seq")
    @SequenceGenerator(name="chr_seq",sequenceName="CHR_SEQ",allocationSize=1)
    private Long id;
    @OneToOne(fetch=FetchType.LAZY) @JoinColumn(name="SHIPMENT_ID",nullable=false)
    private Shipment shipment;

    // Core fields (in DB)
    @Column(name="ACCOUNT_NO",    nullable=false, length=20) private String accountNo;
    @Column(name="SUB_ACCOUNT_NO",length=5)   private String subAccountNo;
    @Column(name="COMPANY_NAME",  length=35)  private String companyName;
    @Column(name="NAME1",         length=35)  private String name1;
    @Column(name="NAME2",         length=35)  private String name2;
    @Column(name="STREET",   nullable=false, length=35) private String street;
    @Column(name="PROP_NUM",      length=8)   private String propNum;
    @Column(name="ADD2",          length=35)  private String add2;
    @Column(name="ZIPCODE",  nullable=false, length=9)  private String zipcode;
    @Column(name="TOWN",     nullable=false, length=35) private String town;
    @Column(name="COUNTRY_CODE",nullable=false,length=3) private String countryCode;
    @Column(name="STATE",         length=2)   private String state;
    @Column(name="PHONE",         length=30)  private String phone;
    @Column(name="FAX",           length=30)  private String fax;
    @Column(name="EMAIL",         length=100) private String email;
    @Column(name="BUSINESS_TYPE", nullable=false, length=1) private String businessType;

    @Column(name="VAT_NO",          length=20)  private String vatNo;
    @Column(name="EORI",            length=20)  private String eori;
    // Still transient — columns not yet in DB:
    @Transient private String sellingWebsite;
    @Transient private String gpsLat;
    @Transient private String gpsLong;
    @Transient private String accountOwner;
}
