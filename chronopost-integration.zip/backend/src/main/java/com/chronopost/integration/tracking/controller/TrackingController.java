package com.chronopost.integration.tracking.controller;
import com.chronopost.integration.common.dto.ApiResponse;
import com.chronopost.integration.tracking.dto.*;
import com.chronopost.integration.tracking.service.TrackingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/tracking") @RequiredArgsConstructor @Slf4j
@CrossOrigin(origins="http://localhost:3000")
public class TrackingController {
    private final TrackingService trackingService;
    @GetMapping("/{parcelNumber}")
    public ResponseEntity<ApiResponse<TrackingResponse>> getByParcel(@PathVariable String parcelNumber) {
        try { return ResponseEntity.ok(ApiResponse.ok(trackingService.getByParcelNumber(parcelNumber))); }
        catch(IllegalArgumentException e) { return ResponseEntity.notFound().build(); }
        catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
    @GetMapping("/shipment/{shipmentId}")
    public ResponseEntity<ApiResponse<List<TrackingResponse>>> getByShipment(@PathVariable Long shipmentId) {
        try { return ResponseEntity.ok(ApiResponse.ok(trackingService.getByShipmentId(shipmentId))); }
        catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<TrackingDashboard>> getDashboard() {
        try { return ResponseEntity.ok(ApiResponse.ok(trackingService.getDashboard())); }
        catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<TrackingSearchResult>>> search(@RequestParam("q") String q) {
        try { return ResponseEntity.ok(ApiResponse.ok(trackingService.search(q))); }
        catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
    @PostMapping("/poll")
    public ResponseEntity<ApiResponse<TrackingPollResult>> poll() {
        try { return ResponseEntity.ok(ApiResponse.ok("Poll complete", trackingService.pollAndProcess())); }
        catch(Exception e) { return ResponseEntity.internalServerError().body(ApiResponse.error(e.getMessage())); }
    }
}
