package com.chronopost.integration.tracking.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TrackingFileResult {
    private String fileName;
    private int totalLines, eventsProcessed, eventsSkipped, parcelsNotFound;
}
