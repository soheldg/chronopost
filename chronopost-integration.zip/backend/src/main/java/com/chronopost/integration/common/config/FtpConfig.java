package com.chronopost.integration.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * SFTP configuration for Chronopost file exchange
 * Doc 4 — Commercial Invoice Exchange v1.1
 *
 * Configure in application.yml:
 *   chronopost:
 *     ftp:
 *       host: ftp.chronopost.fr
 *       port: 22
 *       username: YOUR_USERNAME
 *       password: YOUR_PASSWORD           # or use privateKeyPath
 *       private-key-path: /path/to/key   # preferred for production
 *       private-key-passphrase: OPTIONAL
 *       strict-host-key-checking: false   # true in production
 *       in-directory: /IN
 *       out-directory: /OUT
 *       test-directory: /TEST
 *       connect-timeout: 30000
 *       data-timeout: 60000
 */
@Configuration
@ConfigurationProperties(prefix = "chronopost.ftp")
@Data
public class FtpConfig {

    private String  host             = "ftp.chronopost.fr";
    private int     port             = 22;          // SFTP port (was 21 for FTP)
    private String  username;
    private String  password;

    // ── Key-based auth (preferred for production) ──────────────────────
    private String  privateKeyPath;                  // e.g. /home/app/.ssh/id_rsa
    private String  privateKeyPassphrase;            // null if key has no passphrase

    // ── Host key checking ──────────────────────────────────────────────
    private boolean strictHostKeyChecking = false;   // set true in production

    // ── Directories per Doc 4 §1.1 ────────────────────────────────────
    private String  inDirectory      = "/IN";
    private String  outDirectory     = "/OUT";
    private String  testDirectory    = "/TEST";      // Doc 4 §1.1

    // ── Timeouts (ms) ─────────────────────────────────────────────────
    private int     connectTimeout   = 30000;
    private int     dataTimeout      = 60000;
}
