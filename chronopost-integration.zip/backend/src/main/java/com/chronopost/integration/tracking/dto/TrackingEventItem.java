package com.chronopost.integration.tracking.dto;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class TrackingEventItem {
    private String eventCode, eventDescription, reasonCode;
    private String eventDate, eventTime, location;
    private String deskClerk, deliveryInstruction, instructionDescription;
    private String channel, weight;
}
