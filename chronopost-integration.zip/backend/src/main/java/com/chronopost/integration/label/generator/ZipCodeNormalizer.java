package com.chronopost.integration.label.generator;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Normalizes zip codes for Chronopost routing barcode (field B = 7 chars)
 *
 * Per Doc: Gestion_routage_GB-IE-JE-NL-PT V13.01
 *
 * GB (Great Britain): alphanumeric zip → numerical mapping:
 *   Remote areas (G83, IM, ZE, HS1-9, IV10-28, IV36-99,
 *                 KW1-9, FK17-21, KA27-28, PA20-49, PH17-99) → 03333
 *   All other GB zip codes → 01111
 *
 * IE (Ireland):   ALL zip codes → 00000
 * JE (Jersey):    ALL zip codes → 03333
 * GS (Guernsey):  ALL zip codes → 03333
 *
 * PT (Portugal):  "1849-003" → "1849003"  (remove dash)
 * NL (Netherlands): "1000 AC" → "1000AC"  (remove space)
 *
 * All others: remove spaces/dashes, left-pad with zeros to 7 chars
 */
@Component
@Slf4j
public class ZipCodeNormalizer {

    /**
     * Normalize zip code for routing barcode field B (7 chars, numeric, left-pad 0)
     *
     * @param zip         raw zip code
     * @param countryCode ISO 3166-2 country code (GB, IE, FR, BE, etc.)
     * @return 7-char padded string for routing barcode
     */
    public String normalize(String zip, String countryCode) {
        if (zip == null || zip.isBlank()) return "0000000";
        String cc = countryCode != null ? countryCode.toUpperCase() : "";

        String normalized = switch (cc) {
            case "GB" -> normalizeGB(zip);
            case "IE" -> "0000000";   // Ireland: always 00000 (7-char padded)
            case "JE" -> "0033333";   // Jersey:  always 03333
            case "GS", "GG" -> "0033333"; // Guernsey
            case "PT" -> normalizePT(zip); // Remove dash
            case "NL" -> normalizeNL(zip); // Remove space
            default   -> normalizeDefault(zip);
        };

        log.debug("ZIP normalize: {} ({}) → {}", zip, cc, normalized);
        return normalized;
    }

    // ── Great Britain ──────────────────────────────────────────────────
    private String normalizeGB(String zip) {
        String z = zip.trim().toUpperCase().replace(" ", "").replace("-", "");

        // Remote/island areas → 03333
        if (isRemoteGB(z)) return "0033333";

        // All other GB → 01111
        return "0011111";
    }

    private boolean isRemoteGB(String z) {
        // Exact codes
        if (z.startsWith("IM")) return true;
        if (z.startsWith("ZE")) return true;
        if (z.startsWith("G83")) return true;

        // Ranges
        if (inRange(z, "HS", 1, 9))   return true;
        if (inRange(z, "IV", 10, 28)) return true;
        if (inRange(z, "IV", 36, 99)) return true;
        if (inRange(z, "KW", 1, 9))   return true;
        if (inRange(z, "FK", 17, 21)) return true;
        if (inRange(z, "KA", 27, 28)) return true;
        if (inRange(z, "PA", 20, 49)) return true;
        if (inRange(z, "PH", 17, 99)) return true;

        return false;
    }

    /** Check if zip starts with prefix+number in [min, max] range */
    private boolean inRange(String zip, String prefix, int min, int max) {
        if (!zip.startsWith(prefix)) return false;
        try {
            String numStr = zip.substring(prefix.length()).replaceAll("[^0-9].*", "");
            int num = Integer.parseInt(numStr);
            return num >= min && num <= max;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // ── Portugal ───────────────────────────────────────────────────────
    // "1849-003" → "1849003" → pad to 7 = "1849003"
    private String normalizePT(String zip) {
        String z = zip.trim().replace("-", "").replace(" ", "");
        return padLeft(z, 7);
    }

    // ── Netherlands ───────────────────────────────────────────────────
    // "1000 AC" → "1000AC" → kept as-is (alphanumeric zip stays)
    private String normalizeNL(String zip) {
        String z = zip.trim().replace(" ", "");
        // NL zips are 4 digits + 2 letters (e.g. 1000AC)
        // Left-pad to 7 chars
        return padLeft(z, 7);
    }

    // ── Default ───────────────────────────────────────────────────────
    private String normalizeDefault(String zip) {
        String z = zip.trim().replace(" ", "").replace("-", "");
        return padLeft(z, 7);
    }

    private String padLeft(String s, int len) {
        if (s.length() >= len) return s.substring(0, len);
        return "0".repeat(len - s.length()) + s;
    }
}
