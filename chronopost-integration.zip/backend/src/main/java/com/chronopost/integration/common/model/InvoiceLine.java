package com.chronopost.integration.common.model;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name="CHR_INVOICE_LINES",schema="CHRONOPOST")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class InvoiceLine {
    @Id @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="chr_seq")
    @SequenceGenerator(name="chr_seq",sequenceName="CHR_SEQ",allocationSize=1)
    private Long id;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="SHIPMENT_ID",nullable=false)
    private Shipment shipment;
    @Column(name="POSITION") private Integer position;
    @Column(name="QUANTITY",nullable=false) private Integer quantity;
    @Column(name="CONTENT",nullable=false,length=200) private String content;
    @Column(name="AMOUNT",nullable=false) private Double amount;
    @Column(name="COUNTRY_ORIGIN",nullable=false,length=3) private String countryOrigin;
    @Column(name="NET_WEIGHT") private Long netWeight;
    @Column(name="GROSS_WEIGHT") private Long grossWeight;
    @Column(name="HS_CODE_RECV",nullable=false,length=8) private String hsCodeRecv;
    @Column(name="HS_CODE_SEND",nullable=false,length=10) private String hsCodeSend;
    @Column(name="PROD_CODE",length=255) private String prodCode;
    @Column(name="PROD_TYPE",length=70) private String prodType;
    @Column(name="FABRIC_COMP",length=200) private String fabricComposition;
    @Column(name="GOODS_WEBPAGE",length=255) private String goodsWebpage;
}
