-- ============================================================
-- CHRONOPOST INTEGRATION - ORACLE 11g SCHEMA
-- Run this script as CHRONOPOST user
-- ============================================================

-- ===== SEQUENCES =====
CREATE SEQUENCE CHR_SEQ
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;

-- ===== 1. SHIPMENTS =====
CREATE TABLE CHR_SHIPMENTS (
    ID              NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    MPSID           VARCHAR2(14)    NOT NULL,
    MPSID_CCKEY     VARCHAR2(1),
    STATUS          VARCHAR2(20)    DEFAULT 'CREATED' NOT NULL,
    SERVICE_CODE    NUMBER(3),
    LINEHAUL        VARCHAR2(2),                        -- AI=Air, RO=Road, SE=Sea
    CDATE           DATE            DEFAULT SYSDATE,
    CTIME           VARCHAR2(6),
    SDEPOT          VARCHAR2(7)     DEFAULT '0029999',
    SYSDEPOT        VARCHAR2(7)     DEFAULT '0020456',
    HARDWARE        VARCHAR2(1)     DEFAULT 'K',
    DELMODALLOW     NUMBER(1)       DEFAULT 1,
    SPTDATE         DATE,
    MPSCOUNT        NUMBER(3),
    MPSWEIGHT       NUMBER(8),
    MPSVOLUME       VARCHAR2(9),
    OPCODE          VARCHAR2(3)     DEFAULT 'INS',
    TIMEZONE        VARCHAR2(5)     DEFAULT '+0000',
    CREATED_AT      TIMESTAMP       DEFAULT SYSTIMESTAMP,
    UPDATED_AT      TIMESTAMP,
    CONSTRAINT CHR_SHIP_STATUS_CHK
        CHECK (STATUS IN ('CREATED','LABEL_READY','PREALERT_SENT',
                          'INVOICE_SENT','HANDED_OVER','IN_TRANSIT',
                          'DELIVERED','FAILED','RETURNED'))
);

-- ===== 2. SENDERS =====
CREATE TABLE CHR_SENDERS (
    ID                  NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SHIPMENT_ID         NUMBER          NOT NULL
        REFERENCES CHR_SHIPMENTS(ID) ON DELETE CASCADE,
    ACCOUNT_NO          VARCHAR2(20)    NOT NULL,
    SUB_ACCOUNT_NO      VARCHAR2(5),
    COMPANY_NAME        VARCHAR2(35),
    NAME1               VARCHAR2(35),
    NAME2               VARCHAR2(35),
    STREET              VARCHAR2(35)    NOT NULL,
    PROP_NUM            VARCHAR2(8),
    ADD2                VARCHAR2(35),
    ADD3                VARCHAR2(35),
    ZIPCODE             VARCHAR2(9)     NOT NULL,
    TOWN                VARCHAR2(35)    NOT NULL,
    COUNTRY_CODE        VARCHAR2(3)     NOT NULL,
    STATE               VARCHAR2(2),
    PHONE               VARCHAR2(30),
    FAX                 VARCHAR2(30),
    EMAIL               VARCHAR2(100),
    BUSINESS_TYPE       CHAR(1)         NOT NULL,       -- P=Private, B=Business
    VAT_NO              VARCHAR2(20),
    EORI                VARCHAR2(20),
    SELLING_WEBSITE     VARCHAR2(255),
    TAX_ID_TYPE         VARCHAR2(1),
    TAX_ID_VALUE        VARCHAR2(20),
    GPS_LAT             VARCHAR2(16),
    GPS_LONG            VARCHAR2(16),
    ACCOUNT_OWNER       VARCHAR2(3),
    CONSTRAINT CHR_SEND_BIZ_CHK CHECK (BUSINESS_TYPE IN ('P','B'))
);

-- ===== 3. RECEIVERS =====
CREATE TABLE CHR_RECEIVERS (
    ID                  NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SHIPMENT_ID         NUMBER          NOT NULL
        REFERENCES CHR_SHIPMENTS(ID) ON DELETE CASCADE,
    NAME1               VARCHAR2(35),
    NAME2               VARCHAR2(35),
    COMPANY_NAME        VARCHAR2(35),
    COMPANY_NAME2       VARCHAR2(35),
    STREET              VARCHAR2(35)    NOT NULL,
    PROP_NUM            VARCHAR2(8),
    ADD2                VARCHAR2(35),
    ADD3                VARCHAR2(35),
    ZIPCODE             VARCHAR2(9)     NOT NULL,
    TOWN                VARCHAR2(35)    NOT NULL,
    COUNTRY_CODE        VARCHAR2(3)     NOT NULL,
    STATE               VARCHAR2(2),
    DOOR_CODE           VARCHAR2(8),
    PHONE1              VARCHAR2(30),
    PHONE2              VARCHAR2(30),
    FAX                 VARCHAR2(30),
    EMAIL               VARCHAR2(100),
    BUSINESS_TYPE       CHAR(1)         NOT NULL,       -- P=Private, B=Business
    PUDO_ID             VARCHAR2(20),
    VAT_NO              VARCHAR2(20),
    EORI                VARCHAR2(20),
    TAX_ID_TYPE         VARCHAR2(1),
    TAX_ID_VALUE        VARCHAR2(20),
    GPS_LAT             VARCHAR2(16),
    GPS_LONG            VARCHAR2(16),
    CONSTRAINT CHR_RECV_BIZ_CHK CHECK (BUSINESS_TYPE IN ('P','B'))
);

-- ===== 4. PARCELS =====
CREATE TABLE CHR_PARCELS (
    ID                  NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SHIPMENT_ID         NUMBER          NOT NULL
        REFERENCES CHR_SHIPMENTS(ID) ON DELETE CASCADE,
    PARCEL_NUMBER       VARCHAR2(14)    NOT NULL,       -- 13 char Chronopost ID
    PARCEL_CCKEY        VARCHAR2(1),                    -- checksum of parcel no
    GEOPOST_TRACK_ID    VARCHAR2(15),                   -- 14 chars + 1 checksum
    ROUTING_BARCODE     VARCHAR2(29),                   -- 28 chars + 1 checksum
    PARCEL_RANK         NUMBER(3),
    SERVICE_CODE        NUMBER(3)       NOT NULL,
    DECLARED_WEIGHT     NUMBER(8),                      -- in grams
    MEASURED_WEIGHT     NUMBER(8),
    DIMENSION           VARCHAR2(9),                    -- LWH in cm
    LABEL_PATH          VARCHAR2(255),
    LABEL_STATUS        VARCHAR2(20)    DEFAULT 'PENDING',
    PCONTENT            VARCHAR2(200),
    OWNER_BU            VARCHAR2(3)     DEFAULT 'CHR',
    ASCODE              VARCHAR2(6),
    HAZLQ               NUMBER(1)       DEFAULT 0,
    HZD_PACK_CODE       VARCHAR2(3),
    INS_AMOUNT          NUMBER(15,3),
    INS_CURRENCY        VARCHAR2(3),
    CREATED_AT          TIMESTAMP       DEFAULT SYSTIMESTAMP,
    CONSTRAINT CHR_PARC_LABEL_CHK
        CHECK (LABEL_STATUS IN ('PENDING','GENERATED','PRINTED','ERROR'))
);

-- ===== 5. CUSTOMS (INTER) =====
CREATE TABLE CHR_CUSTOMS (
    ID                      NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SHIPMENT_ID             NUMBER          NOT NULL
        REFERENCES CHR_SHIPMENTS(ID) ON DELETE CASCADE,
    PARCEL_TYPE             CHAR(1),                    -- D=Document, P=Non-Doc
    CUSTOMS_AMOUNT          NUMBER(15,3),
    CURRENCY                VARCHAR2(3),
    CUSTOMS_AMOUNT_EX       NUMBER(15,3),
    CURRENCY_EX             VARCHAR2(3),
    INCOTERMS               VARCHAR2(2),                -- 01=DAP, 02=DDP, 03=DDP+TAX etc
    CLEARANCE_STATUS        CHAR(1),                    -- N,F,E,T,I,H
    HIGH_LOW_VALUE          CHAR(1),                    -- H,M,L
    PREALERT_STATUS         VARCHAR2(3),                -- S03,S04,S05 etc
    INVOICE_NO              VARCHAR2(20),
    INVOICE_DATE            DATE,
    REASON_FOR_EXPORT       VARCHAR2(2)     DEFAULT '01', -- 01=sale, 02=return, 03=gift
    NUMBER_OF_ARTICLE       NUMBER(6),
    DEST_COUNTRY_REG        VARCHAR2(15),               -- IOSS number
    SI_EORI                 VARCHAR2(20),
    TRANSPORT_COST          NUMBER(15,3),
    TRANSPORT_COST_CUR      VARCHAR2(3),
    -- Commercial invoice consignee
    C_NAME1                 VARCHAR2(35),
    C_NAME2                 VARCHAR2(35),
    C_STREET                VARCHAR2(35),
    C_PROP_NUM              VARCHAR2(8),
    C_COUNTRY_CODE          VARCHAR2(3),
    C_ZIPCODE               VARCHAR2(9),
    C_TOWN                  VARCHAR2(35),
    C_CONTACT               VARCHAR2(35),
    C_PHONE                 VARCHAR2(30),
    C_EMAIL                 VARCHAR2(100),
    C_VAT_NO                VARCHAR2(20),
    C_EORI                  VARCHAR2(20),
    -- Sender invoice address
    SI_NAME1                VARCHAR2(35),
    SI_NAME2                VARCHAR2(35),
    SI_STREET               VARCHAR2(35),
    SI_ZIPCODE              VARCHAR2(9),
    SI_TOWN                 VARCHAR2(35),
    SI_COUNTRY_CODE         VARCHAR2(3),
    CONSTRAINT CHR_CUST_TYPE_CHK
        CHECK (PARCEL_TYPE IN ('D','P') OR PARCEL_TYPE IS NULL),
    CONSTRAINT CHR_CUST_CLEAR_CHK
        CHECK (CLEARANCE_STATUS IN ('N','F','E','T','I','H') OR CLEARANCE_STATUS IS NULL)
);

-- ===== 6. INVOICE LINES (INTERINVOICELINE) =====
CREATE TABLE CHR_INVOICE_LINES (
    ID              NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SHIPMENT_ID     NUMBER          NOT NULL
        REFERENCES CHR_SHIPMENTS(ID) ON DELETE CASCADE,
    POSITION        NUMBER(6),
    QUANTITY        NUMBER(4)       NOT NULL,
    CONTENT         VARCHAR2(200)   NOT NULL,
    AMOUNT          NUMBER(15,3)    NOT NULL,
    COUNTRY_ORIGIN  VARCHAR2(3)     NOT NULL,
    NET_WEIGHT      NUMBER(8),
    GROSS_WEIGHT    NUMBER(8),
    HS_CODE_RECV    VARCHAR2(8)     NOT NULL,           -- RCTARIF
    HS_CODE_SEND    VARCHAR2(10)    NOT NULL,           -- SCTARIF
    PROD_CODE       VARCHAR2(255),
    PROD_TYPE       VARCHAR2(70),
    FABRIC_COMP     VARCHAR2(200),
    GOODS_WEBPAGE   VARCHAR2(255)
);

-- ===== 7. TRACKING EVENTS =====
CREATE TABLE CHR_TRACKING_EVENTS (
    ID              NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    PARCEL_ID       NUMBER          NOT NULL
        REFERENCES CHR_PARCELS(ID) ON DELETE CASCADE,
    CONTRACT_NO     VARCHAR2(8),
    EVENT_CODE      VARCHAR2(3),
    REASON_CODE     VARCHAR2(3),
    EVENT_DATE      DATE,
    EVENT_TIME      VARCHAR2(4),
    LOCATION        VARCHAR2(100),
    CHANNEL         VARCHAR2(4),
    CHANNEL_ADDR    VARCHAR2(50),
    DELIVERY_INST   VARCHAR2(35),
    DESK_CLERK      VARCHAR2(35),
    WEIGHT          VARCHAR2(7),
    -- FIX: Missing fields from EDIPOD F42-F51
    PICKUP_PUDO_CODE  VARCHAR2(9),   -- F44: PickUp PUDO code
    DISPOSAL_PLACE    VARCHAR2(8),   -- F42: Disposal place code
    NEW_DELIVERY_DATE DATE,          -- F43: New delivery date
    LENGTH_CM         VARCHAR2(3),   -- F48: Parcel length (cm)
    WIDTH_CM          VARCHAR2(3),   -- F49: Parcel width (cm)
    HEIGHT_CM         VARCHAR2(3),   -- F50: Parcel height (cm)
    POD_IMAGE_URL     VARCHAR2(150), -- F51: Proof of delivery URL
    RAW_LINE          CLOB,
    CREATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ===== 8. PREALERT FILES =====
CREATE TABLE CHR_PREALERT_FILES (
    ID              NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SHIPMENT_ID     NUMBER          NOT NULL
        REFERENCES CHR_SHIPMENTS(ID) ON DELETE CASCADE,
    FILE_NAME       VARCHAR2(255)   NOT NULL,
    FILE_CONTENT    CLOB,
    FTP_STATUS      VARCHAR2(20)    DEFAULT 'PENDING',
    ERROR_MSG       VARCHAR2(500),
    SENT_AT         TIMESTAMP,
    CREATED_AT      TIMESTAMP       DEFAULT SYSTIMESTAMP,
    CONSTRAINT CHR_PRE_STATUS_CHK
        CHECK (FTP_STATUS IN ('PENDING','SENT','FAILED'))
);

-- ===== 9. INVOICE FILES =====
CREATE TABLE CHR_INVOICE_FILES (
    ID              NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SHIPMENT_ID     NUMBER          NOT NULL
        REFERENCES CHR_SHIPMENTS(ID) ON DELETE CASCADE,
    FILE_NAME       VARCHAR2(255)   NOT NULL,
    FILE_PATH       VARCHAR2(255),
    DIRECTION       VARCHAR2(3)     DEFAULT 'OUT',      -- OUT=upload, IN=download
    FTP_STATUS      VARCHAR2(20)    DEFAULT 'PENDING',
    ERROR_MSG       VARCHAR2(500),
    UPLOADED_AT     TIMESTAMP,
    CREATED_AT      TIMESTAMP       DEFAULT SYSTIMESTAMP,
    CONSTRAINT CHR_INV_DIR_CHK   CHECK (DIRECTION IN ('OUT','IN')),
    CONSTRAINT CHR_INV_STAT_CHK
        CHECK (FTP_STATUS IN ('PENDING','SENT','RECEIVED','FAILED'))
);

-- ===== INDEXES =====
CREATE INDEX IDX_SHIP_MPSID   ON CHR_SHIPMENTS(MPSID);
CREATE INDEX IDX_SHIP_STATUS  ON CHR_SHIPMENTS(STATUS);
CREATE INDEX IDX_PARC_SHIPID  ON CHR_PARCELS(SHIPMENT_ID);
CREATE INDEX IDX_PARC_NO      ON CHR_PARCELS(PARCEL_NUMBER);
CREATE INDEX IDX_PARC_TRACK   ON CHR_PARCELS(GEOPOST_TRACK_ID);
CREATE INDEX IDX_TRACK_PARC   ON CHR_TRACKING_EVENTS(PARCEL_ID);
CREATE INDEX IDX_TRACK_DATE   ON CHR_TRACKING_EVENTS(EVENT_DATE);
CREATE INDEX IDX_INVL_SHIPID  ON CHR_INVOICE_LINES(SHIPMENT_ID);

-- ===== TRIGGER: Updated timestamp =====
CREATE OR REPLACE TRIGGER CHR_SHIP_UPD_TRG
    BEFORE UPDATE ON CHR_SHIPMENTS
    FOR EACH ROW
BEGIN
    :NEW.UPDATED_AT := SYSTIMESTAMP;
END;
/

COMMIT;



-- ===== CHR_ROUTING (from ROUCHR routing file — 417K rows) =====
-- Loaded via SQL*Loader (sqlldr) — see load_routing.ctl
-- Used to auto-resolve: origSort, agencyCode, distribSort, numCountryCode
-- for every label by (serviceType, countryCode, zipCode) lookup
CREATE TABLE CHR_ROUTING (
    ID              NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    SERVICE_TYPE    VARCHAR2(6)     NOT NULL,  -- Col 1: DPD, 12H, INT, IPM...
    COUNTRY_CODE    VARCHAR2(3)     NOT NULL,  -- Col 2: FR, BE, GB, DE...
    ZIP_FROM        VARCHAR2(10)    NOT NULL,  -- Col 3: range start
    ZIP_TO          VARCHAR2(10)    NOT NULL,  -- Col 4: range end
    ORIG_SORT       VARCHAR2(10),              -- Col 5: Origine Sort (label left)
    AGENCY_CODE     VARCHAR2(10),              -- Col 6: Agency/hub code (label center)
    DISTRIB_SORT    VARCHAR2(10),              -- Col 7: Distrib Sort (label right)
    ROUTING_ZONE    VARCHAR2(10),              -- Col 8: routing zone/version
    NUM_COUNTRY     VARCHAR2(5),               -- Col 9: numerical country code (barcode E)
    DELIVERY_PT     VARCHAR2(10),              -- Col 10: delivery point code
    FILE_VERSION    VARCHAR2(20)    DEFAULT '20260302_B3', -- routing file version
    CREATED_AT      TIMESTAMP       DEFAULT SYSTIMESTAMP
);

-- Indexes for fast lookup
CREATE INDEX IDX_ROUT_SVC_CC  ON CHR_ROUTING(SERVICE_TYPE, COUNTRY_CODE);
CREATE INDEX IDX_ROUT_ZIP     ON CHR_ROUTING(COUNTRY_CODE, ZIP_FROM, ZIP_TO);
CREATE INDEX IDX_ROUT_LOOKUP  ON CHR_ROUTING(SERVICE_TYPE, COUNTRY_CODE, ZIP_FROM, ZIP_TO);

-- ===== CHR_PRODUCTS (from PRODUIT.CSV — Chronopost product reference) =====
-- Loaded from PRODUIT.CSV provided by Chronopost
-- App uses this to auto-resolve suffix, service name, service text by service code
CREATE TABLE CHR_PRODUCTS (
    ID              NUMBER          DEFAULT CHR_SEQ.NEXTVAL PRIMARY KEY,
    CODE_GEOPOST    NUMBER(4)       NOT NULL,    -- Col 1: Geopost service code (327/328)
    PLTRI           VARCHAR2(4),                 -- Col 2: Sort code (DPD.)
    SERVICE_MARK    VARCHAR2(2),                 -- Col 3: X=small, E=express, R=relay, V=RDV
    FAMILLE_GEO     VARCHAR2(4),                 -- Col 4: Geopost family
    SERVICE_TEXT    VARCHAR2(20),                -- Col 5: Short service text (D-B2C)
    DESCRIPTION     VARCHAR2(35),                -- Col 6: Full product description
    PRODUIT_CHR     VARCHAR2(1),                 -- Col 7: O/S/N/T
    NAT_INTER       VARCHAR2(1),                 -- Col 8: N=national, I=international
    JOUR            VARCHAR2(2),                 -- Col 9: SE/VE/DI
    SUFFIXE         VARCHAR2(4),                 -- Col 15: Parcel ID suffix (JF, EE, FR)
    CODE_FACT       VARCHAR2(4),                 -- Col 16: Billing code
    LIBEL25         VARCHAR2(25),                -- Col 17: 25-char label text (COM INT)
    CODE_EXP        VARCHAR2(4),                 -- Col 18: Export code
    LIBELLE_FA      VARCHAR2(35),                -- Col 20: Service label name
    IS_PRIMARY      VARCHAR2(1)   DEFAULT 'P',   -- Col 21: P=Primary, O=Other
    ACTIVE          NUMBER(1)     DEFAULT 1,
    CREATED_AT      TIMESTAMP     DEFAULT SYSTIMESTAMP,
    CONSTRAINT UQ_CHR_PROD UNIQUE (CODE_GEOPOST, NAT_INTER, SERVICE_MARK, JOUR)
);

CREATE INDEX IDX_PROD_CODE ON CHR_PRODUCTS(CODE_GEOPOST);
CREATE INDEX IDX_PROD_NAT  ON CHR_PRODUCTS(NAT_INTER);

-- ===== CHR_PARCEL_COUNTER (persists parcel ID counter per prefix) =====
-- Ensures counter survives server restarts (spec: no duplicate in 6 months)
CREATE TABLE CHR_PARCEL_COUNTER (
    PREFIX      VARCHAR2(5)  NOT NULL PRIMARY KEY,
    COUNTER_VAL NUMBER(6)    DEFAULT 1 NOT NULL,
    UPDATED_AT  TIMESTAMP    DEFAULT SYSTIMESTAMP
);
